# Segurança

Este repositório pode ser público. Por isso, não coloque credenciais reais em ficheiros, issues, commits ou screenshots.

## Nunca publicar

Não publique:

- utilizador DPD de produção;
- password DPD;
- client secret;
- chave Pickup/MyPudo;
- tokens OAuth;
- etiquetas PDF reais;
- dados pessoais de clientes;
- moradas reais;
- payloads completos de expedições reais;
- logs com dados pessoais.

## Se uma credencial for exposta

Se uma credencial foi publicada por engano:

1. Remova a credencial do repositório.
2. Não confie apenas em apagar o ficheiro, porque o histórico do Git pode manter a informação.
3. Contacte a DPD e peça a substituição/rotação da credencial.
4. Atualize a configuração do módulo no backoffice.
5. Teste novamente o OAuth e a criação de expedição.

## Reportar vulnerabilidades

Não abra uma issue pública para reportar vulnerabilidades com dados sensíveis.

Envie o relatório por canal privado, incluindo:

- versão do módulo;
- versão do PrestaShop;
- passos para reproduzir;
- impacto esperado;
- prints sem dados sensíveis.
