<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

$sql = [];

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'rgcdpd_pickup` (
    `id_rgcdpd_pickup` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `id_cart` INT UNSIGNED NULL,
    `id_order` INT UNSIGNED NULL,
    `pickup_code` VARCHAR(32) NOT NULL,
    `pickup_name` VARCHAR(255) NOT NULL,
    `pickup_address` VARCHAR(255) NULL,
    `pickup_zip` VARCHAR(32) NULL,
    `pickup_city` VARCHAR(128) NULL,
    `pickup_country` VARCHAR(8) NULL,
    `raw_response` LONGTEXT NULL,
    `date_add` DATETIME NOT NULL,
    `date_upd` DATETIME NOT NULL,
    PRIMARY KEY (`id_rgcdpd_pickup`),
    KEY `idx_rgcdpd_pickup_cart` (`id_cart`),
    KEY `idx_rgcdpd_pickup_order` (`id_order`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'rgcdpd_shipment` (
    `id_rgcdpd_shipment` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `id_order` INT UNSIGNED NOT NULL,
    `id_cart` INT UNSIGNED NULL,
    `carrier_type` VARCHAR(32) NOT NULL,
    `dpd_sub_account` VARCHAR(32) NULL,
    `tracking_number` VARCHAR(64) NULL,
    `label_path` VARCHAR(255) NULL,
    `request_payload` LONGTEXT NULL,
    `response_payload` LONGTEXT NULL,
    `status` VARCHAR(32) NOT NULL DEFAULT "created",
    `is_test` TINYINT(1) NOT NULL DEFAULT 1,
    `date_add` DATETIME NOT NULL,
    `date_upd` DATETIME NOT NULL,
    PRIMARY KEY (`id_rgcdpd_shipment`),
    UNIQUE KEY `uniq_rgcdpd_shipment_order` (`id_order`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'rgcdpd_log` (
    `id_rgcdpd_log` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `context_type` VARCHAR(64) NOT NULL,
    `context_id` INT UNSIGNED NULL,
    `level` VARCHAR(16) NOT NULL,
    `message` VARCHAR(255) NOT NULL,
    `payload` LONGTEXT NULL,
    `date_add` DATETIME NOT NULL,
    PRIMARY KEY (`id_rgcdpd_log`),
    KEY `idx_rgcdpd_log_context` (`context_type`, `context_id`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

foreach ($sql as $query) {
    if (!Db::getInstance()->execute($query)) {
        return false;
    }
}

return true;
