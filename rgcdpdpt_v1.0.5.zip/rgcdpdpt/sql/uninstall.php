<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

$sql = [];
$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'rgcdpd_pickup`';
$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'rgcdpd_shipment`';
$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'rgcdpd_log`';

foreach ($sql as $query) {
    if (!Db::getInstance()->execute($query)) {
        return false;
    }
}

return true;
