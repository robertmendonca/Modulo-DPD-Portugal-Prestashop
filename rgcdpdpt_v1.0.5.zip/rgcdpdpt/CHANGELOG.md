## 1.0.5

- Corrige a configuração OAuth interna do plugin.
- Define automaticamente o `client_id` e o `client_secret` fornecidos pela DPD.
- Mantém estes campos ocultos no backoffice.
- Repara automaticamente instalações anteriores com `client_secret` em falta.
- Adiciona ao Diagnóstico apenas o estado configurado/em falta, sem expor o segredo.

## 1.0.4

- Corrigido o cálculo de `fresh_pickup_date`: passa a utilizar o dia útil seguinte, ignorando fins de semana e feriados nacionais portugueses.
- Corrigido o cálculo de `fresh_expiration_date`: a validade passa a ser contada a partir da data de recolha Fresh, e não a partir da data de criação da expedição.
- Movido o campo **Validade Fresh** da aba Operação para a própria linha da conta **DPD Portugal Fresh**, na aba Contas DPD.
- O cliente pode configurar entre 1 e 365 dias de validade após a recolha; o valor por defeito continua a ser 5 dias.
- Mantida a compatibilidade com PrestaShop 8.x e 9.x.

## 1.0.3

- Adicionado verificador próprio de atualizações do módulo.
- O módulo consulta automaticamente, no máximo uma vez a cada 24 horas, o pacote publicado em `https://api.rgcconsulting.pt/dpd/module/latest/rgcdpdpt_v1.0.x.zip`.
- A versão é identificada diretamente no `config.xml` existente dentro do ZIP disponibilizado.
- Adicionado aviso no topo da configuração quando existe uma versão mais recente.
- Adicionado botão **Procurar atualizações** para verificação manual.
- Adicionado estado da atualização na aba **Diagnóstico**, incluindo versão instalada, versão disponível, última verificação e SHA-256 do pacote.
- A atualização continua manual: o módulo não substitui os seus próprios ficheiros automaticamente.
- Compatibilidade declarada atualizada para PrestaShop 8.x e 9.x.

## 1.0.2

- Adicionado serviço **DPD Portugal Fresh** como nova conta configurável.
- Quando uma encomenda usa DPD Fresh, o payload da API passa a incluir `fresh_pickup_date` com D+1.
- Adicionado envio de `fresh_expiration_date` com validade D+5 por defeito.
- Adicionado campo **Validade Fresh (dias)** na aba Operação para permitir validade inferior quando solicitado pelo cliente.
- Atualizada a estrutura de serviços para incluir a conta Fresh no registo técnico enviado à API RGC.

## 1.0.1

- Adiciona envio técnico das contas DPD configuradas para a API de registo.
- O envio passa a incluir serviço, tipo de entrega, conta DPD, estado ativo/inativo e nome visível.
- Ao guardar a configuração do módulo, o registo técnico é atualizado na API central.
- Não são enviados dados de clientes, encomendas, credenciais DPD, tokens ou etiquetas.

## 1.0.0

- Marca a primeira versão estável do módulo.
- Adiciona registo técnico simples de instalação para `https://api.rgcconsulting.pt/dpd/register-install`.
- O registo envia apenas domínio da loja, data da instalação, versão do módulo, versão do PrestaShop e identificador técnico da instalação.
- O registo não bloqueia a instalação caso a API esteja indisponível.
- Não são enviados dados de clientes, encomendas, credenciais DPD, tokens ou etiquetas.

## 0.7.16

- Corrige a acentuação dos textos visíveis no backoffice do módulo.
- Ajusta mensagens de validação e diagnóstico para português de Portugal.
- Atualiza os assets do backoffice para evitar cache dos textos antigos.

## 0.7.15

- Guarda o estado visual da secção Pickup da aba Contas DPD.
- Ao ativar o conteúdo Pickup, a secção permanece ativa após atualizar a página.
- Ao desativar o conteúdo Pickup, a secção permanece desativada após atualizar a página.
- Adiciona persistência via configuração do módulo e localStorage do backoffice.

## 0.7.14

- Corrige a secção Pickup da aba Contas DPD para iniciar oculta por defeito.
- Transforma o botão Pickup em alternância visual: Ativar conteúdo Pickup / Desativar conteúdo Pickup.
- Mantém o alerta de confirmação apenas ao ativar a visualização dos serviços Pickup.

## 0.7.13

- Renomeia a aba Tipologia de serviços / Contas DPD para Contas DPD.
- Divide a configuração de contas DPD em duas secções: Home e Pickup.
- Adiciona botão de ativação visual para mostrar a configuração Pickup, com alerta para usar apenas quando existir contrato DPD para Pickup/Shop.

# Changelog

## 0.7.12

- Adiciona fundo cinza bem claro na aba ativa da configuração do módulo para diferenciar visualmente das demais abas.

## 0.7.11

- Remove completamente a aba Pesquisa de pontos Pickup da configuração do módulo no backoffice.
- Mantém a configuração técnica Pickup/Shop gerida internamente, sem exposição na interface.

## 0.7.10

- A aba Pesquisa de pontos Pickup deixa de mostrar os parâmetros técnicos fixos da pesquisa Pickup/Shop.
- Mantém os valores internos existentes sem os expor no HTML do formulário.

## 0.7.9

- A aba DPD passa a mostrar apenas Utilizador da API e Password da API.
- Oculta da configuração visível os campos técnicos fixos: modo, endpoints, Client ID e Client secret.
- Ajusta os defaults internos para ambiente live e Client ID 2.

## 0.7.8

- Melhora o diagnóstico exibido na encomenda, mostrando resumo da expedição, serviço DPD, conta usada, destino, payload enviado e resposta recebida.
- Regista logs mais completos quando a DPD recusa a criação da expedição, incluindo conta DPD, serviço, destino, endpoint e resposta.
- Mantém tokens, passwords e etiquetas PDF/base64 omitidos nos logs e no diagnóstico.

## 0.7.7

- Força HTTP/1.1 nas chamadas cURL para OAuth, criação de expedição e fallback Pickup, evitando falhas de HTTP/2 como `stream 0 was not closed cleanly: CANCEL`.
- Adiciona headers `Connection: close` e `Expect:` nas chamadas DPD para reduzir problemas de negociação/proxy.
- Melhora o log de erro cURL com `curl_errno`, mensagem e HTTP status.

## 0.7.6

- Mapa Pickup passa a carregar automaticamente quando o cliente seleciona um serviço Pickup/Shop.
- O botão **Procurar pontos Pickup** fica disponível para atualizar a pesquisa quando o código postal é alterado.

## 0.7.5

- Corrigida validação que mostrava o alerta de seleção Pickup antes da morada estar preenchida.

## 0.7.4

- Adicionados ícones personalizados DPD no mapa Pickup.
- Adicionados ícones próprios para carriers Home e Pickup/Shop.

## 0.7.3

- Criada aba própria para **Pesquisa de pontos Pickup**.

## 0.7.2

- Criada aba **Tipologia de serviços / Contas DPD**.
- Removida a configuração antiga baseada em Subconta Home/Pickup.
- Configuração passa a ser baseada nos serviços DPD fornecidos pela DPD.

## 0.7.1

- Configuração do backoffice reorganizada com abas Bootstrap `nav nav-tabs`.

## 0.7.0

- Adicionada base de serviços DPD por tipologia.
- Adicionados serviços Portugal Home, Portugal Shop, Portugal Ilhas, Espanha Home, Espanha Shop, Internacional Home e Internacional Shop.
