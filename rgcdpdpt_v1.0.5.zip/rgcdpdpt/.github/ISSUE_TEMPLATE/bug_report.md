---
name: Reportar problema
about: Use este modelo para reportar problemas no módulo RGC DPD PT
title: "[Bug] "
labels: bug
assignees: ''
---

## Descrição do problema

Explique o que aconteceu.

## Passos para reproduzir

1. Ir a...
2. Clicar em...
3. Selecionar...
4. Ver erro...

## Resultado esperado

Explique o que deveria acontecer.

## Ambiente

- PrestaShop:
- PHP:
- Versão do módulo:
- Tema usado:
- Ambiente DPD: QA ou produção
- Serviço DPD: Portugal Home / Portugal Shop / Ilhas / Espanha / Internacional

## Mensagem de erro

Cole a mensagem de erro, removendo dados pessoais e credenciais.

```text

```

## Prints

Adicione prints se necessário, mas remova passwords, tokens, moradas reais e dados pessoais.

## Informação sensível

Não coloque aqui:

- password DPD;
- client secret;
- chave Pickup/MyPudo;
- dados pessoais de clientes;
- etiquetas reais;
- payloads completos com dados reais.
