# Guia de utilização

Este guia explica o fluxo normal depois do módulo estar instalado e configurado.

## Fluxo do cliente no checkout

1. O cliente adiciona produtos ao carrinho.
2. Preenche a morada de entrega.
3. O PrestaShop mostra os métodos DPD disponíveis para essa morada.
4. O cliente escolhe Home ou Pickup/Shop.

### Se escolher Home

A encomenda será entregue na morada indicada pelo cliente.

### Se escolher DPD Fresh

O cliente final escolhe o método DPD Fresh no checkout como qualquer outra transportadora.

No momento de criar a expedição, o módulo adiciona automaticamente as datas Fresh exigidas pela DPD.

### Se escolher Pickup/Shop

O módulo mostra automaticamente:

- lista de pontos Pickup próximos;
- mapa com os pontos disponíveis;
- marcador DPD no mapa.

O cliente deve selecionar um ponto Pickup antes de continuar.

O botão **Procurar pontos Pickup** serve para atualizar a pesquisa, por exemplo quando o cliente altera o código postal.

## Fluxo do lojista no backoffice

1. Entre no backoffice.
2. Vá a **Encomendas**.
3. Abra a encomenda.
4. Confirme que a encomenda está paga ou pronta para envio.
5. No bloco DPD, clique em **Criar expedição DPD**.
6. Aguarde a resposta da DPD.
7. Abra ou descarregue a etiqueta PDF.
8. Imprima a etiqueta.
9. Cole a etiqueta na encomenda.

## Quando criar a expedição

A expedição não é criada automaticamente no momento da compra.

Isto é intencional. Evita criar expedições para encomendas:

- não pagas;
- canceladas;
- pendentes de validação;
- com stock indisponível;
- ainda em preparação.

## Onde encontrar a guia e a etiqueta

Depois da expedição criada, o módulo guarda:

- número da guia;
- etiqueta PDF;
- resposta da DPD;
- tracking no PrestaShop.

A etiqueta fica disponível no bloco DPD da encomenda.

## Se a expedição falhar

Leia a mensagem devolvida pela DPD.

As causas mais comuns são:

- conta DPD incorreta para o serviço;
- credenciais inválidas;
- IP não autorizado;
- morada incompleta;
- ponto Pickup não selecionado;
- serviço não contratado na DPD.

Use a aba **Diagnóstico** para obter mais informação.
