# Guia de configuração DPD

A configuração do módulo está dividida por abas para facilitar a utilização.

## Aba DPD

Nesta aba ficam apenas as credenciais principais da API DPD.

Preencha os campos com os dados fornecidos pela DPD:

- utilizador da API;
- password da API.

Os endpoints técnicos, Client ID, Client secret e parâmetros Pickup são geridos internamente pelo módulo e não aparecem na interface do cliente.

Depois de guardar, use o botão **Testar OAuth DPD**, se disponível.

## Aba Contas DPD

Nesta aba deve configurar os serviços contratados com a DPD.

A configuração está dividida em duas secções:

- **Home**;
- **Pickup**.

Cada linha representa um serviço.

| Conta DPD | Serviço | Tipo |
|---|---|---|
| `09999001` | DPD Portugal Home | Home |
| `09999002` | DPD Portugal Shop | Pickup/Shop |
| `09999008` | DPD Portugal Fresh | Fresh |
| `09999003` | DPD Portugal Ilhas | Home |
| `09999004` | DPD Espanha Home | Home |
| `09999005` | DPD Espanha Shop | Pickup/Shop |
| `09999006` | DPD Internacional Home | Home |
| `09999007` | DPD Internacional Shop | Pickup/Shop |

As contas acima são exemplos. Use as contas reais fornecidas pela DPD.

Para cada serviço, confirme:

- se está ativo;
- se a conta tem 8 dígitos;
- se o nome visível está correto;
- se o serviço foi contratado com a DPD.

### Secção Home

Use esta secção para serviços de entrega ao domicílio, incluindo DPD Portugal Fresh quando contratado.

### Secção Pickup

Use esta secção apenas se o cliente tiver contrato DPD para Pickup/Shop.

A secção Pickup fica protegida por um botão de ativação. Ao ativar, aparece um aviso para confirmar que só deve ser configurada quando existir contrato DPD para esse serviço.

## Aba Dados do expedidor

Configure os dados do expedidor que serão utilizados pela DPD como origem das expedições, recolhas e etiquetas.

Campos principais:

- nome do remetente;
- e-mail do remetente;
- telefone e/ou telemóvel do remetente;
- nome do expedidor;
- morada do expedidor;
- código postal;
- localidade;
- país do expedidor em formato ISO2.

Para Portugal, use:

```text
PT
```

## Aba Operação

Configure:

- peso máximo permitido;
- Predict, se aplicável;
- validade Fresh em dias, quando aplicável;
- número de volumes por defeito;
- formato da etiqueta;
- logs internos.

### DPD Fresh

Quando o serviço DPD Fresh é selecionado numa encomenda, o módulo adiciona ao payload os campos `fresh_pickup_date` e `fresh_expiration_date`.

- `fresh_pickup_date`: calculado automaticamente como o dia útil seguinte.
- `fresh_expiration_date`: calculado a partir da data de recolha com a validade configurada junto da conta DPD Portugal Fresh.

Se o cliente tiver solicitado uma validade inferior, ajuste o campo **Validade Fresh (dias)** antes de criar a expedição.

## Aba Portes

Defina o preço base de cada serviço.

O módulo usa estes preços para apresentar o custo do envio no checkout.

## Aba Diagnóstico

Use esta aba para:

- testar autenticação;
- verificar configuração;
- analisar logs;
- identificar problemas de comunicação com a DPD.

## Depois de qualquer alteração

Depois de alterar configurações importantes:

1. Clique em **Guardar configurações**.
2. Clique em **Reparar transportadoras**.
3. Limpe a cache do PrestaShop.
4. Faça um teste no checkout.
