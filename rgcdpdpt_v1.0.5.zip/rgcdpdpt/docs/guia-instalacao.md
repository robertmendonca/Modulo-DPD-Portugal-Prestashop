# Guia de instalação

Este guia explica como instalar o módulo RGC DPD PT numa loja PrestaShop.

## Antes de começar

Confirme que tem:

- acesso ao backoffice do PrestaShop;
- permissão para instalar módulos;
- ficheiro ZIP do módulo;
- utilizador e password da API fornecidos pela DPD;
- contas DPD de 8 dígitos dos serviços contratados;
- confirmação de contrato Pickup/Shop, caso pretenda usar Pickup.

## Registo técnico de instalação

Durante a instalação, o módulo envia um registo técnico simples para:

```text
https://api.rgcconsulting.pt/dpd/register-install
```

São enviados apenas domínio da loja, data/hora de instalação, versão do módulo, versão do PrestaShop e identificador técnico da instalação.

Não são enviados dados de clientes, encomendas, credenciais DPD, tokens ou etiquetas.

Se a API de registo estiver indisponível, a instalação não é bloqueada.

## Instalar pelo backoffice

1. Entre no backoffice do PrestaShop.
2. Vá a **Módulos > Gestor de módulos**.
3. Clique em **Carregar um módulo**.
4. Selecione o ficheiro ZIP do módulo.
5. Aguarde o upload terminar.
6. Clique em **Instalar**.
7. Abra a configuração do módulo.

## Configurar após instalar

Depois de instalar:

1. Preencha a aba **DPD** com o utilizador e a password da API.
2. Preencha a aba **Contas DPD** com as contas fornecidas pela DPD.
3. Ative a secção **Pickup** apenas se o cliente tiver contrato DPD para Pickup/Shop.
4. Preencha a aba **Dados do expedidor** com os dados da empresa que envia.
5. Configure a aba **Portes** com os preços base.
6. Clique em **Guardar configurações**.
7. Clique em **Reparar transportadoras**.
8. Limpe a cache do PrestaShop.
9. Faça uma encomenda de teste.

## Instalação manual por FTP/SSH

Use esta opção apenas se estiver confortável com FTP/SSH.

1. Extraia o ZIP do módulo.
2. Copie a pasta `rgcdpdpt` para:

```text
/modules/rgcdpdpt
```

3. No backoffice, vá a **Módulos > Gestor de módulos**.
4. Procure por **RGC DPD PT**.
5. Clique em **Instalar**.

## Após atualizar o módulo

Depois de atualizar:

1. Confirme que a versão mudou no backoffice.
2. Clique em **Guardar configurações**.
3. Clique em **Reparar transportadoras**.
4. Limpe a cache do PrestaShop.
5. Teste o checkout.

## Erro comum: métodos DPD não aparecem

Verifique:

- se os serviços estão ativos;
- se as contas DPD estão preenchidas;
- se clicou em **Reparar transportadoras**;
- se a morada de entrega está completa;
- se o produto é físico;
- se o peso está dentro do limite configurado.
