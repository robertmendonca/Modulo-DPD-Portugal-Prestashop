# Contas DPD

A configuração de contas DPD é feita por tipologia de serviço.

Na aba **Contas DPD**, os serviços ficam separados em duas secções:

- **Home**: serviços de entrega ao domicílio.
- **Pickup**: serviços Shop/Pickup. Esta secção fica protegida por um botão de ativação visual e deve ser configurada apenas quando o cliente tiver contrato DPD para Pickup/Shop.


A configuração antiga baseada apenas em **Subconta Home** e **Subconta Pickup** foi removida da configuração ativa. O módulo usa agora uma conta DPD específica para cada serviço.

## Serviços previstos

| Conta de exemplo | Serviço | Tipo | Regra de destino |
|---|---|---|---|
| `09999001` | DPD Portugal Home | Home | Portugal continental |
| `09999002` | DPD Portugal Shop | Pickup/Shop | Portugal continental |
| `09999008` | DPD Portugal Fresh | Fresh | Portugal continental |
| `09999003` | DPD Portugal Ilhas | Home | Madeira e Açores |
| `09999004` | DPD Espanha Home | Home | Espanha |
| `09999005` | DPD Espanha Shop | Pickup/Shop | Espanha |
| `09999006` | DPD Internacional Home | Home | Países diferentes de Portugal e Espanha |
| `09999007` | DPD Internacional Shop | Pickup/Shop | Países diferentes de Portugal e Espanha |

As contas acima são apenas exemplos. Cada cliente deve usar as contas reais fornecidas pela DPD.

## Campos por serviço

Para cada serviço, o módulo permite configurar:

- ativo/inativo;
- conta DPD com 8 dígitos;
- nome visível do carrier;
- preço base do serviço;
- tipo de entrega: Home, Pickup/Shop ou Fresh.

## O que pedir à DPD

Peça à DPD a lista de contas correspondentes aos serviços contratados.

Exemplo de pedido:

```text
Boa tarde,

Preciso configurar o módulo DPD para PrestaShop.

Podem enviar, por favor, as contas DPD de 8 dígitos para os serviços contratados?

Serviços pretendidos:
- Portugal Home
- Portugal Shop/Pickup
- Portugal Fresh
- Portugal Ilhas
- Espanha Home
- Espanha Shop/Pickup
- Internacional Home
- Internacional Shop/Pickup

Obrigado.
```

## Observação importante

Ative apenas serviços contratados e validados pela DPD.

Se um serviço estiver ativo no módulo, mas a conta DPD não tiver permissão para esse serviço, a criação da expedição pode falhar na API.

## DPD Fresh

O serviço **DPD Portugal Fresh** é tratado como uma conta própria. Deve ser ativado apenas se o cliente tiver este serviço contratado com a DPD.

Quando uma encomenda usa DPD Fresh, o módulo adiciona ao payload da API:

- `fresh_pickup_date`, com o dia útil seguinte;
- `fresh_expiration_date`, calculado a partir da data de recolha com o número de dias configurado no campo **Validade Fresh** da conta.
