# Notas de API DPD

Este documento é uma referência técnica curta. Clientes não técnicos normalmente só precisam preencher os campos fornecidos pela DPD no backoffice do módulo.

## OAuth / token

- Endpoint: configurável no backoffice.
- Método: `POST`.
- Content-Type: `application/x-www-form-urlencoded`.
- Campos principais:
  - `username`
  - `password`
  - `client_id`
  - `client_secret`
  - `grant_type=password`

## Criar expedição

- Endpoint: configurável no backoffice.
- Método: `POST`.
- Autenticação: Bearer token.
- Corpo: JSON.

## Criar recolha

- Endpoint: configurável no backoffice.
- Nesta versão, o endpoint pode ser configurado, mas a ação funcional de pedido de recolha ainda não está implementada no backoffice.

## Fecho do dia / manifesto

- Endpoint: configurável no backoffice.
- Nesta versão, o endpoint pode ser configurado, mas a ação funcional de fecho do dia/manifesto ainda não está implementada no backoffice.

## Campos relevantes usados nesta versão

- `sub_account.code`
- `sender`
- `shipper`
- `recipient`
- `address`
- `contact`
- `destinatario_usar_endereco_pickup`
- `recipient_pickup_store.number`
- `pickup_store_name`
- `pickup_store_mobile`
- `pickup_store_mobile_code`
- `pickup_store_email`
- `opcoes_servico_predict_para_entrega`
- `encomenda_referencia`
- `encomenda_observacao`
- `expedition_date`
- `expedition_time`
- `encomenda_peso_envio`
- `encomenda_num_volumes`
- `fresh_pickup_date`, apenas para DPD Fresh
- `fresh_expiration_date`, apenas para DPD Fresh
- `etiqueta_formato.id`
- `pdf_response`

## DPD Fresh

Quando a encomenda usa o serviço **DPD Portugal Fresh**, o módulo adiciona ao corpo JSON da criação de expedição:

```json
{
  "fresh_pickup_date": "yyyy-mm-dd",
  "fresh_expiration_date": "yyyy-mm-dd"
}
```

Regras aplicadas pelo módulo:

- `fresh_pickup_date`: dia útil seguinte à data da expedição.
- `fresh_expiration_date`: data de recolha acrescida do número de dias configurado no campo **Validade Fresh**.

## Pickup webservice

- WSDL: configurável no backoffice.
- Método SOAP: `GetPudoList`.
- Campos mínimos:
  - `carrier`
  - `key`
  - `zipCode`
  - `countrycode`
  - `requestID`
  - `holiday_tolerant`
  - `date_from`

## Checklist para produção

Antes de ativar produção:

- confirmar credenciais LIVE;
- confirmar endpoints LIVE;
- confirmar IP autorizado, se aplicável;
- confirmar contas DPD finais por serviço;
- confirmar chave Pickup/MyPudo;
- validar formato de etiqueta;
- testar uma encomenda controlada;
- confirmar que a etiqueta e a guia são geradas corretamente.

## Segurança

Não coloque credenciais reais neste ficheiro nem em qualquer outro ficheiro do repositório.
