# Suporte

Este módulo é disponibilizado gratuitamente para clientes DPD que utilizam PrestaShop.

## Apoio inicial gratuito

Cada cliente tem direito a **15 minutos gratuitos de apoio inicial pela DPD** para instalação ou primeira configuração do módulo.

Este apoio inicial destina-se a situações simples, como:

- dúvidas sobre onde instalar o módulo;
- validação dos campos principais;
- confirmação se os carriers foram criados;
- orientação básica para o primeiro teste.

## Suporte adicional pago

Após os 15 minutos gratuitos, o suporte técnico adicional é cobrado em packs de:

```text
20 EUR + IVA por pack adicional de 30 minutos
```

O pack de suporte pode ser usado para:

- instalação assistida;
- configuração das contas DPD;
- análise de erros de checkout;
- análise de erros de API;
- validação do fluxo Pickup;
- testes de criação de expedição;
- apoio remoto ao lojista ou equipa técnica.

## O que o cliente deve ter antes de pedir suporte

Para acelerar o atendimento, tenha estes dados disponíveis:

- URL da loja;
- versão do PrestaShop;
- versão do PHP;
- versão do módulo;
- ambiente usado: produção;
- utilizador e password da API já solicitados à DPD;
- contas DPD de 8 dígitos para os serviços contratados;
- erro apresentado no ecrã;
- print da configuração, ocultando passwords e tokens;
- print da encomenda, se o problema ocorrer na criação da expedição.

## O que não deve enviar publicamente

Nunca envie em issues públicas do GitHub:

- password DPD;
- client secret;
- chave Pickup/MyPudo;
- dados pessoais de clientes;
- moradas reais completas;
- etiquetas PDF reais;
- payloads completos com dados pessoais.

Se precisar enviar dados sensíveis, use apenas o canal privado indicado pela equipa de suporte.

## Problemas que geralmente dependem da DPD

Alguns erros não são causados pelo módulo e precisam ser confirmados com a DPD:

- credenciais inválidas;
- IP não autorizado;
- conta DPD sem permissão para Pickup;
- conta DPD incorreta para Espanha ou Internacional;
- serviço contratado diferente do serviço configurado;
- serviços contratados diferentes dos serviços configurados.

## Pedido mínimo de suporte

Ao pedir suporte, use este formato:

```text
Loja: https://exemplo.pt
PrestaShop: 8.x
PHP: 8.x
Módulo: 1.0.0
Ambiente: QA ou produção
Serviço DPD usado: Portugal Home / Portugal Shop / Ilhas / Espanha / Internacional
Erro apresentado:
Passos para reproduzir:
```
