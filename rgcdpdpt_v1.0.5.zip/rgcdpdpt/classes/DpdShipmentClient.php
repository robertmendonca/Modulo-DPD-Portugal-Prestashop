<?php
class DpdShipmentClient
{
    public function createShipment(array $payload)
    {
        $token = (new DpdAuthClient())->getAccessToken();
        $url = trim((string) DpdConfig::get('SHIPMENT_URL'));
        if ($url === '') {
            throw new Exception('Shipment URL not configured.');
        }

        $ch = curl_init($url);
        $body = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_CONNECTTIMEOUT => 20,
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_USERAGENT => 'RGC-DPD-PT-Prestashop/' . (defined('_PS_VERSION_') ? _PS_VERSION_ : 'unknown'),
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $token,
                'Content-Type: application/json',
                'Accept: application/json',
                'Connection: close',
                'Expect:',
            ],
        ]);

        $raw = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($errno) {
            DpdLogRepository::add('error', 'DPD shipment curl error', 'shipment', 0, [
                'curl_errno' => (int) $errno,
                'curl_error' => $error,
                'http_status' => $status,
            ]);

            throw new Exception('DPD shipment curl error [' . (int) $errno . ']: ' . $error);
        }

        $decoded = json_decode((string) $raw, true);
        if (!is_array($decoded)) {
            DpdLogRepository::add('error', 'DPD shipment invalid JSON response', 'shipment', 0, [
                'http_status' => $status,
                'sub_account' => $payload['sub_account']['code'] ?? '',
                'reference' => $payload['encomenda_referencia'] ?? '',
                'destination_country' => $payload['address']['country']['iso2'] ?? ($payload['address']['country']['id'] ?? ''),
                'destination_zip' => $payload['address']['zip_code'] ?? '',
                'raw_preview' => Tools::substr((string) $raw, 0, 1200),
            ]);

            throw new Exception('DPD shipment invalid JSON response. HTTP ' . $status . '. Raw: ' . Tools::substr((string) $raw, 0, 500));
        }

        $dpdStatusCode = isset($decoded['status_code']) ? (int) $decoded['status_code'] : null;
        $dpdMessage = isset($decoded['message']) && is_scalar($decoded['message']) ? (string) $decoded['message'] : '';
        $level = ($status >= 400 || ($dpdStatusCode !== null && ($dpdStatusCode < 200 || $dpdStatusCode >= 300))) ? 'warning' : 'info';

        DpdLogRepository::add($level, 'Shipment request executed', 'shipment', 0, [
            'http_status' => $status,
            'dpd_status_code' => $dpdStatusCode,
            'dpd_message' => $dpdMessage,
            'sub_account' => $payload['sub_account']['code'] ?? '',
            'reference' => $payload['encomenda_referencia'] ?? '',
            'destination_country' => $payload['address']['country']['iso2'] ?? ($payload['address']['country']['id'] ?? ''),
            'destination_zip' => $payload['address']['zip_code'] ?? '',
            'response_preview' => Tools::substr(json_encode($this->sanitizeResponseForLog($decoded), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), 0, 1200),
        ]);

        return $decoded;
    }

    protected function sanitizeResponseForLog($value)
    {
        if (!is_array($value)) {
            return $value;
        }

        $sanitized = [];
        foreach ($value as $key => $item) {
            $normalizedKey = Tools::strtolower(preg_replace('/[^a-zA-Z0-9]/', '', (string) $key));
            if (in_array($normalizedKey, ['pdf', 'labelpdf', 'etiquetapdf', 'zpl', 'qr', 'qrcode'], true)) {
                $sanitized[$key] = '[conteúdo da etiqueta omitido]';
                continue;
            }

            if (in_array($normalizedKey, ['password', 'clientsecret', 'accesstoken', 'refreshtoken', 'token', 'authorization'], true)) {
                $sanitized[$key] = '[omitido]';
                continue;
            }

            $sanitized[$key] = is_array($item) ? $this->sanitizeResponseForLog($item) : $item;
        }

        return $sanitized;
    }
}
