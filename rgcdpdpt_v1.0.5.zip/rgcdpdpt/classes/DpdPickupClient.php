<?php
class DpdPickupClient
{
    public function search($zipCode, $countryCode = 'PRT', $address = '', $city = '?')
    {
        $zipCode = $this->normalizeZipCode($zipCode);
        $countryCode = strtoupper(trim((string) $countryCode));
        $address = $this->normalizeText($address);
        $city = $this->normalizeText($city);
        if ($city === '') {
            $city = '?';
        }

        $wsdl = trim((string) DpdConfig::get('PICKUP_WSDL'));
        if ($wsdl === '') {
            throw new Exception('Pickup WSDL not configured.');
        }

        $params = [
            'carrier' => DpdConfig::get('PICKUP_CARRIER', 'CHR'),
            'key' => DpdConfig::get('PICKUP_KEY'),
            'address' => $address,
            'zipCode' => $zipCode,
            'city' => $city,
            'countrycode' => $countryCode ?: 'PRT',
            'requestID' => 'PS_' . date('YmdHis'),
            'date_from' => date('d/m/Y'),
            'max_pudo_number' => DpdConfig::get('PICKUP_MAX_POINTS', '10'),
            'max_distance_search' => DpdConfig::get('PICKUP_MAX_DISTANCE', '20'),
            'weight' => '',
            'category' => '',
            'holiday_tolerant' => '0',
        ];

        $method = class_exists('SoapClient') ? 'soap' : 'curl';
        $result = $method === 'soap'
            ? $this->callViaSoapClient($wsdl, $params)
            : $this->callViaCurl($wsdl, $params);

        $items = $this->normalizeResult($result);
        $items = $this->prioritizePostcodeMatches($items, $zipCode);

        DpdLogRepository::add('info', 'Pickup lookup executed', 'pickup', 0, [
            'zip' => $zipCode,
            'country' => $countryCode ?: 'PRT',
            'address' => $address,
            'city' => $city,
            'method' => $method,
            'count' => count($items),
        ]);

        if (!count($items)) {
            DpdLogRepository::add('warning', 'Pickup lookup returned no normalized points', 'pickup', 0, [
                'zip' => $zipCode,
                'country' => $countryCode ?: 'PRT',
                'address' => $address,
                'city' => $city,
                'method' => $method,
                'preview' => $this->previewResult($result),
            ]);
        }

        return $items;
    }

    protected function normalizeZipCode($zipCode)
    {
        $zipCode = strtoupper(trim((string) $zipCode));
        $zipCode = preg_replace('/\s+/', '', $zipCode);

        if (preg_match('/^([0-9]{4})([0-9]{3})$/', $zipCode, $matches)) {
            return $matches[1] . '-' . $matches[2];
        }

        return $zipCode;
    }

    protected function normalizeText($value)
    {
        $value = trim((string) $value);
        $value = preg_replace('/\s+/', ' ', $value);

        return $value;
    }

    protected function callViaSoapClient($wsdl, array $params)
    {
        $client = new SoapClient($wsdl, [
            'trace' => false,
            'exceptions' => true,
            'cache_wsdl' => WSDL_CACHE_MEMORY,
            'connection_timeout' => 20,
            'soap_version' => SOAP_1_2,
        ]);

        return $client->__soapCall('GetPudoList', [$params]);
    }

    protected function callViaCurl($wsdl, array $params)
    {
        if (!function_exists('curl_init')) {
            throw new Exception('DPD pickup lookup requires PHP SOAP extension or PHP cURL extension.');
        }

        $endpoint = $this->wsdlToEndpoint($wsdl);
        $body = $this->buildSoapEnvelope($params);

        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => false,
            CURLOPT_CONNECTTIMEOUT => 20,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_USERAGENT => 'RGC-DPD-PT-Prestashop/' . (defined('_PS_VERSION_') ? _PS_VERSION_ : 'unknown'),
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/soap+xml; charset=utf-8; action="http://MyPudo.pickup-services.com/GetPudoList"',
                'Accept: application/soap+xml, text/xml, */*',
                'Content-Length: ' . strlen($body),
                'Connection: close',
                'Expect:',
            ],
        ]);

        $response = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $statusCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response === false || $errno) {
            throw new Exception('DPD pickup cURL error [' . (int) $errno . ']: ' . $error);
        }

        if ($statusCode < 200 || $statusCode >= 300) {
            throw new Exception('DPD pickup HTTP error ' . $statusCode . ': ' . Tools::substr(trim(strip_tags($response)), 0, 250));
        }

        return $response;
    }

    protected function wsdlToEndpoint($wsdl)
    {
        $parts = parse_url($wsdl);
        if (!$parts || empty($parts['scheme']) || empty($parts['host'])) {
            return str_replace('?wsdl', '', $wsdl);
        }

        $endpoint = $parts['scheme'] . '://' . $parts['host'];
        if (!empty($parts['port'])) {
            $endpoint .= ':' . $parts['port'];
        }
        $endpoint .= isset($parts['path']) ? $parts['path'] : '';

        return $endpoint;
    }

    protected function buildSoapEnvelope(array $params)
    {
        $xml = [];
        foreach ($params as $name => $value) {
            $xml[] = '<myp:' . $name . '>' . $this->xmlEscape((string) $value) . '</myp:' . $name . '>';
        }

        return '<?xml version="1.0" encoding="utf-8"?>'
            . '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:myp="http://MyPudo.pickup-services.com/">'
            . '<soap:Header/>'
            . '<soap:Body>'
            . '<myp:GetPudoList>' . implode('', $xml) . '</myp:GetPudoList>'
            . '</soap:Body>'
            . '</soap:Envelope>';
    }

    protected function xmlEscape($value)
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }

    protected function normalizeResult($result)
    {
        $items = [];

        if (is_string($result)) {
            $flat = $this->extractPudoItemsFromXml($result);
            if (!$flat) {
                $array = $this->toArray($result);
                $array = $this->parseEmbeddedXmlStrings($array);
                $flat = $this->flattenCandidates($array);
            }
        } else {
            $array = $this->toArray($result);
            if (!$array) {
                return $items;
            }

            $array = $this->parseEmbeddedXmlStrings($array);
            $flat = $this->flattenCandidates($array);
        }

        foreach ($flat as $item) {
            $number = $this->pickValue($item, ['number', 'pudo_id', 'pudoid', 'pudo', 'id', 'code']);
            if (!$number) {
                continue;
            }

            $address1 = $this->pickValue($item, ['address1', 'address_1', 'address', 'street']);
            $address2 = $this->pickValue($item, ['address2', 'address_2']);
            $address = trim((string) $address1 . ($address2 ? ' ' . $address2 : ''));

            $latitude = $this->normalizeCoordinate($this->pickValue($item, ['latitude', 'lat', 'gps_latitude', 'gpslat', 'geo_lat', 'coord_y', 'coordinate_y', 'gps_y', 'pudo_gps_y', 'y']));
            $longitude = $this->normalizeCoordinate($this->pickValue($item, ['longitude', 'lon', 'lng', 'gps_longitude', 'gpslongitude', 'gpslon', 'geo_lng', 'geo_lon', 'coord_x', 'coordinate_x', 'gps_x', 'pudo_gps_x', 'x']));

            $items[] = [
                'code' => (string) $number,
                'name' => (string) ($this->pickValue($item, ['name', 'company', 'company_name']) ?: 'DPD Pickup'),
                'address' => $address,
                'zip' => (string) $this->pickValue($item, ['zipcode', 'zip_code', 'zipCode', 'zip', 'postalcode', 'postal_code']),
                'city' => (string) $this->pickValue($item, ['city', 'locality', 'location']),
                'country' => (string) ($this->pickValue($item, ['countrycode', 'country_code', 'country']) ?: 'PRT'),
                'latitude' => $latitude,
                'longitude' => $longitude,
                'distance' => $this->normalizeDistance($this->pickValue($item, ['distance', 'dist', 'km', 'distance_km', 'distancekm', 'distance_in_km'])),
                'raw' => $item,
            ];
        }

        return $items;
    }

    protected function prioritizePostcodeMatches(array $items, $requestedZipCode)
    {
        $requestedDigits = $this->postcodeDigits($requestedZipCode);
        if (strlen($requestedDigits) < 7 || !count($items)) {
            return $this->sortByDistanceIfAvailable($items);
        }

        return $this->sortByPostcodeProximity($items, $requestedDigits);
    }

    /**
     * MyPudo sometimes returns a distance that is based on a broad postal area,
     * not the exact Portuguese postcode the customer typed. For Pickup selection
     * we therefore prefer the closest postal code first and use MyPudo distance
     * only as a tie breaker.
     */
    protected function sortByPostcodeProximity(array $items, $requestedDigits)
    {
        $hasAnyPostcode = false;

        foreach ($items as $index => $item) {
            $shopDigits = $this->postcodeDigits(isset($item['zip']) ? $item['zip'] : '');
            if (strlen($shopDigits) >= 7) {
                $hasAnyPostcode = true;
            }

            $score = $this->postcodeProximityScore($requestedDigits, $shopDigits);
            $items[$index]['_rgcdpdpt_postcode_group'] = $score['group'];
            $items[$index]['_rgcdpdpt_postcode_diff'] = $score['diff'];
            $items[$index]['_rgcdpdpt_original_index'] = $index;
        }

        if (!$hasAnyPostcode) {
            return $this->sortByDistanceIfAvailable($items);
        }

        usort($items, function ($a, $b) {
            $ag = isset($a['_rgcdpdpt_postcode_group']) ? (int) $a['_rgcdpdpt_postcode_group'] : 9;
            $bg = isset($b['_rgcdpdpt_postcode_group']) ? (int) $b['_rgcdpdpt_postcode_group'] : 9;
            if ($ag !== $bg) {
                return ($ag < $bg) ? -1 : 1;
            }

            $adiff = isset($a['_rgcdpdpt_postcode_diff']) ? (int) $a['_rgcdpdpt_postcode_diff'] : PHP_INT_MAX;
            $bdiff = isset($b['_rgcdpdpt_postcode_diff']) ? (int) $b['_rgcdpdpt_postcode_diff'] : PHP_INT_MAX;
            if ($adiff !== $bdiff) {
                return ($adiff < $bdiff) ? -1 : 1;
            }

            $ad = (isset($a['distance']) && $a['distance'] !== '' && is_numeric($a['distance'])) ? (float) $a['distance'] : PHP_FLOAT_MAX;
            $bd = (isset($b['distance']) && $b['distance'] !== '' && is_numeric($b['distance'])) ? (float) $b['distance'] : PHP_FLOAT_MAX;
            if ($ad !== $bd) {
                return ($ad < $bd) ? -1 : 1;
            }

            $ai = isset($a['_rgcdpdpt_original_index']) ? (int) $a['_rgcdpdpt_original_index'] : 0;
            $bi = isset($b['_rgcdpdpt_original_index']) ? (int) $b['_rgcdpdpt_original_index'] : 0;

            return $ai <=> $bi;
        });

        foreach ($items as $index => $item) {
            unset($items[$index]['_rgcdpdpt_postcode_group'], $items[$index]['_rgcdpdpt_postcode_diff'], $items[$index]['_rgcdpdpt_original_index']);
        }

        return $items;
    }

    protected function postcodeProximityScore($requestedDigits, $shopDigits)
    {
        if (strlen($shopDigits) < 7) {
            return ['group' => 9, 'diff' => PHP_INT_MAX];
        }

        $requestedDigits = substr($requestedDigits, 0, 7);
        $shopDigits = substr($shopDigits, 0, 7);

        if ($shopDigits === $requestedDigits) {
            return ['group' => 0, 'diff' => 0];
        }

        $requestedNumber = (int) $requestedDigits;
        $shopNumber = (int) $shopDigits;
        $fullDiff = abs($requestedNumber - $shopNumber);

        if (substr($shopDigits, 0, 4) === substr($requestedDigits, 0, 4)) {
            return ['group' => 1, 'diff' => abs((int) substr($requestedDigits, 4, 3) - (int) substr($shopDigits, 4, 3))];
        }

        if (substr($shopDigits, 0, 3) === substr($requestedDigits, 0, 3)) {
            return ['group' => 2, 'diff' => $fullDiff];
        }

        if (substr($shopDigits, 0, 2) === substr($requestedDigits, 0, 2)) {
            return ['group' => 3, 'diff' => $fullDiff];
        }

        return ['group' => 4, 'diff' => $fullDiff];
    }

    protected function sortByDistanceIfAvailable(array $items)
    {

        $hasDistance = false;
        foreach ($items as $item) {
            if (isset($item['distance']) && $item['distance'] !== '' && is_numeric($item['distance'])) {
                $hasDistance = true;
                break;
            }
        }

        if (!$hasDistance) {
            return $items;
        }

        usort($items, function ($a, $b) {
            $ad = (isset($a['distance']) && $a['distance'] !== '' && is_numeric($a['distance'])) ? (float) $a['distance'] : PHP_FLOAT_MAX;
            $bd = (isset($b['distance']) && $b['distance'] !== '' && is_numeric($b['distance'])) ? (float) $b['distance'] : PHP_FLOAT_MAX;

            if ($ad === $bd) {
                return 0;
            }

            return ($ad < $bd) ? -1 : 1;
        });

        return $items;
    }

    protected function postcodeDigits($postcode)
    {
        return preg_replace('/[^0-9]/', '', (string) $postcode);
    }

    protected function normalizeCoordinate($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }

        $value = str_replace(',', '.', $value);
        $value = preg_replace('/[^0-9.\-]/', '', $value);

        if ($value === '' || !is_numeric($value)) {
            return '';
        }

        return (string) (float) $value;
    }

    protected function normalizeDistance($value)
    {
        $original = trim((string) $value);
        if ($original === '') {
            return '';
        }

        $lower = strtolower($original);
        $normalized = str_replace(',', '.', $original);
        $normalized = preg_replace('/[^0-9.\-]/', '', $normalized);

        if ($normalized === '' || !is_numeric($normalized)) {
            return '';
        }

        $distance = (float) $normalized;

        // MyPudo often returns distance in metres even when max_distance_search is in km.
        // Example: 721 means 721 m, not 721 km. Normalize everything to kilometres
        // so sorting and display are coherent in the front office.
        if (strpos($lower, 'km') === false && (strpos($lower, 'm') !== false || $distance > 100)) {
            $distance = $distance / 1000;
        }

        return rtrim(rtrim(number_format($distance, 3, '.', ''), '0'), '.');
    }

    protected function previewResult($result)
    {
        if (is_string($result)) {
            $preview = $result;
        } else {
            $preview = json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }

        $preview = trim(strip_tags((string) $preview));
        $preview = preg_replace('/\s+/', ' ', $preview);

        return Tools::substr($preview, 0, 800);
    }

    protected function toArray($result)
    {
        if (is_string($result)) {
            $parsed = $this->xmlStringToArray($result);
            if ($parsed) {
                return $parsed;
            }

            $json = json_decode($result, true);
            return is_array($json) ? $json : [];
        }

        $json = json_encode($result);
        if ($json === false) {
            return [];
        }

        $array = json_decode($json, true);
        return is_array($array) ? $array : [];
    }

    protected function xmlStringToArray($xml)
    {
        $xml = trim($xml);
        if ($xml === '' || $xml[0] !== '<' || !function_exists('simplexml_load_string')) {
            return [];
        }

        $previous = libxml_use_internal_errors(true);
        $simpleXml = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA);
        libxml_clear_errors();
        libxml_use_internal_errors($previous);

        if (!$simpleXml) {
            return [];
        }

        $json = json_encode($simpleXml);
        $array = json_decode($json, true);

        return is_array($array) ? $array : [];
    }

    protected function extractPudoItemsFromXml($xml)
    {
        $xml = html_entity_decode((string) $xml, ENT_QUOTES | ENT_XML1, 'UTF-8');
        $items = [];

        $patterns = [
            '/<((?:[a-zA-Z0-9_-]+:)?PUDO_ITEM)\b[^>]*>(.*?)<\/\1>/is',
            '/<((?:[a-zA-Z0-9_-]+:)?PUDO)\b[^>]*>(.*?)<\/\1>/is',
            '/<((?:[a-zA-Z0-9_-]+:)?POINT)\b[^>]*>(.*?)<\/\1>/is',
            '/<((?:[a-zA-Z0-9_-]+:)?item)\b[^>]*>(.*?)<\/\1>/is',
        ];

        $matchedItems = [];
        foreach ($patterns as $pattern) {
            if (preg_match_all($pattern, $xml, $matches) && !empty($matches[2])) {
                $matchedItems = array_merge($matchedItems, $matches[2]);
            }
        }

        if (!$matchedItems) {
            return $items;
        }

        foreach ($matchedItems as $itemXml) {
            $item = [];
            if (preg_match_all('/<([a-zA-Z0-9:_-]+)\b[^>]*>(.*?)<\/\1>/is', $itemXml, $fields, PREG_SET_ORDER)) {
                foreach ($fields as $field) {
                    $key = preg_replace('/^.*:/', '', $field[1]);
                    $value = trim(html_entity_decode(strip_tags($field[2]), ENT_QUOTES | ENT_XML1, 'UTF-8'));
                    if ($key !== '' && $value !== '') {
                        $item[$key] = $value;
                    }
                }
            }

            if ($item) {
                $items[] = $item;
            }
        }

        return $items;
    }

    protected function parseEmbeddedXmlStrings($data)
    {
        if (is_array($data)) {
            foreach ($data as $key => $value) {
                $data[$key] = $this->parseEmbeddedXmlStrings($value);
            }
            return $data;
        }

        if (is_string($data)) {
            $decoded = html_entity_decode(trim($data), ENT_QUOTES | ENT_XML1, 'UTF-8');
            if ($decoded !== '' && $decoded[0] === '<') {
                $parsed = $this->xmlStringToArray($decoded);
                return $parsed ?: $data;
            }
        }

        return $data;
    }

    protected function flattenCandidates($data)
    {
        $output = [];
        if (!is_array($data)) {
            return $output;
        }

        if ($this->hasAnyKey($data, ['number', 'pudo_id', 'pudoid', 'pudo', 'id', 'code'])) {
            $output[] = $data;
            return $output;
        }

        foreach ($data as $value) {
            if (is_array($value)) {
                $output = array_merge($output, $this->flattenCandidates($value));
            }
        }

        return $output;
    }

    protected function hasAnyKey(array $data, array $keys)
    {
        $normalized = [];
        foreach (array_keys($data) as $key) {
            $normalized[$this->normalizeKey($key)] = true;
        }

        foreach ($keys as $key) {
            if (isset($normalized[$this->normalizeKey($key)])) {
                return true;
            }
        }

        return false;
    }

    protected function pickValue(array $data, array $keys)
    {
        $map = [];
        foreach ($data as $key => $value) {
            $map[$this->normalizeKey($key)] = $value;
        }

        foreach ($keys as $key) {
            $normalized = $this->normalizeKey($key);
            if (array_key_exists($normalized, $map) && $map[$normalized] !== null && $map[$normalized] !== '') {
                return is_array($map[$normalized]) ? '' : $map[$normalized];
            }
        }

        return '';
    }

    protected function normalizeKey($key)
    {
        return strtolower(str_replace(['_', '-', ' '], '', (string) $key));
    }
}
