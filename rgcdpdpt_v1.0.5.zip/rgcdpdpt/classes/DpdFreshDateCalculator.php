<?php
class DpdFreshDateCalculator
{
    /**
     * Calculates the expedition, next business pickup and Fresh expiration dates.
     * The expiration is counted from the pickup date, as required by DPD Fresh.
     *
     * @param string|null $baseDate Date in Y-m-d format. Null means today.
     * @param int $validityDays Number of calendar days after pickup.
     * @param string|null $timezoneName IANA timezone. Null uses the shop timezone.
     *
     * @return array{expedition_date:string,pickup_date:string,expiration_date:string}
     */
    public static function calculate($baseDate = null, $validityDays = 5, $timezoneName = null)
    {
        $timezone = self::timezone($timezoneName);
        $expedition = self::date($baseDate, $timezone);
        $pickup = self::nextBusinessDay($expedition);

        $days = (int) $validityDays;
        if ($days < 1) {
            $days = 5;
        }
        $days = min($days, 365);

        $expiration = $pickup->modify('+' . $days . ' days');

        return [
            'expedition_date' => $expedition->format('Y-m-d'),
            'pickup_date' => $pickup->format('Y-m-d'),
            'expiration_date' => $expiration->format('Y-m-d'),
        ];
    }

    protected static function nextBusinessDay(DateTimeImmutable $date)
    {
        $candidate = $date->modify('+1 day');

        while (!self::isBusinessDay($candidate)) {
            $candidate = $candidate->modify('+1 day');
        }

        return $candidate;
    }

    protected static function isBusinessDay(DateTimeImmutable $date)
    {
        $weekday = (int) $date->format('N');
        if ($weekday >= 6) {
            return false;
        }

        return !in_array($date->format('Y-m-d'), self::portugalNationalHolidays((int) $date->format('Y'), $date->getTimezone()), true);
    }

    protected static function portugalNationalHolidays($year, DateTimeZone $timezone)
    {
        $fixed = [
            '01-01',
            '04-25',
            '05-01',
            '06-10',
            '08-15',
            '10-05',
            '11-01',
            '12-01',
            '12-08',
            '12-25',
        ];

        $holidays = [];
        foreach ($fixed as $monthDay) {
            $holidays[] = sprintf('%04d-%s', (int) $year, $monthDay);
        }

        $easter = self::easterSunday((int) $year, $timezone);
        $holidays[] = $easter->modify('-2 days')->format('Y-m-d'); // Sexta-feira Santa
        $holidays[] = $easter->modify('+60 days')->format('Y-m-d'); // Corpo de Deus

        return $holidays;
    }

    protected static function easterSunday($year, DateTimeZone $timezone)
    {
        // Meeus/Jones/Butcher Gregorian algorithm.
        $a = $year % 19;
        $b = intdiv($year, 100);
        $c = $year % 100;
        $d = intdiv($b, 4);
        $e = $b % 4;
        $f = intdiv($b + 8, 25);
        $g = intdiv($b - $f + 1, 3);
        $h = (19 * $a + $b - $d - $g + 15) % 30;
        $i = intdiv($c, 4);
        $k = $c % 4;
        $l = (32 + 2 * $e + 2 * $i - $h - $k) % 7;
        $m = intdiv($a + 11 * $h + 22 * $l, 451);
        $month = intdiv($h + $l - 7 * $m + 114, 31);
        $day = (($h + $l - 7 * $m + 114) % 31) + 1;

        return new DateTimeImmutable(sprintf('%04d-%02d-%02d', $year, $month, $day), $timezone);
    }

    protected static function date($baseDate, DateTimeZone $timezone)
    {
        if ($baseDate === null || trim((string) $baseDate) === '') {
            return new DateTimeImmutable('today', $timezone);
        }

        $date = DateTimeImmutable::createFromFormat('!Y-m-d', (string) $baseDate, $timezone);
        if (!$date) {
            throw new InvalidArgumentException('Data Fresh inválida. Utilize o formato Y-m-d.');
        }

        return $date;
    }

    protected static function timezone($timezoneName = null)
    {
        $name = trim((string) $timezoneName);
        if ($name === '' && class_exists('Configuration')) {
            $name = trim((string) Configuration::get('PS_TIMEZONE'));
        }
        if ($name === '') {
            $name = 'Europe/Lisbon';
        }

        try {
            return new DateTimeZone($name);
        } catch (Exception $e) {
            return new DateTimeZone('Europe/Lisbon');
        }
    }
}
