<?php
class DpdSchema
{
    public static function install()
    {
        return (bool) require dirname(__DIR__) . '/sql/install.php';
    }

    public static function uninstall()
    {
        return (bool) require dirname(__DIR__) . '/sql/uninstall.php';
    }

    public static function tableName($name)
    {
        return _DB_PREFIX_ . ltrim((string) $name, '_');
    }

    public static function hasTable($name)
    {
        $table = pSQL(self::tableName($name));
        $sql = "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '" . $table . "'";

        try {
            return (bool) Db::getInstance()->getValue($sql);
        } catch (Exception $e) {
            return false;
        }
    }
}
