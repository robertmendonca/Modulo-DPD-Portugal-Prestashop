<?php
class DpdAuthClient
{
    public function getAccessToken()
    {
        DpdConfig::ensureInternalOAuthCredentials();

        $url = trim((string) DpdConfig::get('OAUTH_URL'));
        if ($url === '') {
            throw new Exception('OAuth URL not configured.');
        }

        $params = [
            'username' => trim((string) DpdConfig::get('API_USERNAME')),
            'password' => (string) DpdConfig::get('API_PASSWORD'),
            'client_id' => trim((string) DpdConfig::get('CLIENT_ID')),
            'client_secret' => trim((string) DpdConfig::get('CLIENT_SECRET')),
            'grant_type' => 'password',
        ];

        foreach (['username', 'password', 'client_id', 'client_secret'] as $required) {
            if ($params[$required] === '') {
                throw new Exception('DPD OAuth missing required configuration: ' . $required . '.');
            }
        }

        $body = http_build_query($params, '', '&', PHP_QUERY_RFC1738);

        $response = $this->request($url, $body, [
            'Content-Type: application/x-www-form-urlencoded',
            'Accept: application/json',
            'Connection: close',
            'Expect:',
        ]);

        $token = $this->extractAccessToken($response['decoded']);
        if ($token === '') {
            $message = 'DPD token response did not include access_token. HTTP ' . (int) $response['status'] . '.';
            $details = $this->extractErrorMessage($response['decoded']);
            if ($details !== '') {
                $message .= ' DPD response: ' . $details;
            }
            $message .= ' Check credentials, client_id/client_secret, environment URL and DPD IP whitelist.';

            DpdLogRepository::add('error', $message, 'oauth', 0, [
                'http_status' => (int) $response['status'],
                'response' => $this->sanitizeResponse($response['decoded']),
            ]);

            throw new Exception($message);
        }

        DpdLogRepository::add('info', 'OAuth token received', 'oauth', 0, [
            'http_status' => (int) $response['status'],
            'token_type' => isset($response['decoded']['token_type']) ? $response['decoded']['token_type'] : null,
            'expires_in' => isset($response['decoded']['expires_in']) ? $response['decoded']['expires_in'] : null,
        ]);

        return $token;
    }

    protected function request($url, $body, array $headers)
    {
        if (!function_exists('curl_init')) {
            throw new Exception('PHP cURL extension is required for DPD OAuth.');
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_USERAGENT => 'RGC-DPD-PT-Prestashop/' . (defined('_PS_VERSION_') ? _PS_VERSION_ : 'unknown'),
        ]);

        $raw = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($errno) {
            DpdLogRepository::add('error', 'DPD OAuth curl error', 'oauth', 0, [
                'curl_errno' => (int) $errno,
                'curl_error' => $error,
                'http_status' => $status,
            ]);

            throw new Exception('DPD OAuth curl error [' . (int) $errno . ']: ' . $error);
        }

        $decoded = json_decode((string) $raw, true);
        if (!is_array($decoded)) {
            $preview = Tools::substr(trim((string) $raw), 0, 500);
            DpdLogRepository::add('error', 'DPD OAuth invalid JSON response', 'oauth', 0, [
                'http_status' => $status,
                'raw_preview' => $preview,
            ]);
            throw new Exception('DPD OAuth invalid JSON response. HTTP ' . $status . '. Raw: ' . $preview);
        }

        if ($status >= 400) {
            $message = 'DPD OAuth HTTP ' . $status . '.';
            $details = $this->extractErrorMessage($decoded);
            if ($details !== '') {
                $message .= ' DPD response: ' . $details;
            }

            DpdLogRepository::add('error', $message, 'oauth', 0, [
                'http_status' => $status,
                'response' => $this->sanitizeResponse($decoded),
            ]);

            throw new Exception($message . ' Check credentials, client_id/client_secret, environment URL and DPD IP whitelist.');
        }

        return [
            'status' => $status,
            'decoded' => $decoded,
        ];
    }

    protected function extractAccessToken(array $decoded)
    {
        $candidates = [
            $decoded['access_token'] ?? null,
            $decoded['accessToken'] ?? null,
            $decoded['token'] ?? null,
            $decoded['result']['access_token'] ?? null,
            $decoded['data']['access_token'] ?? null,
        ];

        foreach ($candidates as $candidate) {
            $candidate = trim((string) $candidate);
            if ($candidate !== '') {
                return $candidate;
            }
        }

        return '';
    }

    protected function extractErrorMessage(array $decoded)
    {
        $parts = [];
        foreach (['error', 'error_description', 'message', 'detail', 'title', 'Message'] as $key) {
            if (isset($decoded[$key]) && $decoded[$key] !== '') {
                $parts[] = $key . '=' . (is_scalar($decoded[$key]) ? (string) $decoded[$key] : json_encode($decoded[$key]));
            }
        }

        if (isset($decoded['errors']) && $decoded['errors']) {
            $parts[] = 'errors=' . json_encode($decoded['errors'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }

        if (!$parts && isset($decoded['status_code'])) {
            $parts[] = 'status_code=' . (string) $decoded['status_code'];
        }

        return Tools::substr(implode('; ', $parts), 0, 500);
    }

    protected function sanitizeResponse(array $decoded)
    {
        foreach (['access_token', 'accessToken', 'refresh_token', 'token'] as $key) {
            if (isset($decoded[$key])) {
                $decoded[$key] = '[hidden]';
            }
        }

        if (isset($decoded['result']) && is_array($decoded['result'])) {
            foreach (['access_token', 'accessToken', 'refresh_token', 'token'] as $key) {
                if (isset($decoded['result'][$key])) {
                    $decoded['result'][$key] = '[hidden]';
                }
            }
        }

        if (isset($decoded['data']) && is_array($decoded['data'])) {
            foreach (['access_token', 'accessToken', 'refresh_token', 'token'] as $key) {
                if (isset($decoded['data'][$key])) {
                    $decoded['data'][$key] = '[hidden]';
                }
            }
        }

        return $decoded;
    }
}
