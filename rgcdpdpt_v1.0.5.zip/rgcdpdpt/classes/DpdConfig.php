<?php
class DpdConfig
{
    public const PREFIX = 'RGCDPDPT_';
    public const DEFAULT_CLIENT_ID = '2';
    public const DEFAULT_CLIENT_SECRET = 'rczLIC19WQd4p7wCeQHejNCvBtyJRKgVMvTA34Li';

    public static function serviceDefinitions()
    {
        return [
            'home' => [
                'label' => 'DPD Portugal Home',
                'delivery' => 'home',
                'default_account' => '09999001',
                'default_name' => 'DPD Portugal Home',
                'default_enabled' => '1',
                'default_rate' => '0',
            ],
            'pickup' => [
                'label' => 'DPD Portugal Shop',
                'delivery' => 'pickup',
                'default_account' => '09999002',
                'default_name' => 'DPD Portugal Shop',
                'default_enabled' => '1',
                'default_rate' => '0',
            ],
            'pt_fresh' => [
                'label' => 'DPD Portugal Fresh',
                'delivery' => 'home',
                'default_account' => '09999008',
                'default_name' => 'DPD Portugal Fresh',
                'default_enabled' => '0',
                'default_rate' => '0',
            ],
            'pt_islands' => [
                'label' => 'DPD Portugal Ilhas',
                'delivery' => 'home',
                'default_account' => '09999003',
                'default_name' => 'DPD Portugal Ilhas',
                'default_enabled' => '1',
                'default_rate' => '0',
            ],
            'es_home' => [
                'label' => 'DPD Espanha Home',
                'delivery' => 'home',
                'default_account' => '09999004',
                'default_name' => 'DPD Espanha Home',
                'default_enabled' => '1',
                'default_rate' => '0',
            ],
            'es_pickup' => [
                'label' => 'DPD Espanha Shop',
                'delivery' => 'pickup',
                'default_account' => '09999005',
                'default_name' => 'DPD Espanha Shop',
                'default_enabled' => '1',
                'default_rate' => '0',
            ],
            'int_home' => [
                'label' => 'DPD Internacional Home',
                'delivery' => 'home',
                'default_account' => '09999006',
                'default_name' => 'DPD Internacional Home',
                'default_enabled' => '1',
                'default_rate' => '0',
            ],
            'int_pickup' => [
                'label' => 'DPD Internacional Shop',
                'delivery' => 'pickup',
                'default_account' => '09999007',
                'default_name' => 'DPD Internacional Shop',
                'default_enabled' => '1',
                'default_rate' => '0',
            ],
        ];
    }

    public static function definitions()
    {
        $definitions = [
            'MODE' => 'live',
            'OAUTH_URL' => 'https://business.dpd.pt/api/v1/pt/oauth/token',
            'SHIPMENT_URL' => 'https://business.dpd.pt/api/v1/pt/expedition/registarExpedicao',
            'COLLECT_URL' => 'https://business.dpd.pt/api/v1/pt/collect',
            'MANIFEST_URL' => 'https://business.dpd.pt/api/v1/pt/expedition/fechoApi',
            'PICKUP_WSDL' => 'http://mypudo.pickup-services.com/mypudo/mypudo.asmx?wsdl',
            'PICKUP_CARRIER' => 'CHR',
            'PICKUP_KEY' => '',
            'PICKUP_MAX_POINTS' => '10',
            'PICKUP_MAX_DISTANCE' => '20',
            'PICKUP_CONFIG_OPEN' => '0',
            'INSTALL_REPORT_ENDPOINT' => 'https://api.rgcconsulting.pt/dpd/register-install',
            'INSTALL_ID' => '',
            'INSTALL_CREATED_AT' => '',
            'INSTALL_REPORTED' => '0',
            'INSTALL_REPORTED_AT' => '',
            'INSTALL_LAST_REPORT_ATTEMPT' => '',
            'INSTALL_LAST_REPORT_ERROR' => '',
            'UPDATE_URL' => 'https://api.rgcconsulting.pt/dpd/module/latest/rgcdpdpt_v1.0.x.zip',
            'UPDATE_CHECK_INTERVAL' => '86400',
            'UPDATE_LAST_CHECK' => '',
            'UPDATE_LATEST_VERSION' => '',
            'UPDATE_DOWNLOAD_URL' => '',
            'UPDATE_PACKAGE_SHA256' => '',
            'UPDATE_LAST_ERROR' => '',
            'API_USERNAME' => '',
            'API_PASSWORD' => '',
            'CLIENT_ID' => self::DEFAULT_CLIENT_ID,
            'CLIENT_SECRET' => self::DEFAULT_CLIENT_SECRET,
            'MAX_WEIGHT' => '30',
            'ENABLE_PREDICT' => '0',
            'FRESH_EXPIRATION_DAYS' => '5',
            'DEFAULT_VOLUMES' => '1',
            'LABEL_FORMAT_ID' => '1',
            'LOG_ENABLED' => '1',
            'SENDER_NAME' => '',
            'SENDER_PHONE' => '',
            'SENDER_PHONE_CODE' => '+351',
            'SENDER_MOBILE' => '',
            'SENDER_MOBILE_CODE' => '+351',
            'SENDER_EMAIL' => '',
            'SHIPPER_NAME' => '',
            'SHIPPER_ADDRESS' => '',
            'SHIPPER_ZIP' => '',
            'SHIPPER_CITY' => '',
            'SHIPPER_COUNTRY_ISO2' => 'PT',
        ];

        foreach (self::serviceDefinitions() as $type => $definition) {
            $suffix = self::serviceKeySuffix($type);
            $definitions['SERVICE_' . $suffix . '_ENABLED'] = (string) ($definition['default_enabled'] ?? '0');
            $definitions['SERVICE_' . $suffix . '_ACCOUNT'] = (string) ($definition['default_account'] ?? '');
            $definitions['SERVICE_' . $suffix . '_NAME'] = (string) ($definition['default_name'] ?? $definition['label']);
            $definitions['RATE_' . $suffix] = (string) ($definition['default_rate'] ?? '0');
            $definitions['CARRIER_' . $suffix . '_ID'] = '0';
            $definitions['CARRIER_' . $suffix . '_REF'] = '0';
        }

        return $definitions;
    }

    public static function key($name)
    {
        return self::PREFIX . $name;
    }

    public static function get($name, $default = null)
    {
        $value = Configuration::get(self::key($name));
        if ($value === false || $value === null || $value === '') {
            $definitions = self::definitions();
            return array_key_exists($name, $definitions) ? $definitions[$name] : $default;
        }

        if (self::isSensitiveField($name)) {
            return self::decodeSensitiveValue((string) $value);
        }

        return $value;
    }

    public static function set($name, $value)
    {
        if (self::isSensitiveField($name)) {
            return Configuration::updateValue(self::key($name), self::encodeSensitiveValue((string) $value), false);
        }

        return Configuration::updateValue(self::key($name), (string) $value, false);
    }

    public static function isSensitiveField($name)
    {
        return in_array($name, self::sensitiveFields(), true);
    }

    protected static function sensitiveFields()
    {
        return [
            'API_PASSWORD',
            'CLIENT_SECRET',
            'PICKUP_KEY',
        ];
    }

    protected static function encodeSensitiveValue($value)
    {
        return 'base64:' . base64_encode((string) $value);
    }

    protected static function decodeSensitiveValue($value)
    {
        if (strpos((string) $value, 'base64:') === 0) {
            $decoded = base64_decode(substr((string) $value, 7), true);
            if ($decoded !== false) {
                return $decoded;
            }
        }

        return $value;
    }

    public static function all()
    {
        $output = [];
        foreach (self::definitions() as $name => $default) {
            $output[$name] = self::get($name, $default);
        }

        return $output;
    }

    public static function installDefaults($overwrite = true)
    {
        foreach (self::definitions() as $name => $default) {
            $key = self::key($name);
            $current = Configuration::get($key);
            $hasValue = $current !== false && $current !== null && $current !== '';

            if ($hasValue && self::isSensitiveField($name)) {
                $hasValue = trim((string) self::decodeSensitiveValue((string) $current)) !== '';
            }

            if (!$overwrite && $hasValue) {
                continue;
            }

            self::set($name, $default);
        }

        return true;
    }

    public static function ensureDefaults()
    {
        return self::installDefaults(false);
    }

    public static function ensureInternalOAuthCredentials()
    {
        // These credentials are defined by DPD for this plugin and are not
        // editable in the backoffice. Keep them synchronized on install,
        // upgrade and before requesting an OAuth token.
        self::set('CLIENT_ID', self::DEFAULT_CLIENT_ID);
        self::set('CLIENT_SECRET', self::DEFAULT_CLIENT_SECRET);

        return true;
    }

    public static function removeAll()
    {
        foreach (array_keys(self::definitions()) as $name) {
            Configuration::deleteByName(self::key($name));
        }

        return true;
    }

    public static function isQaMode()
    {
        return self::get('MODE') !== 'live';
    }

    public static function normalizeServiceType($type)
    {
        $type = strtolower(trim((string) $type));
        $type = str_replace('-', '_', $type);

        if ($type === 'pt_home') {
            return 'home';
        }

        if ($type === 'pt_pickup' || $type === 'pt_shop') {
            return 'pickup';
        }

        return $type;
    }

    public static function serviceKeySuffix($type)
    {
        $type = self::normalizeServiceType($type);
        return strtoupper(preg_replace('/[^a-z0-9]+/i', '_', $type));
    }

    public static function serviceTypes()
    {
        return array_keys(self::serviceDefinitions());
    }

    public static function pickupServiceTypes()
    {
        $types = [];
        foreach (self::serviceDefinitions() as $type => $definition) {
            if (($definition['delivery'] ?? 'home') === 'pickup') {
                $types[] = $type;
            }
        }

        return $types;
    }

    public static function isKnownServiceType($type)
    {
        return array_key_exists(self::normalizeServiceType($type), self::serviceDefinitions());
    }

    public static function serviceLabel($type)
    {
        $type = self::normalizeServiceType($type);
        $definitions = self::serviceDefinitions();
        return isset($definitions[$type]) ? $definitions[$type]['label'] : $type;
    }

    public static function isPickupService($type)
    {
        $type = self::normalizeServiceType($type);
        $definitions = self::serviceDefinitions();
        return isset($definitions[$type]) && ($definitions[$type]['delivery'] ?? 'home') === 'pickup';
    }

    public static function isFreshService($type)
    {
        return self::normalizeServiceType($type) === 'pt_fresh';
    }

    public static function isServiceEnabled($type)
    {
        $type = self::normalizeServiceType($type);
        if (!self::isKnownServiceType($type)) {
            return false;
        }

        return (bool) (int) self::get('SERVICE_' . self::serviceKeySuffix($type) . '_ENABLED', 0);
    }

    public static function serviceName($type)
    {
        $type = self::normalizeServiceType($type);
        $definitions = self::serviceDefinitions();
        $fallback = isset($definitions[$type]) ? $definitions[$type]['default_name'] : $type;
        $value = trim((string) self::get('SERVICE_' . self::serviceKeySuffix($type) . '_NAME', $fallback));

        return $value !== '' ? $value : $fallback;
    }

    public static function serviceAccount($type)
    {
        $type = self::normalizeServiceType($type);
        return trim((string) self::get('SERVICE_' . self::serviceKeySuffix($type) . '_ACCOUNT', ''));
    }

    public static function carrierIdKey($type)
    {
        $type = self::normalizeServiceType($type);
        return 'CARRIER_' . self::serviceKeySuffix($type) . '_ID';
    }

    public static function carrierRefKey($type)
    {
        $type = self::normalizeServiceType($type);
        return 'CARRIER_' . self::serviceKeySuffix($type) . '_REF';
    }

    public static function serviceRate($type, $bucket = '')
    {
        $type = self::normalizeServiceType($type);
        if (!self::isKnownServiceType($type)) {
            return 0.0;
        }

        return self::normalizeDecimal(self::get('RATE_' . self::serviceKeySuffix($type), 0));
    }

    public static function fallbackCarrierRate($carrierType)
    {
        return self::serviceRate($carrierType);
    }

    public static function supportsAddress($type, Address $address)
    {
        $type = self::normalizeServiceType($type);
        $iso2 = self::addressCountryIso2($address);
        if ($iso2 === '') {
            return false;
        }

        if ($type === 'home') {
            return $iso2 === 'PT' && DpdZoneResolver::resolveByPostcode($address->postcode) === DpdZoneResolver::MAINLAND;
        }

        if ($type === 'pickup') {
            return $iso2 === 'PT' && DpdZoneResolver::resolveByPostcode($address->postcode) === DpdZoneResolver::MAINLAND;
        }

        if ($type === 'pt_fresh') {
            return $iso2 === 'PT' && DpdZoneResolver::resolveByPostcode($address->postcode) === DpdZoneResolver::MAINLAND;
        }

        if ($type === 'pt_islands') {
            return $iso2 === 'PT' && DpdZoneResolver::resolveByPostcode($address->postcode) !== DpdZoneResolver::MAINLAND;
        }

        if ($type === 'es_home') {
            return $iso2 === 'ES';
        }

        if ($type === 'es_pickup') {
            return $iso2 === 'ES';
        }

        if ($type === 'int_home') {
            return !in_array($iso2, ['PT', 'ES'], true);
        }

        if ($type === 'int_pickup') {
            return !in_array($iso2, ['PT', 'ES'], true);
        }

        return false;
    }

    public static function addressCountryIso2(Address $address)
    {
        $country = new Country((int) $address->id_country);
        if (!Validate::isLoadedObject($country)) {
            return '';
        }

        return Tools::strtoupper((string) $country->iso_code);
    }

    public static function normalizeDecimal($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return 0.0;
        }

        $value = str_replace(["\xc2\xa0", ' '], '', $value);
        $value = preg_replace('/[^0-9,\.\-]/', '', $value);

        if ($value === '' || $value === '-' || $value === ',' || $value === '.') {
            return 0.0;
        }

        $lastComma = strrpos($value, ',');
        $lastDot = strrpos($value, '.');

        if ($lastComma !== false && $lastDot !== false) {
            if ($lastComma > $lastDot) {
                $value = str_replace('.', '', $value);
                $value = str_replace(',', '.', $value);
            } else {
                $value = str_replace(',', '', $value);
            }
        } elseif ($lastComma !== false) {
            $value = str_replace(',', '.', $value);
        }

        return (float) $value;
    }

    public static function formatPriceForDisplay($value)
    {
        return number_format((float) $value, 2, ',', '.') . ' EUR';
    }

    public static function maxWeight()
    {
        return (float) self::get('MAX_WEIGHT', 30);
    }

    public static function freshExpirationDays()
    {
        $days = (int) self::get('FRESH_EXPIRATION_DAYS', 5);
        if ($days < 1) {
            return 5;
        }

        return min($days, 365);
    }

    public static function loggingEnabled()
    {
        return (bool) self::get('LOG_ENABLED', 1);
    }
}
