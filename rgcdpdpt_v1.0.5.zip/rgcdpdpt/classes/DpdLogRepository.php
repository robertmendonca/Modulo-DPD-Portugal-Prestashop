<?php
class DpdLogRepository
{
    protected static function tableExists()
    {
        return DpdSchema::hasTable('rgcdpd_log');
    }

    public static function add($level, $message, $contextType = 'system', $contextId = null, $payload = null)
    {
        if (!DpdConfig::loggingEnabled() || !self::tableExists()) {
            return true;
        }

        return Db::getInstance()->insert('rgcdpd_log', [
            'context_type' => pSQL($contextType),
            'context_id' => $contextId !== null ? (int) $contextId : null,
            'level' => pSQL($level),
            'message' => pSQL($message),
            'payload' => $payload !== null ? pSQL(is_string($payload) ? $payload : json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), true) : null,
            'date_add' => date('Y-m-d H:i:s'),
        ]);
    }

    public static function latest($limit = 20)
    {
        if (!self::tableExists()) {
            return [];
        }

        $limit = max(1, (int) $limit);

        try {
            return Db::getInstance()->executeS(
                'SELECT * FROM `' . _DB_PREFIX_ . 'rgcdpd_log` ORDER BY `id_rgcdpd_log` DESC LIMIT ' . (int) $limit
            ) ?: [];
        } catch (Exception $e) {
            return [];
        }
    }
}
