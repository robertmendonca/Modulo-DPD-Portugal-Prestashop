<?php
class DpdUpdateChecker
{
    const DEFAULT_CHECK_INTERVAL = 86400;
    const MAX_PACKAGE_BYTES = 15728640;

    public static function check($module, $force = false)
    {
        $currentVersion = isset($module->version) ? (string) $module->version : '';
        $lastCheck = trim((string) DpdConfig::get('UPDATE_LAST_CHECK'));

        if (!$force && !self::isCheckDue($lastCheck)) {
            return self::status($module);
        }

        $checkedAt = gmdate('c');
        DpdConfig::set('UPDATE_LAST_CHECK', $checkedAt);

        $url = trim((string) DpdConfig::get('UPDATE_URL'));
        if ($url === '') {
            DpdConfig::set('UPDATE_LAST_ERROR', 'URL de atualização não configurado.');
            return self::status($module);
        }

        $result = self::inspectRemotePackage($url);
        if (!$result['ok']) {
            DpdConfig::set('UPDATE_LAST_ERROR', Tools::substr((string) $result['error'], 0, 500));
            return self::status($module);
        }

        $latestVersion = (string) $result['version'];
        DpdConfig::set('UPDATE_LATEST_VERSION', $latestVersion);
        DpdConfig::set('UPDATE_DOWNLOAD_URL', (string) $result['download_url']);
        DpdConfig::set('UPDATE_PACKAGE_SHA256', (string) $result['sha256']);
        DpdConfig::set('UPDATE_LAST_ERROR', '');

        return [
            'checked' => true,
            'current_version' => $currentVersion,
            'latest_version' => $latestVersion,
            'available' => self::isNewerVersion($latestVersion, $currentVersion),
            'download_url' => (string) $result['download_url'],
            'checked_at' => $checkedAt,
            'error' => '',
            'sha256' => (string) $result['sha256'],
        ];
    }

    public static function status($module)
    {
        $currentVersion = isset($module->version) ? (string) $module->version : '';
        $latestVersion = trim((string) DpdConfig::get('UPDATE_LATEST_VERSION'));
        $downloadUrl = trim((string) DpdConfig::get('UPDATE_DOWNLOAD_URL'));
        if ($downloadUrl === '') {
            $downloadUrl = trim((string) DpdConfig::get('UPDATE_URL'));
        }

        return [
            'checked' => trim((string) DpdConfig::get('UPDATE_LAST_CHECK')) !== '',
            'current_version' => $currentVersion,
            'latest_version' => $latestVersion,
            'available' => self::isNewerVersion($latestVersion, $currentVersion),
            'download_url' => $downloadUrl,
            'checked_at' => trim((string) DpdConfig::get('UPDATE_LAST_CHECK')),
            'error' => trim((string) DpdConfig::get('UPDATE_LAST_ERROR')),
            'sha256' => trim((string) DpdConfig::get('UPDATE_PACKAGE_SHA256')),
        ];
    }

    public static function clearCache()
    {
        DpdConfig::set('UPDATE_LAST_CHECK', '');
        DpdConfig::set('UPDATE_LATEST_VERSION', '');
        DpdConfig::set('UPDATE_DOWNLOAD_URL', '');
        DpdConfig::set('UPDATE_PACKAGE_SHA256', '');
        DpdConfig::set('UPDATE_LAST_ERROR', '');

        return true;
    }

    protected static function isCheckDue($lastCheck)
    {
        if ($lastCheck === '') {
            return true;
        }

        $timestamp = strtotime($lastCheck);
        if ($timestamp === false) {
            return true;
        }

        $interval = (int) DpdConfig::get('UPDATE_CHECK_INTERVAL', self::DEFAULT_CHECK_INTERVAL);
        if ($interval < 3600) {
            $interval = 3600;
        }

        return (time() - $timestamp) >= $interval;
    }

    protected static function isNewerVersion($latestVersion, $currentVersion)
    {
        if (!self::isValidVersion($latestVersion) || !self::isValidVersion($currentVersion)) {
            return false;
        }

        return version_compare($latestVersion, $currentVersion, '>');
    }

    protected static function inspectRemotePackage($url)
    {
        $urlParts = parse_url($url);
        if (!is_array($urlParts)
            || strtolower((string) ($urlParts['scheme'] ?? '')) !== 'https'
            || strtolower((string) ($urlParts['host'] ?? '')) !== 'api.rgcconsulting.pt') {
            return ['ok' => false, 'error' => 'O endereço de atualização não é permitido.'];
        }

        if (!function_exists('curl_init')) {
            return ['ok' => false, 'error' => 'A extensão PHP cURL não está disponível.'];
        }

        $body = '';
        $headers = [];
        $tooLarge = false;
        $ch = curl_init($url);

        if (!$ch) {
            return ['ok' => false, 'error' => 'Não foi possível iniciar a consulta de atualização.'];
        }

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: application/zip, application/octet-stream;q=0.9, */*;q=0.5',
            'User-Agent: rgcdpdpt-update-checker/1.0.3',
        ]);

        if (defined('CURLOPT_PROTOCOLS') && defined('CURLPROTO_HTTPS')) {
            curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTPS);
        }
        if (defined('CURLOPT_REDIR_PROTOCOLS') && defined('CURLPROTO_HTTPS')) {
            curl_setopt($ch, CURLOPT_REDIR_PROTOCOLS, CURLPROTO_HTTPS);
        }

        curl_setopt($ch, CURLOPT_HEADERFUNCTION, function ($curl, $headerLine) use (&$headers) {
            $length = strlen($headerLine);
            $line = trim($headerLine);
            if ($line === '' || strpos($line, ':') === false) {
                return $length;
            }

            list($name, $value) = explode(':', $line, 2);
            $headers[strtolower(trim($name))] = trim($value);
            return $length;
        });

        curl_setopt($ch, CURLOPT_WRITEFUNCTION, function ($curl, $chunk) use (&$body, &$tooLarge) {
            if ((strlen($body) + strlen($chunk)) > self::MAX_PACKAGE_BYTES) {
                $tooLarge = true;
                return 0;
            }

            $body .= $chunk;
            return strlen($chunk);
        });

        $executed = curl_exec($ch);
        $errno = (int) curl_errno($ch);
        $curlError = (string) curl_error($ch);
        $httpStatus = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $effectiveUrl = (string) curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        curl_close($ch);

        if ($tooLarge) {
            return ['ok' => false, 'error' => 'O pacote de atualização ultrapassa o limite permitido de 15 MB.'];
        }

        if ($executed === false || $errno !== 0) {
            return ['ok' => false, 'error' => 'Falha ao consultar atualização: ' . ($curlError !== '' ? $curlError : 'erro cURL ' . $errno)];
        }

        if ($httpStatus < 200 || $httpStatus >= 300) {
            return ['ok' => false, 'error' => 'O servidor de atualização respondeu com HTTP ' . $httpStatus . '.'];
        }

        $effectiveParts = parse_url($effectiveUrl);
        if (!is_array($effectiveParts)
            || strtolower((string) ($effectiveParts['scheme'] ?? '')) !== 'https'
            || strtolower((string) ($effectiveParts['host'] ?? '')) !== 'api.rgcconsulting.pt') {
            return ['ok' => false, 'error' => 'O servidor tentou redirecionar o pacote para um endereço não permitido.'];
        }

        if (strlen($body) < 4 || substr($body, 0, 2) !== 'PK') {
            return ['ok' => false, 'error' => 'O ficheiro disponibilizado não é um pacote ZIP válido.'];
        }

        $latestVersion = self::versionFromHeaders($headers);
        if ($latestVersion === '') {
            $latestVersion = self::versionFromText((string) ($headers['content-disposition'] ?? ''));
        }
        if ($latestVersion === '') {
            $latestVersion = self::versionFromText($effectiveUrl);
        }
        if ($latestVersion === '') {
            $latestVersion = self::versionFromZipData($body);
        }

        if (!self::isValidVersion($latestVersion)) {
            return [
                'ok' => false,
                'error' => 'Não foi possível identificar a versão contida no pacote. Confirme que o ZIP contém rgcdpdpt/config.xml.',
            ];
        }

        return [
            'ok' => true,
            'version' => $latestVersion,
            'download_url' => $url,
            'sha256' => hash('sha256', $body),
        ];
    }

    protected static function versionFromHeaders(array $headers)
    {
        foreach (['x-rgcdpdpt-version', 'x-module-version'] as $headerName) {
            $candidate = trim((string) ($headers[$headerName] ?? ''));
            if (self::isValidVersion($candidate)) {
                return $candidate;
            }
        }

        return '';
    }

    protected static function versionFromText($text)
    {
        if (preg_match('/rgcdpdpt[_-]v?([0-9]+\.[0-9]+\.[0-9]+(?:[-+][0-9A-Za-z.-]+)?)\.zip/i', (string) $text, $matches)) {
            return (string) $matches[1];
        }

        return '';
    }

    protected static function versionFromZipData($body)
    {
        $configXml = self::configXmlFromZipData($body);

        if ($configXml === false && class_exists('ZipArchive')) {
            $configXml = self::configXmlWithZipArchive($body);
        }

        if ($configXml === false) {
            return '';
        }

        if (!preg_match('#<name>\s*(?:<!\[CDATA\[)?\s*rgcdpdpt\s*(?:\]\]>)?\s*</name>#i', $configXml)) {
            return '';
        }

        if (!preg_match('#<version>\s*(?:<!\[CDATA\[)?\s*([^<\]]+)\s*(?:\]\]>)?\s*</version>#i', $configXml, $matches)) {
            return '';
        }

        $candidate = trim((string) $matches[1]);
        return self::isValidVersion($candidate) ? $candidate : '';
    }

    protected static function configXmlFromZipData($body)
    {
        $bodyLength = strlen($body);
        if ($bodyLength < 22) {
            return false;
        }

        $searchStart = max(0, $bodyLength - 65557);
        $eocdOffset = strrpos(substr($body, $searchStart), "PK\x05\x06");
        if ($eocdOffset === false) {
            return false;
        }
        $eocdOffset += $searchStart;

        if (($eocdOffset + 22) > $bodyLength) {
            return false;
        }

        $entries = self::readUInt16($body, $eocdOffset + 10);
        $centralOffset = self::readUInt32($body, $eocdOffset + 16);
        if ($entries === null || $centralOffset === null || $centralOffset >= $bodyLength) {
            return false;
        }

        $offset = $centralOffset;
        for ($i = 0; $i < $entries; $i++) {
            if (($offset + 46) > $bodyLength || substr($body, $offset, 4) !== "PK\x01\x02") {
                return false;
            }

            $flags = self::readUInt16($body, $offset + 8);
            $compression = self::readUInt16($body, $offset + 10);
            $compressedSize = self::readUInt32($body, $offset + 20);
            $uncompressedSize = self::readUInt32($body, $offset + 24);
            $fileNameLength = self::readUInt16($body, $offset + 28);
            $extraLength = self::readUInt16($body, $offset + 30);
            $commentLength = self::readUInt16($body, $offset + 32);
            $localOffset = self::readUInt32($body, $offset + 42);

            if ($flags === null || $compression === null || $compressedSize === null
                || $uncompressedSize === null || $fileNameLength === null
                || $extraLength === null || $commentLength === null || $localOffset === null) {
                return false;
            }

            $fileName = substr($body, $offset + 46, $fileNameLength);
            $normalizedName = strtolower(str_replace('\\', '/', (string) $fileName));
            $isConfig = in_array($normalizedName, [
                'rgcdpdpt/config.xml',
                'config.xml',
                'rgcdpdpt/config_pt.xml',
                'config_pt.xml',
            ], true) || (bool) preg_match('#(^|/)rgcdpdpt/config(?:_pt)?\.xml$#i', $normalizedName);

            if ($isConfig) {
                if (($flags & 0x0001) !== 0) {
                    return false;
                }

                if ($uncompressedSize > 1048576 || $compressedSize > self::MAX_PACKAGE_BYTES) {
                    return false;
                }

                if (($localOffset + 30) > $bodyLength || substr($body, $localOffset, 4) !== "PK\x03\x04") {
                    return false;
                }

                $localNameLength = self::readUInt16($body, $localOffset + 26);
                $localExtraLength = self::readUInt16($body, $localOffset + 28);
                if ($localNameLength === null || $localExtraLength === null) {
                    return false;
                }

                $dataOffset = $localOffset + 30 + $localNameLength + $localExtraLength;
                if (($dataOffset + $compressedSize) > $bodyLength) {
                    return false;
                }

                $compressedData = substr($body, $dataOffset, $compressedSize);
                if ($compression === 0) {
                    $xml = $compressedData;
                } elseif ($compression === 8 && function_exists('gzinflate')) {
                    $xml = @gzinflate($compressedData);
                } else {
                    return false;
                }

                if ($xml === false || strlen($xml) > 1048576) {
                    return false;
                }

                return (string) $xml;
            }

            $offset += 46 + $fileNameLength + $extraLength + $commentLength;
        }

        return false;
    }

    protected static function configXmlWithZipArchive($body)
    {
        $cacheDir = defined('_PS_CACHE_DIR_') ? (string) _PS_CACHE_DIR_ : sys_get_temp_dir();
        if (!is_dir($cacheDir) || !is_writable($cacheDir)) {
            $cacheDir = sys_get_temp_dir();
        }

        $tempFile = tempnam($cacheDir, 'rgcdpdpt_update_');
        if ($tempFile === false) {
            return false;
        }

        try {
            if (file_put_contents($tempFile, $body) === false) {
                return false;
            }

            $zip = new ZipArchive();
            if ($zip->open($tempFile) !== true) {
                return false;
            }

            $configXml = false;
            foreach (['rgcdpdpt/config.xml', 'config.xml', 'rgcdpdpt/config_pt.xml', 'config_pt.xml'] as $candidate) {
                $configXml = $zip->getFromName($candidate);
                if ($configXml !== false) {
                    break;
                }
            }

            if ($configXml === false) {
                for ($i = 0; $i < $zip->numFiles; $i++) {
                    $name = (string) $zip->getNameIndex($i);
                    if (preg_match('#(^|/)rgcdpdpt/config(?:_pt)?\.xml$#i', $name)) {
                        $configXml = $zip->getFromIndex($i);
                        if ($configXml !== false) {
                            break;
                        }
                    }
                }
            }

            $zip->close();
            return $configXml;
        } finally {
            @unlink($tempFile);
        }
    }

    protected static function readUInt16($data, $offset)
    {
        if (($offset + 2) > strlen($data)) {
            return null;
        }

        $value = unpack('vvalue', substr($data, $offset, 2));
        return isset($value['value']) ? (int) $value['value'] : null;
    }

    protected static function readUInt32($data, $offset)
    {
        if (($offset + 4) > strlen($data)) {
            return null;
        }

        $value = unpack('Vvalue', substr($data, $offset, 4));
        return isset($value['value']) ? (int) $value['value'] : null;
    }

    protected static function isValidVersion($version)
    {
        return (bool) preg_match('/^[0-9]+\.[0-9]+\.[0-9]+(?:[-+][0-9A-Za-z.-]+)?$/', (string) $version);
    }
}
