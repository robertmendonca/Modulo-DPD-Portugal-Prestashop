(function () {
  function getTabLinkFromEventTarget(target) {
    while (target && target !== document) {
      if (target.matches && target.matches('.rgcdpdpt-admin-tabs a[data-toggle="tab"]')) {
        return target;
      }
      target = target.parentNode;
    }
    return null;
  }

  function setActiveTab(hash, updateHash) {
    if (!hash || hash.indexOf('#rgcdpdpt-') !== 0) {
      return false;
    }

    var link = document.querySelector('.rgcdpdpt-admin-tabs a[href="' + hash + '"]');
    var pane = document.querySelector(hash);
    if (!link || !pane) {
      return false;
    }

    if (window.jQuery && typeof window.jQuery.fn.tab === 'function') {
      window.jQuery(link).tab('show');
    } else {
      var tabs = document.querySelectorAll('.rgcdpdpt-admin-tabs li');
      var panes = document.querySelectorAll('.rgcdpdpt-tab-content .tab-pane');

      for (var i = 0; i < tabs.length; i++) {
        tabs[i].classList.remove('active');
      }
      for (var j = 0; j < panes.length; j++) {
        panes[j].classList.remove('active');
      }

      link.parentNode.classList.add('active');
      pane.classList.add('active');
    }

    try {
      window.localStorage.setItem('rgcdpdptActiveAdminTab', hash);
    } catch (e) {}

    if (updateHash && window.history && window.history.replaceState) {
      window.history.replaceState(null, document.title, hash);
    }

    return true;
  }

  function setPickupState(button, config, enabled) {
    var inactiveLabel = button.getAttribute('data-inactive-label') || 'Ativar conteúdo Pickup';
    var activeLabel = button.getAttribute('data-active-label') || 'Desativar conteúdo Pickup';

    if (enabled) {
      config.classList.add('is-active');
      config.style.display = 'block';
      config.setAttribute('aria-hidden', 'false');
      button.setAttribute('aria-expanded', 'true');
      button.textContent = activeLabel;
      button.classList.remove('btn-warning');
      button.classList.add('btn-default');
      button.classList.add('is-active');
      return;
    }

    config.classList.remove('is-active');
    config.style.display = 'none';
    config.setAttribute('aria-hidden', 'true');
    button.setAttribute('aria-expanded', 'false');
    button.textContent = inactiveLabel;
    button.classList.remove('btn-default');
    button.classList.add('btn-warning');
    button.classList.remove('is-active');
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.addEventListener('click', function (event) {
      var link = getTabLinkFromEventTarget(event.target);
      if (link) {
        event.preventDefault();
        setActiveTab(link.getAttribute('href'), true);
        return;
      }

      var pickupButton = event.target.closest ? event.target.closest('.rgcdpdpt-enable-pickup-config') : null;
      if (!pickupButton) {
        return;
      }

      event.preventDefault();
      var section = pickupButton.closest ? pickupButton.closest('.rgcdpdpt-service-section-pickup') : null;
      var pickupConfig = section ? section.querySelector('.rgcdpdpt-pickup-config') : null;
      if (!pickupConfig) {
        return;
      }

      var isActive = pickupButton.getAttribute('aria-expanded') === 'true' || pickupConfig.classList.contains('is-active');
      if (isActive) {
        setPickupState(pickupButton, pickupConfig, false);
        return;
      }

      var warning = pickupButton.getAttribute('data-warning') || 'Ative o conteúdo Pickup apenas se tiver contrato com a DPD. Deseja continuar?';
      if (!window.confirm(warning)) {
        return;
      }

      setPickupState(pickupButton, pickupConfig, true);
    });

    var storedTab = '';
    try {
      storedTab = window.localStorage.getItem('rgcdpdptActiveAdminTab') || '';
    } catch (e) {}

    setActiveTab(window.location.hash || storedTab || '#rgcdpdpt-dpd', false);
  });
})();
