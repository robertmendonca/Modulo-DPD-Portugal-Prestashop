<div class="card">
  <h3 class="card-header">DPD Portugal</h3>
  <div class="card-body">
    {if isset($flash_success) && $flash_success}
      <div class="alert alert-success">{$flash_success|escape:'htmlall':'UTF-8'}</div>
    {/if}
    {if isset($flash_error) && $flash_error}
      <div class="alert alert-danger">{$flash_error|escape:'htmlall':'UTF-8'}</div>
    {/if}

    {if $shipment}
      <p><strong>Estado:</strong> {$shipment.status|escape:'htmlall':'UTF-8'}</p>
      {if isset($shipment_is_failed) && $shipment_is_failed}
        <div class="alert alert-danger">
          A expedição DPD não foi criada.
          {if isset($shipment_error_message) && $shipment_error_message}
            <br><strong>Erro DPD:</strong> {$shipment_error_message|escape:'htmlall':'UTF-8'}
          {/if}
        </div>
        <p>
          <a class="btn btn-primary" href="{$create_shipment_url|escape:'htmlall':'UTF-8'}">
            Tentar criar expedição novamente
          </a>
        </p>
      {elseif isset($shipment_tracking_number) && $shipment_tracking_number}
        <p><strong>Guia:</strong> {$shipment_tracking_number|escape:'htmlall':'UTF-8'}</p>
      {else}
        <div class="alert alert-warning">
          A expedição foi criada, mas a API DPD não devolveu a guia num campo reconhecido. Abra a etiqueta PDF ou use a recuperação abaixo para tentar extrair a guia da resposta/etiqueta guardada.
        </div>
        <p>
          <a class="btn btn-outline-primary" href="{$refresh_tracking_url|escape:'htmlall':'UTF-8'}">
            Recuperar guia DPD
          </a>
        </p>
        <form method="post" action="{$set_manual_tracking_url|escape:'htmlall':'UTF-8'}" class="form-inline" style="margin: 10px 0;">
          <input type="hidden" name="action" value="SetManualTracking">
          <input type="hidden" name="id_order" value="{$id_order|intval}">
          <div class="form-group" style="margin-right: 8px;">
            <label class="sr-only" for="rgcdpdpt_manual_tracking">Guia DPD</label>
            <input id="rgcdpdpt_manual_tracking" class="form-control" type="text" name="tracking_number" placeholder="Inserir guia manualmente" maxlength="64">
          </div>
          <button type="submit" class="btn btn-outline-secondary">Gravar guia</button>
        </form>
      {/if}
      {if $shipment.label_path}
        <p>
          <a class="btn btn-outline-secondary"
             href="{$download_label_url|escape:'htmlall':'UTF-8'}"
             target="_blank" rel="noopener">
            Abrir etiqueta PDF
          </a>
        </p>
      {/if}
      {if isset($shipment_debug_payload) && $shipment_debug_payload}
        <details style="margin-top: 12px;">
          <summary>Ver diagnóstico completo da expedição DPD</summary>
          <p class="text-muted" style="margin-top: 8px;">Inclui resumo, conta DPD usada, serviço selecionado, payload enviado e resposta recebida. Tokens, passwords e etiquetas PDF/base64 foram omitidos.</p>
          <pre style="white-space: pre-wrap; max-height: 320px; overflow: auto; background: #f7f7f7; padding: 10px; border: 1px solid #ddd;">{$shipment_debug_payload|escape:'htmlall':'UTF-8'}</pre>
        </details>
      {/if}
    {else}
      <p>Ainda não existe expedição DPD para esta encomenda.</p>
      <p>
        <a class="btn btn-primary"
           href="{$create_shipment_url|escape:'htmlall':'UTF-8'}">
          Criar expedição DPD
        </a>
      </p>
    {/if}

    {if $pickup}
      <hr>
      <p><strong>Pickup:</strong> {$pickup.pickup_name|escape:'htmlall':'UTF-8'} ({$pickup.pickup_code|escape:'htmlall':'UTF-8'})</p>
      <p>{$pickup.pickup_address|escape:'htmlall':'UTF-8'}, {$pickup.pickup_zip|escape:'htmlall':'UTF-8'} {$pickup.pickup_city|escape:'htmlall':'UTF-8'}</p>
    {/if}
  </div>
</div>
