# RGC DPD PT para PrestaShop

Módulo gratuito de integração **DPD Portugal** para **PrestaShop 8.x e 9.x**.

Este módulo permite adicionar métodos de envio DPD no checkout da loja, incluindo entregas **Home** e entregas em **pontos Pickup/Shop**, e criar expedições DPD a partir da encomenda no backoffice.

> **Versão atual:** 1.0.5  
> **Compatibilidade:** PrestaShop 8.x e 9.x  
> **Estado PrestaShop 9.x:** em validação.  
> **Área de atuação:** Portugal Continental, Portugal Ilhas, Espanha e Internacional, de acordo com os serviços contratados com a DPD.

---

## Para quem é este módulo

Este módulo foi criado para clientes DPD que usam PrestaShop e precisam integrar os serviços DPD na loja online.

Para criar expedições reais, o cliente precisa solicitar os dados de acesso à DPD e preencher as contas de serviço contratadas na configuração do módulo.

---

## Informação importante sobre suporte

O módulo é disponibilizado gratuitamente.

Cada cliente tem direito a **15 minutos gratuitos de apoio inicial pela DPD** para apoio à instalação ou primeira configuração.

Após esse período, o suporte técnico adicional é cobrado em packs de:

```text
20 EUR + IVA por pack adicional de 30 minutos
```

Consulte: [SUPPORT.md](SUPPORT.md)

---

## Registo técnico de instalação

Durante a instalação, o módulo faz um registo técnico simples em:

```text
https://api.rgcconsulting.pt/dpd/register-install
```

Este registo serve apenas para identificar onde o módulo foi instalado e ajudar no controlo de distribuição e suporte.

Dados enviados:

- domínio da loja;
- data/hora da instalação;
- versão do módulo;
- versão do PrestaShop;
- identificador técnico único da instalação.

Não são enviados:

- dados de clientes;
- encomendas;
- moradas;
- credenciais DPD;
- passwords;
- tokens OAuth;
- etiquetas PDF;
- payloads de expedições.

Se a API de registo estiver temporariamente indisponível, a instalação do módulo não é bloqueada.

---

## Antes de instalar: pedir os dados à DPD

Antes de configurar o módulo, peça à DPD os dados de acesso da sua conta.

Deve solicitar:

- utilizador da API;
- password da API;
- contas DPD de 8 dígitos para os serviços contratados;
- confirmação dos serviços contratados, incluindo Pickup/Shop e Fresh quando aplicável.

Sem estes dados, o módulo pode ser instalado, mas não conseguirá criar expedições reais.

---

## Serviços DPD configuráveis

A configuração atual do módulo é baseada em tipologia de serviço e contas DPD.

| Conta DPD | Serviço | Tipo |
|---|---|---|
| `09999001` | DPD Portugal Home | Home |
| `09999002` | DPD Portugal Shop | Pickup/Shop |
| `09999008` | DPD Portugal Fresh | Fresh |
| `09999003` | DPD Portugal Ilhas | Home |
| `09999004` | DPD Espanha Home | Home |
| `09999005` | DPD Espanha Shop | Pickup/Shop |
| `09999006` | DPD Internacional Home | Home |
| `09999007` | DPD Internacional Shop | Pickup/Shop |

As contas acima são exemplos. Cada cliente deve preencher as contas reais fornecidas pela DPD.

---

## O que o módulo faz

### No checkout

- Mostra métodos de envio DPD conforme a morada do cliente.
- Permite entrega ao domicílio com serviços Home.
- Permite configurar DPD Fresh como serviço próprio para Portugal Continental.
- Permite entrega em pontos Pickup/Shop.
- Mostra mapa com pontos Pickup quando o cliente escolhe um envio Pickup.
- Exige que o cliente selecione um ponto Pickup antes de finalizar a encomenda.
- Usa ícones DPD nos métodos de envio e no mapa.

### No backoffice

- Permite configurar o utilizador e a password da API DPD.
- Mantém endpoints técnicos, Client ID, Client secret e parâmetros Pickup ocultos da interface.
- Permite configurar as contas DPD por serviço.
- Inclui suporte ao serviço **DPD Portugal Fresh**.
- Separa os serviços entre **Home** e **Pickup**.
- Permite ativar a área Pickup apenas quando o cliente tiver contrato DPD para esse serviço.
- Cria e repara as transportadoras DPD no PrestaShop.
- Permite criar expedição DPD a partir da encomenda.
- Guarda a guia DPD e a etiqueta PDF.
- Atualiza o tracking da encomenda no PrestaShop.
- Mostra logs e informações de diagnóstico.

---

## Instalação rápida

1. Faça download do ficheiro ZIP do módulo.
2. Entre no backoffice do PrestaShop.
3. Vá a **Módulos > Gestor de módulos**.
4. Clique em **Carregar um módulo**.
5. Envie o ZIP do módulo.
6. Instale o módulo **RGC DPD PT**.
7. Abra a configuração do módulo.
8. Preencha os dados fornecidos pela DPD.
9. Clique em **Guardar configurações**.
10. Clique em **Reparar transportadoras**.
11. Limpe a cache do PrestaShop.
12. Faça uma encomenda de teste.

Guia completo: [docs/guia-instalacao.md](docs/guia-instalacao.md)

---

## Configuração do módulo

A configuração está organizada por abas:

| Aba | Finalidade |
|---|---|
| **DPD** | Utilizador e password da API DPD. |
| **Contas DPD** | Contas DPD de 8 dígitos e nome visível de cada serviço. |
| **Dados do expedidor** | Dados da empresa que envia a encomenda. |
| **Operação** | Peso máximo, validade Fresh, formato de etiqueta, volumes, Predict e logs. |
| **Portes** | Preço base de cada serviço. |
| **Diagnóstico** | Testes, logs e informação técnica para suporte. |

Guia de configuração: [docs/configuracao-dpd.md](docs/configuracao-dpd.md)

---

## Dados do expedidor

Configure os dados do expedidor que serão utilizados pela DPD como origem das expedições, recolhas e etiquetas. Estes dados devem corresponder à morada e aos contactos associados ao contrato DPD.

Para Portugal, o campo **País do expedidor — ISO2** deve ser:

```text
PT
```

## DPD Fresh

O serviço **DPD Portugal Fresh** fica disponível como uma conta própria na aba **Contas DPD**.

Quando uma encomenda usa a transportadora DPD Fresh, o módulo adiciona automaticamente ao payload da API:

```json
{
  "fresh_pickup_date": "dia útil seguinte",
  "fresh_expiration_date": "data de recolha + validade configurada"
}
```

A data `fresh_pickup_date` é calculada como o dia útil seguinte à criação da expedição, ignorando fins de semana e feriados nacionais portugueses.

A data `fresh_expiration_date` é calculada a partir da data de recolha. A validade é configurada no pequeno campo **Validade Fresh**, junto da conta DPD Portugal Fresh, e utiliza 5 dias por defeito.

---

## Fluxo normal de utilização

### Cliente final

1. Escolhe os produtos.
2. Preenche a morada.
3. Escolhe um método de envio DPD.
4. Se escolher Pickup/Shop, seleciona um ponto no mapa ou na lista.
5. Finaliza a encomenda.

### Lojista

1. Abre a encomenda no backoffice.
2. Confirma que a encomenda está pronta para expedir.
3. Clica em **Criar expedição DPD**.
4. Abre ou descarrega a etiqueta PDF.
5. Imprime a etiqueta e prepara a encomenda.

Guia de utilização: [docs/guia-utilizacao.md](docs/guia-utilizacao.md)

---

## Requisitos

### Loja

- PrestaShop 8.x ou 9.x.
- Produtos físicos.
- Países, zonas e transportadoras corretamente configurados.
- Checkout compatível com o fluxo padrão do PrestaShop.

### Servidor

Recomendado:

- PHP 8.1 ou superior.
- Extensão PHP `curl` ativa.
- Extensão PHP `json` ativa.
- Extensão PHP `openssl` ativa.
- Extensão PHP `soap` recomendada para pesquisa Pickup.

Para o mapa Pickup, o front office precisa conseguir carregar os recursos externos usados pelo Leaflet/OpenStreetMap.

---

## Perguntas frequentes

### O módulo é gratuito?

Sim. O módulo é disponibilizado gratuitamente.

### Posso usar sem ter contrato com a DPD?

Não para envios reais. É necessário ter dados de acesso e contas DPD válidas.

### A DPD fornece os dados que devo preencher?

Sim. O cliente deve pedir os dados de acesso e as contas de serviço à DPD.

### O módulo cria a expedição automaticamente?

Não. Nesta versão, a expedição é criada manualmente no backoffice da encomenda. Isto evita criar expedições para encomendas ainda não pagas, canceladas ou pendentes.

---

## Resolução rápida de problemas

### Não aparecem métodos DPD no checkout

Verifique:

- se o módulo está ativo;
- se as contas DPD estão ativas na aba **Contas DPD**;
- se clicou em **Reparar transportadoras**;
- se a morada do cliente está completa;
- se o país/região está abrangido pelo serviço ativo;
- se o peso do carrinho não ultrapassa o peso máximo configurado;
- se a cache do PrestaShop foi limpa.

### O mapa Pickup não aparece

Verifique:

- se o cliente selecionou um método Pickup/Shop;
- se a secção Pickup está ativa na aba **Contas DPD**;
- se o serviço Pickup/Shop correspondente está ativo;
- se a conta DPD de Pickup está configurada;
- se o cliente tem contrato DPD para Pickup;
- se a morada tem código postal válido;
- se o servidor consegue aceder ao webservice Pickup;
- se o tema não bloqueia JavaScript ou recursos externos do mapa.

### A API DPD rejeita a expedição

Verifique:

- utilizador da API;
- password da API;
- conta DPD usada no serviço;
- permissões da conta na DPD;
- IP autorizado, se aplicável;
- resposta técnica mostrada no diagnóstico.

---

## Segurança

Nunca publique no GitHub:

- utilizador de produção;
- password de produção;
- client secret;
- chave Pickup;
- etiquetas PDF reais;
- payloads reais com dados de clientes;
- logs com dados pessoais.

Consulte: [SECURITY.md](SECURITY.md)

---

## Documentação adicional

- [Guia de instalação](docs/guia-instalacao.md)
- [Guia de configuração DPD](docs/configuracao-dpd.md)
- [Guia de utilização](docs/guia-utilizacao.md)
- [Contas DPD](docs/dpd-service-accounts.md)
- [Notas de API DPD](docs/api-dpd.md)
- [Perguntas frequentes](docs/perguntas-frequentes.md)
- [Suporte](SUPPORT.md)
- [Segurança](SECURITY.md)
- [Changelog](CHANGELOG.md)

---

## Limitações atuais

Nesta versão, o módulo ainda não implementa:

- criação automática de expedição por mudança de estado da encomenda;
- pedido de recolha através do endpoint `/collect`;
- fecho do dia/manifesto através do endpoint `/expedition/fechoApi`;
- cancelamento de expedição;
- tracking detalhado por API;
- regras avançadas de portes por peso, valor, categoria ou país/região.

---

## Contribuição

Contribuições são bem-vindas.

Antes de enviar uma alteração:

1. Teste instalação limpa.
2. Teste upgrade a partir de uma versão anterior.
3. Teste checkout com serviço Home.
4. Teste checkout com serviço Pickup/Shop.
5. Teste criação de expedição no backoffice.
6. Confirme que não incluiu credenciais, logs reais ou etiquetas reais.

Testes básicos de sintaxe:

```bash
php -l rgcdpdpt.php
find classes controllers upgrade -name "*.php" -print0 | xargs -0 -n1 php -l
```

---

## Licença

Defina a licença antes de publicar o repositório em modo público.

Se o módulo for distribuído oficialmente ou recomendado pela DPD, valide previamente os termos de uso, suporte, responsabilidade e manutenção.

---

## Créditos

Desenvolvido por **RGC Consulting** para integração DPD Portugal em PrestaShop.


## Registo técnico de instalação e contas DPD

Durante a instalação e ao guardar a configuração, o módulo envia à RGC Consulting um registo técnico simples com o domínio da loja, a data de instalação, a versão do módulo, a versão do PrestaShop e as contas DPD configuradas por serviço. Não são enviados dados de clientes, encomendas, credenciais DPD, tokens ou etiquetas.


## Verificação de atualizações

A partir da versão **1.0.3**, o módulo consegue verificar se existe uma versão mais recente.

O pacote mais recente deve ser publicado sempre neste endereço fixo:

```text
https://api.rgcconsulting.pt/dpd/module/latest/rgcdpdpt_v1.0.x.zip
```

O ficheiro pode manter o nome `rgcdpdpt_v1.0.x.zip`. O módulo descarrega o pacote apenas para verificação, lê a versão existente no ficheiro `rgcdpdpt/config.xml` e compara-a com a versão instalada.

Funcionamento:

- verificação automática ao abrir a configuração do módulo;
- intervalo máximo de uma verificação a cada 24 horas;
- botão **Procurar atualizações** para consulta manual;
- aviso quando existir uma versão mais recente;
- link para descarregar o pacote oficial;
- SHA-256 apresentado na aba **Diagnóstico**;
- nenhuma instalação automática ou substituição silenciosa de ficheiros.

Para disponibilizar uma atualização, gere o ZIP normalmente, mantendo dentro dele a pasta `rgcdpdpt` e o `config.xml` com a versão correta, e publique ou substitua o ficheiro no endereço fixo acima.

## Credenciais OAuth internas

O `client_id` e o `client_secret` técnicos definidos pela DPD são configurados automaticamente pelo módulo e não aparecem no backoffice. O cliente deve preencher apenas o utilizador e a password da API fornecidos pela DPD.

A partir da versão **1.0.5**, instalações anteriores com o `client_secret` em falta são reparadas automaticamente durante a atualização ou ao abrir a configuração do módulo.
