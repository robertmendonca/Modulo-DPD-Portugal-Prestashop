<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_5_6($module)
{
    return $module->registerHook('displayAdminOrderSideBottom')
        && $module->registerHook('displayBackOfficeHeader')
        && DpdSchema::install();
}
