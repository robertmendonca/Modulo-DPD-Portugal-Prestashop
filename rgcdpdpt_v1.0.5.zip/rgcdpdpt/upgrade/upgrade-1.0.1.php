<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_1($module)
{
    DpdConfig::ensureDefaults();
    DpdInstallReporter::report($module, true);
    return true;
}
