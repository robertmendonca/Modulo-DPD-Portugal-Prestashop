<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_7_16($module)
{
    return true;
}
