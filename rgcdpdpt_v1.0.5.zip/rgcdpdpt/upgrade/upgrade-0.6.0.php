<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_6_0($module)
{
    // Preserve current sensitive values in the new base64 storage format.
    foreach (['API_PASSWORD', 'CLIENT_SECRET', 'PICKUP_KEY'] as $name) {
        $value = DpdConfig::get($name, '');
        if ($value !== '') {
            DpdConfig::set($name, $value);
        }
    }

    return true;
}
