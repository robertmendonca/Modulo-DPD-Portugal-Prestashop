<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_5_1($module)
{
    DpdConfig::ensureDefaults();
    return true;
}
