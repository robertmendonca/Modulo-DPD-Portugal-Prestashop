<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_5($module)
{
    DpdConfig::ensureDefaults();
    DpdConfig::ensureInternalOAuthCredentials();

    if (class_exists('DpdUpdateChecker')) {
        DpdUpdateChecker::clearCache();
    }

    if (class_exists('DpdInstallReporter')) {
        DpdInstallReporter::report($module, true);
    }

    return true;
}
