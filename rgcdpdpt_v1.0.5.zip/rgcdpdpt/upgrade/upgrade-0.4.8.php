<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_4_8($module)
{
    foreach ([
        'displayBeforeCarrier',
        'displayAfterCarrier',
    ] as $hook) {
        $module->unregisterHook($hook);
    }

    $ok = true;
    foreach ([
        'displayCarrierExtraContent',
        'actionCarrierProcess',
        'actionValidateOrder',
        'displayHeader',
        'displayBackOfficeHeader',
        'displayAdminOrderSideBottom',
        'actionFrontControllerSetMedia',
    ] as $hook) {
        $ok = $ok && $module->registerHook($hook);
    }

    if (class_exists('DpdCarrierManager')) {
        $ok = $ok && (new DpdCarrierManager($module))->installOrRepair();
    }

    return $ok;
}
