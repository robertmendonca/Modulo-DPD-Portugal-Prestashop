<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_7_13($module)
{
    return true;
}
