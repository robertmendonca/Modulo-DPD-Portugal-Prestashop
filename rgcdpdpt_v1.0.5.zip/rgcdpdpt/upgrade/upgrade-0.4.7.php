<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_4_7($module)
{
    $hooks = [
        'displayCarrierExtraContent',
        'displayBeforeCarrier',
        'displayAfterCarrier',
        'actionFrontControllerSetMedia',
        'displayHeader',
    ];

    $ok = true;
    foreach ($hooks as $hook) {
        $ok = $ok && $module->registerHook($hook);
    }

    return $ok;
}
