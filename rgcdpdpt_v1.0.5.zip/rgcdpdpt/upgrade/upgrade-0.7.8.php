<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_7_8($module)
{
    if (class_exists('DpdConfig')) {
        DpdConfig::ensureDefaults();
    }

    return true;
}
