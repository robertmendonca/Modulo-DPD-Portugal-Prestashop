<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_3($module)
{
    DpdConfig::ensureDefaults();

    if (class_exists('DpdUpdateChecker')) {
        DpdUpdateChecker::clearCache();
    }

    if (class_exists('DpdInstallReporter')) {
        DpdInstallReporter::report($module, true);
    }

    return true;
}
