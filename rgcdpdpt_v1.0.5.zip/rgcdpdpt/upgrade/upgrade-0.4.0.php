<?php
function upgrade_module_0_4_0($module)
{
    if (!(bool) require dirname(__DIR__) . '/sql/install.php') {
        return false;
    }

    foreach (glob(dirname(__DIR__) . '/classes/*.php') as $classFile) {
        require_once $classFile;
    }

    DpdConfig::ensureDefaults();

    if (method_exists($module, 'registerHook')) {
        $module->registerHook('actionCarrierUpdate');
        $module->registerHook('displayCarrierExtraContent');
        $module->registerHook('actionCarrierProcess');
        $module->registerHook('actionValidateOrder');
        $module->registerHook('displayHeader');
        $module->registerHook('displayBackOfficeHeader');
        $module->registerHook('displayAdminOrderSideBottom');
        $module->registerHook('actionFrontControllerSetMedia');
    }

    if (class_exists('DpdCarrierManager')) {
        return (new DpdCarrierManager($module))->installOrRepair();
    }

    return true;
}
