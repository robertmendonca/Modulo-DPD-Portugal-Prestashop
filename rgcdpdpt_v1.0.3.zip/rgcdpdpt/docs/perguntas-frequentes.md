# Perguntas frequentes

## O módulo é gratuito?

Sim. O módulo é disponibilizado gratuitamente.

## O suporte é gratuito?

Há 15 minutos gratuitos de apoio inicial pela DPD. Depois disso, o suporte adicional é cobrado em packs de 30 minutos por 20 EUR + IVA.

## Posso usar o módulo sem dados da DPD?

Pode instalar, mas não conseguirá criar expedições reais sem credenciais e contas DPD válidas.

## Onde peço os dados de acesso?

Peça diretamente à DPD o utilizador da API, a password da API e as contas DPD dos serviços contratados.

## Quais dados preciso pedir à DPD?

Peça:

- utilizador da API;
- password da API;
- contas DPD de 8 dígitos por serviço;
- confirmação dos serviços contratados;
- confirmação de contrato Pickup/Shop, caso pretenda usar Pickup;
- confirmação de contrato DPD Fresh, caso pretenda usar Fresh.

## O que são as contas DPD de 8 dígitos?

São os códigos de conta usados para cada serviço DPD. Por exemplo, uma conta para Portugal Home e outra para Portugal Shop/Pickup.

## Posso ativar só alguns serviços?

Sim. Ative apenas os serviços contratados e configurados com contas válidas.

## Posso ativar Pickup sem contrato?

Não. A secção Pickup deve ser ativada apenas quando o cliente tiver contrato DPD para serviços Pickup/Shop.

## O módulo suporta Portugal Ilhas?

Sim, existe serviço específico para Portugal Ilhas, desde que a conta DPD correspondente esteja configurada.

## O módulo suporta Espanha e Internacional?

Sim, desde que os serviços estejam contratados e configurados.

## O mapa Pickup aparece automaticamente?

Sim. Quando o cliente seleciona uma forma de entrega Pickup/Shop, o mapa aparece automaticamente. O botão de pesquisa serve para atualizar os pontos, por exemplo quando o código postal é alterado.

## A expedição é criada automaticamente?

Não. A criação da expedição é manual no backoffice da encomenda.

## O módulo envia algum registo durante a instalação?

Sim. Durante a instalação, o módulo envia um registo técnico simples para a RGC Consulting com domínio da loja, data/hora da instalação, versão do módulo, versão do PrestaShop e identificador técnico da instalação.

Não são enviados dados de clientes, encomendas, credenciais DPD, tokens ou etiquetas.

## O que faço se aparecer erro de permissão Pickup?

Confirme com a DPD se a conta configurada tem autorização para criar expedições Pickup/Shop.

## Devo publicar as credenciais no GitHub para pedir ajuda?

Não. Nunca publique credenciais, tokens, etiquetas reais ou dados pessoais.

## O módulo suporta DPD Fresh?

Sim. A partir da versão 1.0.2 existe o serviço **DPD Portugal Fresh** como conta configurável.

Quando uma encomenda usa DPD Fresh, o módulo envia `fresh_pickup_date` com D+1 e `fresh_expiration_date` com validade D+5 por defeito. A validade pode ser ajustada na aba **Operação**.
