<?php
class DpdInstallReporter
{
    public static function report($module)
    {
        if ((int) DpdConfig::get('INSTALL_REPORTED', 0) === 1) {
            return true;
        }

        $endpoint = trim((string) DpdConfig::get('INSTALL_REPORT_ENDPOINT'));
        if ($endpoint === '') {
            return true;
        }

        if (self::recentFailedAttempt()) {
            return true;
        }

        DpdConfig::set('INSTALL_LAST_REPORT_ATTEMPT', gmdate('c'));

        $payload = self::buildPayload($module);
        $result = self::postJson($endpoint, $payload);

        if ($result['ok']) {
            DpdConfig::set('INSTALL_REPORTED', '1');
            DpdConfig::set('INSTALL_REPORTED_AT', gmdate('c'));
            DpdConfig::set('INSTALL_LAST_REPORT_ERROR', '');
            return true;
        }

        DpdConfig::set('INSTALL_LAST_REPORT_ERROR', Tools::substr((string) $result['error'], 0, 250));
        return true;
    }


    protected static function recentFailedAttempt()
    {
        $lastAttempt = trim((string) DpdConfig::get('INSTALL_LAST_REPORT_ATTEMPT'));
        if ($lastAttempt === '') {
            return false;
        }

        $timestamp = strtotime($lastAttempt);
        if ($timestamp === false) {
            return false;
        }

        return (time() - $timestamp) < 86400;
    }

    protected static function buildPayload($module)
    {
        return [
            'module' => isset($module->name) ? (string) $module->name : 'rgcdpdpt',
            'module_version' => isset($module->version) ? (string) $module->version : '',
            'prestashop_version' => defined('_PS_VERSION_') ? (string) _PS_VERSION_ : '',
            'shop_url' => self::shopUrl(),
            'installed_at' => self::installedAt(),
            'install_id' => self::installId(),
        ];
    }


    protected static function installedAt()
    {
        $current = trim((string) DpdConfig::get('INSTALL_CREATED_AT'));
        if ($current !== '') {
            return $current;
        }

        $createdAt = gmdate('c');
        DpdConfig::set('INSTALL_CREATED_AT', $createdAt);
        return $createdAt;
    }

    protected static function installId()
    {
        $current = trim((string) DpdConfig::get('INSTALL_ID'));
        if ($current !== '') {
            return $current;
        }

        $id = self::generateUuidV4();
        DpdConfig::set('INSTALL_ID', $id);
        return $id;
    }

    protected static function generateUuidV4()
    {
        if (function_exists('random_bytes')) {
            try {
                $data = random_bytes(16);
                $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
                $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
                return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
            } catch (Exception $e) {
                // Fallback below.
            }
        }

        return md5(uniqid('', true) . microtime(true));
    }

    protected static function shopUrl()
    {
        if (class_exists('Tools')) {
            $url = trim((string) Tools::getShopDomainSsl(true, true));
            if ($url !== '') {
                return $url;
            }
        }

        $domain = '';
        if (class_exists('Configuration')) {
            $domain = trim((string) Configuration::get('PS_SHOP_DOMAIN_SSL'));
            if ($domain === '') {
                $domain = trim((string) Configuration::get('PS_SHOP_DOMAIN'));
            }
        }

        return $domain !== '' ? 'https://' . $domain : '';
    }

    protected static function postJson($endpoint, array $payload)
    {
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            return ['ok' => false, 'error' => 'json_encode failed'];
        }

        if (function_exists('curl_init')) {
            $ch = curl_init($endpoint);
            if (!$ch) {
                return ['ok' => false, 'error' => 'curl_init failed'];
            }

            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Accept: application/json',
                'User-Agent: rgcdpdpt-install-reporter/1.0.0',
            ]);

            curl_exec($ch);
            $errno = (int) curl_errno($ch);
            $error = (string) curl_error($ch);
            $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($errno === 0 && $status >= 200 && $status < 300) {
                return ['ok' => true, 'error' => ''];
            }

            return ['ok' => false, 'error' => 'HTTP ' . $status . ($error !== '' ? ' - ' . $error : '')];
        }

        return ['ok' => false, 'error' => 'cURL not available'];
    }
}
