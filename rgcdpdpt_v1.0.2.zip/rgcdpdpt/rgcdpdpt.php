<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

foreach (glob(__DIR__ . '/classes/*.php') as $classFile) {
    require_once $classFile;
}

class Rgcdpdpt extends CarrierModule
{
    public $id_carrier = 0;

    public function __construct()
    {
        $this->name = 'rgcdpdpt';
        $this->tab = 'shipping_logistics';
        $this->version = '1.0.2';
        $this->author = 'RGC Consulting';
        $this->need_instance = 1;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('RGC DPD PT');
        $this->description = $this->l('Integração DPD Portugal para PrestaShop 8.2.x');
        $this->ps_versions_compliancy = [
            'min' => '8.0.0',
            'max' => _PS_VERSION_,
        ];
    }

    public function install()
    {
        if (!parent::install()) {
            return false;
        }

        if (!require __DIR__ . '/sql/install.php') {
            return false;
        }

        DpdConfig::installDefaults();
        DpdInstallReporter::report($this);

        $ok = $this->registerHook('actionCarrierUpdate')
            && $this->registerHook('displayCarrierExtraContent')
            && $this->registerHook('actionCarrierProcess')
            && $this->registerHook('actionValidateOrder')
            && $this->registerHook('displayHeader')
            && $this->registerHook('displayBackOfficeHeader')
            && $this->registerHook('displayAdminOrderSideBottom')
            && $this->registerHook('actionFrontControllerSetMedia');

        $ok = $ok && $this->installTabs();
        $ok = $ok && (new DpdCarrierManager($this))->installOrRepair();

        return $ok;
    }

    public function uninstall()
    {
        (new DpdCarrierManager($this))->uninstall();
        $this->uninstallTabs();
        DpdConfig::removeAll();
        require __DIR__ . '/sql/uninstall.php';

        return parent::uninstall();
    }

    protected function installTabs()
    {
        $className = 'AdminRgcDpdptAjax';
        $idParent = (int) Tab::getIdFromClassName('AdminParentModulesSf');

        $existing = (int) Tab::getIdFromClassName($className);
        if ($existing > 0) {
            return true;
        }

        $tab = new Tab();
        $tab->class_name = $className;
        $tab->module = $this->name;
        $tab->id_parent = $idParent ?: 0;
        $tab->active = 0;
        foreach (Language::getLanguages(true) as $lang) {
            $tab->name[(int) $lang['id_lang']] = 'RGC DPD PT Ajax';
        }

        return $tab->add();
    }

    protected function uninstallTabs()
    {
        $idTab = (int) Tab::getIdFromClassName('AdminRgcDpdptAjax');
        if ($idTab > 0) {
            $tab = new Tab($idTab);
            return $tab->delete();
        }

        return true;
    }

    protected function ensureSchema()
    {
        return DpdSchema::install();
    }

    public function getContent()
    {
        $html = '';

        if ($this->ensureSchema()) {
            DpdConfig::ensureDefaults();
            DpdInstallReporter::report($this);
        }

        if (Tools::isSubmit('submitRgcdpdptConfig')) {
            $this->saveConfiguration();
            (new DpdCarrierManager($this))->installOrRepair();
            DpdInstallReporter::report($this, true);
            $html .= $this->displayConfirmation($this->l('Configurações guardadas. Portes e transportadoras sincronizados.'));
        }

        if (Tools::isSubmit('submitRgcdpdptRepair')) {
            (new DpdCarrierManager($this))->installOrRepair();
            $html .= $this->displayConfirmation($this->l('Transportadoras reparadas.'));
        }

        if (Tools::isSubmit('submitRgcdpdptTestOAuth')) {
            $this->saveConfiguration();
            try {
                $token = (new DpdAuthClient())->getAccessToken();
                $preview = Tools::substr((string) $token, 0, 12);
                $html .= $this->displayConfirmation($this->l('OAuth DPD OK. Token recebido: ') . Tools::safeOutput($preview) . '...');
            } catch (Exception $e) {
                DpdLogRepository::add('error', $e->getMessage(), 'oauth', 0);
                $html .= $this->displayError($e->getMessage());
            }
        }

        $html .= $this->renderConfiguration();

        return $html;
    }

    protected function saveConfiguration()
    {
        foreach (array_keys(DpdConfig::definitions()) as $name) {
            $key = DpdConfig::key($name);
            if (Tools::getIsset($key)) {
                DpdConfig::set($name, $this->getSubmittedConfigValue($name, $key));
            }
        }
    }

    protected function getSubmittedConfigValue($name, $key)
    {
        if (DpdConfig::isSensitiveField($name) && isset($_POST[$key])) {
            // Do not use Tools::getValue() for secrets. Some PrestaShop flows sanitize
            // values containing '<', so passwords like 8}F<h9-%03f" may be truncated.
            return (string) $_POST[$key];
        }

        return Tools::getValue($key);
    }

    protected function renderConfiguration()
    {
        $values = DpdConfig::all();
        $html = '';

        $tabs = [
            'rgcdpdpt-dpd' => $this->l('DPD'),
            'rgcdpdpt-services' => $this->l('Contas DPD'),
            'rgcdpdpt-shipper' => $this->l('Dados do expedidor'),
            'rgcdpdpt-operation' => $this->l('Operação'),
            'rgcdpdpt-rates' => $this->l('Portes'),
            'rgcdpdpt-diagnostic' => $this->l('Diagnóstico'),
        ];

        $html .= '<ul class="nav nav-tabs rgcdpdpt-admin-tabs" role="tablist">';
        $isFirstTab = true;
        foreach ($tabs as $tabId => $tabLabel) {
            $html .= '<li role="presentation"' . ($isFirstTab ? ' class="active"' : '') . '>'
                . '<a href="#' . $this->escapeAttribute($tabId) . '" aria-controls="' . $this->escapeAttribute($tabId) . '" role="tab" data-toggle="tab">'
                . Tools::safeOutput($tabLabel)
                . '</a></li>';
            $isFirstTab = false;
        }
        $html .= '</ul>';

        $html .= '<form method="post" class="rgcdpdpt-admin-form">';
        $html .= '<div class="tab-content rgcdpdpt-tab-content">';
        $html .= '<div role="tabpanel" class="tab-pane active" id="rgcdpdpt-dpd"><div class="panel"><h3>' . $this->l('DPD') . '</h3>';
        $html .= '<p class="help-block">Configure aqui as credenciais fornecidas pela DPD.</p>';
        $html .= $this->input('API_USERNAME', 'Utilizador da API', 'text', $values['API_USERNAME']);
        $html .= $this->input('API_PASSWORD', 'Password da API', $this->passwordFieldType(), $values['API_PASSWORD']);
        $html .= '</div></div>';

        $html .= '<div role="tabpanel" class="tab-pane" id="rgcdpdpt-services"><div class="panel"><h3>' . $this->l('Contas DPD') . '</h3>';
        $html .= '<p class="help-block">Configure as contas DPD de 8 dígitos, o nome visível e a ativação de cada serviço.</p>';
        $html .= $this->renderServiceAccountsSections($values);
        $html .= '</div></div>';

        $html .= '<div role="tabpanel" class="tab-pane" id="rgcdpdpt-shipper"><div class="panel"><h3>' . $this->l('Dados do expedidor') . '</h3>';
        $html .= '<p class="help-block">Configure os dados do expedidor que serão utilizados pela DPD como origem das expedições, recolhas e etiquetas. Estes dados devem corresponder à morada e aos contactos associados ao contrato DPD.</p>';
        $html .= $this->input('SENDER_NAME', 'Nome do remetente', 'text', $values['SENDER_NAME']);
        $html .= $this->input('SENDER_EMAIL', 'E-mail do remetente', 'text', $values['SENDER_EMAIL']);
        $html .= $this->input('SENDER_PHONE', 'Telefone do remetente', 'text', $values['SENDER_PHONE']);
        $html .= $this->input('SENDER_PHONE_CODE', 'Indicativo do telefone do remetente', 'text', $values['SENDER_PHONE_CODE']);
        $html .= $this->input('SENDER_MOBILE', 'Telemóvel do remetente', 'text', $values['SENDER_MOBILE']);
        $html .= $this->input('SENDER_MOBILE_CODE', 'Indicativo do telemóvel do remetente', 'text', $values['SENDER_MOBILE_CODE']);
        $html .= $this->input('SHIPPER_NAME', 'Nome do expedidor', 'text', $values['SHIPPER_NAME']);
        $html .= $this->input('SHIPPER_ADDRESS', 'Morada do expedidor', 'text', $values['SHIPPER_ADDRESS']);
        $html .= $this->input('SHIPPER_ZIP', 'Código postal do expedidor', 'text', $values['SHIPPER_ZIP']);
        $html .= $this->input('SHIPPER_CITY', 'Localidade do expedidor', 'text', $values['SHIPPER_CITY']);
        $html .= $this->input('SHIPPER_COUNTRY_ISO2', 'País do expedidor - ISO2', 'text', $values['SHIPPER_COUNTRY_ISO2']);
        $html .= '</div></div>';

        $html .= '<div role="tabpanel" class="tab-pane" id="rgcdpdpt-operation"><div class="panel"><h3>' . $this->l('Operação') . '</h3>';
        $html .= $this->input('MAX_WEIGHT', 'Peso máximo (kg)', 'text', $values['MAX_WEIGHT']);
        $html .= $this->input('ENABLE_PREDICT', 'Predict (0/1)', 'text', $values['ENABLE_PREDICT']);
        $html .= $this->input('FRESH_EXPIRATION_DAYS', 'Validade Fresh (dias)', 'text', $values['FRESH_EXPIRATION_DAYS']);
        $html .= '<p class="help-block">Usado apenas para DPD Fresh. Por defeito, a validade enviada à DPD é D+5. Se o cliente tiver solicitado uma validade inferior, ajuste este valor.</p>';
        $html .= $this->input('DEFAULT_VOLUMES', 'Volumes por defeito', 'text', $values['DEFAULT_VOLUMES']);
        $html .= $this->input('LABEL_FORMAT_ID', 'Formato da etiqueta (1/2/3)', 'text', $values['LABEL_FORMAT_ID']);
        $html .= $this->input('LOG_ENABLED', 'Logs (0/1)', 'text', $values['LOG_ENABLED']);
        $html .= '</div></div>';


        $html .= '<div role="tabpanel" class="tab-pane" id="rgcdpdpt-rates"><div class="panel"><h3>' . $this->l('Portes') . '</h3>';
        $html .= '<p class="help-block">Defina o preço base por serviço DPD. O módulo utiliza apenas os serviços configurados na aba Contas DPD.</p>';
        $html .= $this->renderServiceRatesTable($values);
        $html .= '</div></div>';

        $html .= '<div role="tabpanel" class="tab-pane" id="rgcdpdpt-diagnostic"><div class="panel"><h3>' . $this->l('Diagnóstico') . '</h3>';
        $html .= $this->renderDiagnosticServices();
        $html .= '<p><strong>Comprimento da password da API guardada:</strong> ' . (int) strlen((string) DpdConfig::get('API_PASSWORD')) . ' caracteres</p>';
        $html .= '<p><small>Ao guardar, o módulo também atualiza as transportadoras DPD para não ficarem marcadas como grátis no PrestaShop.</small></p>';
        $html .= '<p><strong>Últimos logs:</strong></p><ul>';
        foreach (DpdLogRepository::latest(10) as $log) {
            $html .= '<li>[' . Tools::safeOutput($log['level']) . '] ' . Tools::safeOutput($log['message']) . ' - ' . Tools::safeOutput($log['date_add']);
            if (!empty($log['payload'])) {
                $html .= '<br><small><code>' . Tools::safeOutput(Tools::substr((string) $log['payload'], 0, 800)) . '</code></small>';
            }
            $html .= '</li>';
        }
        $html .= '</ul></div></div>';
        $html .= '</div>';

        $html .= '<div class="panel rgcdpdpt-actions-panel">';
        $html .= '<button class="btn btn-primary" type="submit" name="submitRgcdpdptConfig">' . $this->l('Guardar configurações') . '</button> ';
        $html .= '<button class="btn btn-default" type="submit" name="submitRgcdpdptRepair">' . $this->l('Reparar transportadoras') . '</button> ';
        $html .= '<button class="btn btn-default" type="submit" name="submitRgcdpdptTestOAuth">' . $this->l('Testar OAuth DPD') . '</button>';
        $html .= '</div>';
        $html .= '</form>';

        return $html;
    }

    protected function renderServiceAccountsSections(array $values)
    {
        $pickupWarning = $this->l('Ative o conteúdo Pickup apenas se o cliente tiver contrato com a DPD para este serviço. Deseja continuar?');
        $pickupOpen = (int) ($values['PICKUP_CONFIG_OPEN'] ?? 0) === 1;
        $pickupStateKey = DpdConfig::key('PICKUP_CONFIG_OPEN');
        $pickupButtonClass = $pickupOpen ? 'btn btn-default rgcdpdpt-enable-pickup-config is-active' : 'btn btn-warning rgcdpdpt-enable-pickup-config';
        $pickupButtonLabel = $pickupOpen ? $this->l('Desativar conteúdo Pickup') : $this->l('Ativar conteúdo Pickup');
        $pickupConfigClass = $pickupOpen ? 'rgcdpdpt-pickup-config is-active' : 'rgcdpdpt-pickup-config';
        $pickupConfigStyle = $pickupOpen ? 'display:block;' : 'display:none;';
        $pickupAriaExpanded = $pickupOpen ? 'true' : 'false';
        $pickupAriaHidden = $pickupOpen ? 'false' : 'true';

        $html = '<div class="rgcdpdpt-service-section rgcdpdpt-service-section-home">';
        $html .= '<h4>' . $this->l('Home') . '</h4>';
        $html .= '<p class="help-block">' . $this->l('Serviços de entrega ao domicílio.') . '</p>';
        $html .= $this->renderServiceAccountsTable($values, 'home');
        $html .= '</div>';

        $html .= '<div class="rgcdpdpt-service-section rgcdpdpt-service-section-pickup">';
        $html .= '<h4>' . $this->l('Pickup') . '</h4>';
        $html .= '<p class="help-block">' . $this->l('Serviços de entrega em ponto Pickup.') . '</p>';
        $html .= '<div class="alert alert-warning rgcdpdpt-pickup-activation-notice">' . $this->l('Ative e configure os serviços Pickup apenas se tiver contrato com a DPD para este serviço.') . '</div>';
        $html .= '<input type="hidden" class="rgcdpdpt-pickup-config-state" id="' . $this->escapeAttribute($pickupStateKey) . '" name="' . $this->escapeAttribute($pickupStateKey) . '" value="' . ($pickupOpen ? '1' : '0') . '">';
        $html .= '<button type="button" class="' . $pickupButtonClass . '" data-warning="' . $this->escapeAttribute($pickupWarning) . '" data-inactive-label="' . $this->escapeAttribute($this->l('Ativar conteúdo Pickup')) . '" data-active-label="' . $this->escapeAttribute($this->l('Desativar conteúdo Pickup')) . '" aria-expanded="' . $pickupAriaExpanded . '">' . $pickupButtonLabel . '</button>';
        $html .= '<div class="' . $pickupConfigClass . '" style="' . $pickupConfigStyle . '" aria-hidden="' . $pickupAriaHidden . '">';
        $html .= $this->renderServiceAccountsTable($values, 'pickup');
        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }

    protected function renderServiceAccountsTable(array $values, $delivery = null)
    {
        $html = '<div class="table-responsive"><table class="table">';
        $html .= '<thead><tr><th>Serviço DPD</th><th>Ativo</th><th>Conta DPD</th><th>Nome visível</th></tr></thead><tbody>';

        foreach (DpdConfig::serviceDefinitions() as $type => $definition) {
            if ($delivery !== null && ($definition['delivery'] ?? 'home') !== $delivery) {
                continue;
            }

            $suffix = DpdConfig::serviceKeySuffix($type);
            $enabled = 'SERVICE_' . $suffix . '_ENABLED';
            $account = 'SERVICE_' . $suffix . '_ACCOUNT';
            $name = 'SERVICE_' . $suffix . '_NAME';
            $html .= '<tr>';
            $html .= '<td><strong>' . Tools::safeOutput($definition['label']) . '</strong></td>';
            $html .= '<td>' . $this->checkboxInput($enabled, (int) ($values[$enabled] ?? 0)) . '</td>';
            $html .= '<td>' . $this->plainInput($account, 'text', $values[$account] ?? '', ' maxlength="8" pattern="[0-9]{8}" placeholder="09999001"') . '</td>';
            $html .= '<td>' . $this->plainInput($name, 'text', $values[$name] ?? '') . '</td>';
            $html .= '</tr>';
        }

        $html .= '</tbody></table></div>';
        return $html;
    }

    protected function renderServiceRatesTable(array $values)
    {
        $html = '<div class="table-responsive"><table class="table">';
        $html .= '<thead><tr><th>Serviço</th><th>Preço base</th><th>Conta configurada</th></tr></thead><tbody>';

        foreach (DpdConfig::serviceDefinitions() as $type => $definition) {
            $suffix = DpdConfig::serviceKeySuffix($type);
            $rate = 'RATE_' . $suffix;
            $account = DpdConfig::serviceAccount($type);
            $html .= '<tr>';
            $html .= '<td><strong>' . Tools::safeOutput($definition['label']) . '</strong></td>';
            $html .= '<td>' . $this->plainInput($rate, 'text', $values[$rate] ?? '', ' placeholder="0,00"') . '</td>';
            $html .= '<td>' . Tools::safeOutput($account !== '' ? $account : '-') . '</td>';
            $html .= '</tr>';
        }

        $html .= '</tbody></table></div>';
        return $html;
    }

    protected function renderDiagnosticServices()
    {
        $manager = new DpdCarrierManager($this);
        $html = '<div class="table-responsive"><table class="table">';
        $html .= '<thead><tr><th>Serviço</th><th>Ativo</th><th>Conta</th><th>ID da transportadora</th><th>Referência da transportadora</th></tr></thead><tbody>';

        foreach (DpdConfig::serviceDefinitions() as $type => $definition) {
            $meta = $manager->getCarrierMeta($type, false);
            $html .= '<tr>';
            $html .= '<td>' . Tools::safeOutput($definition['label']) . '</td>';
            $html .= '<td>' . (DpdConfig::isServiceEnabled($type) ? 'Sim' : 'Não') . '</td>';
            $html .= '<td>' . Tools::safeOutput(DpdConfig::serviceAccount($type) ?: '-') . '</td>';
            $html .= '<td>' . (int) ($meta['id'] ?? 0) . '</td>';
            $html .= '<td>' . (int) ($meta['id_reference'] ?? 0) . '</td>';
            $html .= '</tr>';
        }

        $html .= '</tbody></table></div>';
        return $html;
    }

    protected function checkboxInput($name, $checked)
    {
        $key = DpdConfig::key($name);
        return '<input type="hidden" name="' . $this->escapeAttribute($key) . '" value="0">'
            . '<input type="checkbox" value="1" id="' . $this->escapeAttribute($key) . '" name="' . $this->escapeAttribute($key) . '"' . ((int) $checked ? ' checked="checked"' : '') . '>';
    }

    protected function plainInput($name, $type, $value, $extra = '')
    {
        $key = DpdConfig::key($name);
        $autocomplete = ($type === 'password') ? ' autocomplete="new-password"' : '';
        return '<input class="form-control" type="' . $this->escapeAttribute($type) . '" id="' . $this->escapeAttribute($key) . '" name="' . $this->escapeAttribute($key) . '" value="' . $this->escapeAttribute((string) $value) . '"' . $autocomplete . $extra . '>';
    }

    protected function passwordFieldType()
    {
        return version_compare(_PS_VERSION_, '8.0.0', '>=') ? 'password' : 'text';
    }

    protected function input($name, $label, $type, $value)
    {
        $key = DpdConfig::key($name);
        $autocomplete = ($type === 'password') ? ' autocomplete="new-password"' : '';

        return '
            <div class="form-group">
              <label for="' . $this->escapeAttribute($key) . '">' . Tools::safeOutput($label) . '</label>
              <input class="form-control" type="' . $this->escapeAttribute($type) . '" id="' . $this->escapeAttribute($key) . '" name="' . $this->escapeAttribute($key) . '" value="' . $this->escapeAttribute((string) $value) . '"' . $autocomplete . '>
            </div>';
    }

    protected function escapeAttribute($value)
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }

    protected function registerFrontAssets()
    {
        if (!isset($this->context->controller)) {
            return;
        }


        $this->context->controller->registerJavascript(
            'module-rgcdpdpt-front-v056',
            'modules/' . $this->name . '/views/js/front-v056.js',
            ['position' => 'bottom', 'priority' => 150]
        );

        $this->context->controller->registerStylesheet(
            'module-rgcdpdpt-front-css-v053',
            'modules/' . $this->name . '/views/css/front-v054.css',
            ['media' => 'all', 'priority' => 150]
        );
    }

    public function hookActionFrontControllerSetMedia()
    {
        $this->registerFrontAssets();
    }

    public function hookDisplayHeader()
    {
        $this->registerFrontAssets();
        return '';
    }

    public function hookDisplayBackOfficeHeader()
    {
        if (Tools::getValue('controller') === 'AdminModules' || Tools::getValue('controller') === 'AdminOrders') {
            $this->context->controller->addCSS($this->_path . 'views/css/admin-v100.css');
            $this->context->controller->addJS($this->_path . 'views/js/admin-v100.js');
        }
    }

    public function hookActionCarrierUpdate($params)
    {
        $oldId = (int) $params['id_carrier'];
        $newId = (int) $params['carrier']->id;
        $carrierManager = new DpdCarrierManager($this);

        foreach (DpdConfig::serviceTypes() as $type) {
            $idKey = DpdConfig::carrierIdKey($type);
            $refKey = DpdConfig::carrierRefKey($type);
            if ($oldId === (int) DpdConfig::get($idKey, 0)) {
                DpdConfig::set($idKey, $newId);
                DpdConfig::set($refKey, (int) $params['carrier']->id_reference);
                $carrierManager->syncCarrierLogoForType($type, $newId);
            }
        }
    }

    public function getOrderShippingCost($params, $shippingCost)
    {
        return $this->resolveShippingCost($params);
    }

    public function getOrderShippingCostExternal($params)
    {
        return $this->resolveShippingCost($params);
    }

    public function getPackageShippingCost($params, $shippingCost, $products = null)
    {
        return $this->resolveShippingCost($params);
    }

    protected function resolveShippingCost($cart)
    {
        if (!$cart || !Validate::isLoadedObject($cart)) {
            return false;
        }

        $idAddress = (int) $cart->id_address_delivery;
        $address = $idAddress ? new Address($idAddress) : null;
        if (!$address || !Validate::isLoadedObject($address)) {
            return false;
        }

        if (DpdConfig::addressCountryIso2($address) === '') {
            return false;
        }

        $weight = (float) $cart->getTotalWeight();
        $maxWeight = DpdConfig::maxWeight();
        if ($maxWeight > 0 && $weight > $maxWeight) {
            return false;
        }

        $carrierType = $this->detectCurrentCarrierType($cart);
        if (!DpdConfig::isServiceEnabled($carrierType)) {
            return false;
        }

        if (!DpdConfig::supportsAddress($carrierType, $address)) {
            return false;
        }

        if (DpdConfig::serviceAccount($carrierType) === '') {
            return false;
        }

        $bucket = DpdZoneResolver::resolveByPostcode($address->postcode);
        return DpdConfig::serviceRate($carrierType, $bucket);
    }

    protected function detectCurrentCarrierType($cart = null)
    {
        $candidateIds = [];

        if ((int) $this->id_carrier > 0) {
            $candidateIds[] = (int) $this->id_carrier;
        }

        if ($cart instanceof Cart && (int) $cart->id_carrier > 0) {
            $candidateIds[] = (int) $cart->id_carrier;
        }

        if (
            isset($this->context)
            && isset($this->context->cart)
            && Validate::isLoadedObject($this->context->cart)
            && (int) $this->context->cart->id_carrier > 0
        ) {
            $candidateIds[] = (int) $this->context->cart->id_carrier;
        }

        $candidateIds = array_values(array_unique(array_filter($candidateIds)));
        $carrierManager = new DpdCarrierManager($this);

        foreach ($candidateIds as $carrierId) {
            $matched = $carrierManager->getMatchedType($carrierId, 0, '');
            if ($matched !== '') {
                return $matched;
            }

            $matchedByReference = $carrierManager->getMatchedType(0, $carrierId, '');
            if ($matchedByReference !== '') {
                return $matchedByReference;
            }
        }

        return DpdCarrierManager::TYPE_HOME;
    }

    protected function extractCarrierMeta($carrier)
    {
        $id = 0;
        $idReference = 0;
        $externalModuleName = '';
        $name = '';

        if (is_array($carrier)) {
            $id = (int) ($carrier['id'] ?? $carrier['id_carrier'] ?? 0);
            $idReference = (int) ($carrier['id_reference'] ?? 0);
            $externalModuleName = (string) ($carrier['external_module_name'] ?? '');
            $name = (string) ($carrier['name'] ?? '');

            if (isset($carrier['instance']) && $carrier['instance'] instanceof Carrier) {
                $id = $id ?: (int) $carrier['instance']->id;
                $idReference = $idReference ?: (int) $carrier['instance']->id_reference;
                $externalModuleName = $externalModuleName ?: (string) $carrier['instance']->external_module_name;
                $name = $name ?: (string) $carrier['instance']->name;
            }
        } elseif ($carrier instanceof Carrier) {
            $id = (int) $carrier->id;
            $idReference = (int) $carrier->id_reference;
            $externalModuleName = (string) $carrier->external_module_name;
            $name = (string) $carrier->name;
        }

        return [$id, $idReference, $externalModuleName, $name];
    }

    protected function isCarrierOfType($carrierId, $type)
    {
        $carrierId = (int) $carrierId;
        if ($carrierId <= 0) {
            return false;
        }

        $carrier = new Carrier($carrierId);
        if (!Validate::isLoadedObject($carrier)) {
            return false;
        }

        return (new DpdCarrierManager($this))->matchesType(
            (int) $carrier->id,
            (int) $carrier->id_reference,
            $type,
            (string) $carrier->name
        );
    }

    public function hookDisplayCarrierExtraContent($params)
    {
        if (empty($params['carrier'])) {
            return '';
        }

        [$carrierId, $carrierReference, $externalModuleName, $carrierName] = $this->extractCarrierMeta($params['carrier']);

        if ($externalModuleName && $externalModuleName !== $this->name) {
            return '';
        }

        $carrierManager = new DpdCarrierManager($this);
        $matchedType = $carrierManager->getMatchedType($carrierId, $carrierReference, $carrierName);
        if ($matchedType === '' || !DpdConfig::isPickupService($matchedType)) {
            return '';
        }

        if (!isset($this->context->cart) || !Validate::isLoadedObject($this->context->cart)) {
            return '';
        }

        $selected = DpdPickupRepository::getByCartId((int) $this->context->cart->id);
        $deliveryPostcode = '';
        $deliveryAddress = '';
        $deliveryCity = '';

        if ((int) $this->context->cart->id_address_delivery > 0) {
            $address = new Address((int) $this->context->cart->id_address_delivery);
            if (Validate::isLoadedObject($address)) {
                $deliveryPostcode = (string) $address->postcode;
                $deliveryAddress = trim((string) $address->address1 . ' ' . (string) $address->address2);
                $deliveryCity = (string) $address->city;
            }
        }

        $this->smarty->assign([
            'pickup_ajax_url' => $this->context->link->getModuleLink($this->name, 'pickup', ['ajax' => 1], true),
            'selected_pickup' => $selected ?: [],
            'delivery_postcode' => $deliveryPostcode,
            'delivery_address' => $deliveryAddress,
            'delivery_city' => $deliveryCity,
            'rgcdpdpt_is_fallback' => false,
            'rgcdpdpt_pickup_carrier_id' => (int) $carrierId,
            'rgcdpdpt_pickup_carrier_ref' => (int) $carrierReference,
            'rgcdpdpt_pickup_marker_icon' => $this->_path . 'views/img/pickup-marker-dpd.png',
            'rgcdpdpt_instance' => 'extra',
        ]);

        return $this->fetch('module:' . $this->name . '/views/templates/hook/carrier_extra.tpl');
    }

    public function hookDisplayBeforeCarrier($params)
    {
        return '';
    }

    public function hookDisplayAfterCarrier($params)
    {
        return '';
    }
    protected function renderPickupFallbackWidget($position = 'after')
    {
        if (!isset($this->context->cart) || !Validate::isLoadedObject($this->context->cart)) {
            return '';
        }

        // Prefer displayAfterCarrier. displayBeforeCarrier is registered only as a safety net.
        if ($position !== 'after') {
            return '';
        }

        $selected = DpdPickupRepository::getByCartId((int) $this->context->cart->id);
        $deliveryPostcode = '';
        $deliveryAddress = '';
        $deliveryCity = '';

        if ((int) $this->context->cart->id_address_delivery > 0) {
            $address = new Address((int) $this->context->cart->id_address_delivery);
            if (Validate::isLoadedObject($address)) {
                $deliveryPostcode = (string) $address->postcode;
                $deliveryAddress = trim((string) $address->address1 . ' ' . (string) $address->address2);
                $deliveryCity = (string) $address->city;
            }
        }

        $manager = new DpdCarrierManager($this);
        $pickupMeta = ['id' => 0, 'id_reference' => 0];
        foreach (DpdConfig::pickupServiceTypes() as $pickupType) {
            if (!DpdConfig::isServiceEnabled($pickupType)) {
                continue;
            }
            $pickupMeta = $manager->getCarrierMeta($pickupType);
            break;
        }

        $this->smarty->assign([
            'pickup_ajax_url' => $this->context->link->getModuleLink($this->name, 'pickup', ['ajax' => 1], true),
            'selected_pickup' => $selected ?: [],
            'delivery_postcode' => $deliveryPostcode,
            'delivery_address' => $deliveryAddress,
            'delivery_city' => $deliveryCity,
            'rgcdpdpt_is_fallback' => true,
            'rgcdpdpt_pickup_carrier_id' => (int) ($pickupMeta['id'] ?? 0),
            'rgcdpdpt_pickup_carrier_ref' => (int) ($pickupMeta['id_reference'] ?? 0),
            'rgcdpdpt_pickup_marker_icon' => $this->_path . 'views/img/pickup-marker-dpd.png',
            'rgcdpdpt_instance' => 'fallback',
        ]);

        return $this->fetch('module:' . $this->name . '/views/templates/hook/carrier_extra.tpl');
    }
    public function hookActionCarrierProcess($params)
    {
        $cart = $params['cart'];
        if (!$cart || !Validate::isLoadedObject($cart)) {
            return;
        }

        $idAddressDelivery = (int) $cart->id_address_delivery;
        if ($idAddressDelivery <= 0) {
            return;
        }

        $address = new Address($idAddressDelivery);
        if (!Validate::isLoadedObject($address)) {
            return;
        }

        $hasDeliveryAddress = trim((string) $address->address1) !== ''
            && trim((string) $address->postcode) !== ''
            && trim((string) $address->city) !== '';
        if (!$hasDeliveryAddress) {
            return;
        }

        $deliveryOption = $cart->getDeliveryOption();
        $selectedCarrierId = null;

        if (is_array($deliveryOption) && isset($deliveryOption[$idAddressDelivery])) {
            $selected = (string) $deliveryOption[$idAddressDelivery];
            $pieces = explode(',', $selected);
            $selectedCarrierId = (int) $pieces[0];
        }

        $selectedCarrierType = $selectedCarrierId > 0 ? (new DpdCarrierManager($this))->getMatchedType($selectedCarrierId, 0, '') : '';
        if ($selectedCarrierId > 0 && DpdConfig::isPickupService($selectedCarrierType)) {
            $pickup = DpdPickupRepository::getByCartId((int) $cart->id);
            if (!$pickup) {
                $this->context->controller->errors[] = $this->l('Selecione um ponto DPD Pickup para continuar.');
            }
        }
    }

    public function hookActionValidateOrder($params)
    {
        $order = $params['order'];
        if (Validate::isLoadedObject($order)) {
            DpdPickupRepository::assignOrderFromCart((int) $order->id_cart, (int) $order->id);
        }
    }

    public function hookDisplayAdminOrderSideBottom($params)
    {
        $idOrder = (int) $params['id_order'];
        $order = new Order($idOrder);
        if (!Validate::isLoadedObject($order)) {
            return '';
        }

        $carrierId = (int) $order->id_carrier;
        $carrier = new Carrier($carrierId);
        $carrierRef = Validate::isLoadedObject($carrier) ? (int) $carrier->id_reference : 0;
        $carrierName = Validate::isLoadedObject($carrier) ? (string) $carrier->name : '';
        $supported = (new DpdCarrierManager($this))->getMatchedType($carrierId, $carrierRef, $carrierName) !== '';

        if (!$supported) {
            return '';
        }

        $flashSuccess = $this->context->cookie->__get('rgcdpdpt_flash_success');
        $flashError = $this->context->cookie->__get('rgcdpdpt_flash_error');
        unset($this->context->cookie->rgcdpdpt_flash_success, $this->context->cookie->rgcdpdpt_flash_error);

        $shipment = DpdShipmentRepository::getByOrderId($idOrder);
        $shipmentTrackingNumber = $this->normalizeShipmentTrackingForDisplay($shipment);
        if ($shipment && $shipmentTrackingNumber === '') {
            $shipment['tracking_number'] = '';
        }

        $this->smarty->assign([
            'id_order' => $idOrder,
            'shipment' => $shipment,
            'shipment_tracking_number' => $shipmentTrackingNumber,
            'shipment_is_failed' => $this->isFailedShipmentForDisplay($shipment),
            'shipment_error_message' => $this->extractShipmentErrorForDisplay($shipment),
            'shipment_debug_payload' => $this->buildShipmentDebugPayload($shipment),
            'pickup' => DpdPickupRepository::getByOrderId($idOrder),
            'flash_success' => $flashSuccess,
            'flash_error' => $flashError,
            'create_shipment_url' => $this->context->link->getAdminLink('AdminRgcDpdptAjax', true, [], [
                'action' => 'CreateShipment',
                'id_order' => $idOrder,
            ]),
            'download_label_url' => $this->context->link->getAdminLink('AdminRgcDpdptAjax', true, [], [
                'action' => 'DownloadLabel',
                'id_order' => $idOrder,
            ]),
            'refresh_tracking_url' => $this->context->link->getAdminLink('AdminRgcDpdptAjax', true, [], [
                'action' => 'RefreshTracking',
                'id_order' => $idOrder,
            ]),
            'set_manual_tracking_url' => $this->context->link->getAdminLink('AdminRgcDpdptAjax', true, [], [
                'action' => 'SetManualTracking',
                'id_order' => $idOrder,
            ]),
        ]);

        return $this->fetch('module:' . $this->name . '/views/templates/hook/admin_order.tpl');
    }

    protected function normalizeShipmentTrackingForDisplay($shipment)
    {
        if (!$shipment || !isset($shipment['tracking_number'])) {
            return '';
        }

        $tracking = trim((string) $shipment['tracking_number']);
        if ($tracking === '') {
            return '';
        }

        $normalized = Tools::strtolower($tracking);
        if (in_array($normalized, ['array', 'object', 'null'], true)) {
            return '';
        }

        return $tracking;
    }

    protected function isFailedShipmentForDisplay($shipment)
    {
        if (!$shipment) {
            return false;
        }

        if (isset($shipment['status']) && Tools::strtolower((string) $shipment['status']) === 'failed') {
            return true;
        }

        $decoded = !empty($shipment['response_payload']) ? json_decode((string) $shipment['response_payload'], true) : null;
        if (!is_array($decoded)) {
            return false;
        }

        if (isset($decoded['status_code']) && ((int) $decoded['status_code'] < 200 || (int) $decoded['status_code'] >= 300)) {
            return true;
        }

        if (array_key_exists('result', $decoded) && ($decoded['result'] === null || $decoded['result'] === false)) {
            return true;
        }

        return false;
    }

    protected function extractShipmentErrorForDisplay($shipment)
    {
        if (!$shipment || empty($shipment['response_payload'])) {
            return '';
        }

        $decoded = json_decode((string) $shipment['response_payload'], true);
        if (!is_array($decoded)) {
            return '';
        }

        $candidates = [
            $decoded['message'] ?? null,
            $decoded['error_description'] ?? null,
            $decoded['error'] ?? null,
            $decoded['result']['message'] ?? null,
            $decoded['result']['error'] ?? null,
            $decoded['data']['message'] ?? null,
            $decoded['data']['error'] ?? null,
        ];

        foreach ($candidates as $candidate) {
            if (is_scalar($candidate) && trim((string) $candidate) !== '') {
                return trim((string) $candidate);
            }
        }

        return '';
    }


    protected function buildShipmentDebugPayload($shipment)
    {
        if (!$shipment) {
            return '';
        }

        $request = $this->decodeStoredJsonPayload($shipment['request_payload'] ?? '');
        $response = $this->decodeStoredJsonPayload($shipment['response_payload'] ?? '');

        if ($request === null && $response === null) {
            return '';
        }

        $carrierType = isset($shipment['carrier_type']) ? (string) $shipment['carrier_type'] : '';
        $diagnostic = [
            'resumo' => [
                'id_order' => isset($shipment['id_order']) ? (int) $shipment['id_order'] : null,
                'id_cart' => isset($shipment['id_cart']) ? (int) $shipment['id_cart'] : null,
                'estado_local' => isset($shipment['status']) ? (string) $shipment['status'] : null,
                'modo' => DpdConfig::get('MODE'),
                'endpoint_oauth' => DpdConfig::get('OAUTH_URL'),
                'endpoint_expedicao' => DpdConfig::get('SHIPMENT_URL'),
                'servico_interno' => $carrierType,
                'servico_dpd' => $carrierType !== '' ? DpdConfig::serviceLabel($carrierType) : null,
                'conta_dpd_guardada' => isset($shipment['dpd_sub_account']) ? (string) $shipment['dpd_sub_account'] : null,
                'conta_dpd_no_payload' => is_array($request) ? ($request['sub_account']['code'] ?? null) : null,
                'pais_destino' => is_array($request) ? ($request['address']['country']['iso2'] ?? ($request['address']['country']['id'] ?? null)) : null,
                'codigo_postal_destino' => is_array($request) ? ($request['address']['zip_code'] ?? null) : null,
                'referencia_encomenda' => is_array($request) ? ($request['encomenda_referencia'] ?? null) : null,
                'codigo_dpd' => is_array($response) ? ($response['status_code'] ?? null) : null,
                'mensagem_dpd' => is_array($response) ? ($response['message'] ?? ($response['error_description'] ?? ($response['error'] ?? null))) : null,
                'data_criacao_local' => isset($shipment['date_add']) ? (string) $shipment['date_add'] : null,
                'data_atualizacao_local' => isset($shipment['date_upd']) ? (string) $shipment['date_upd'] : null,
            ],
            'observacao' => 'Este diagnóstico contém o payload enviado para a DPD e a resposta recebida. Tokens, passwords e etiquetas PDF/base64 foram omitidos.',
            'pedido_enviado_dpd' => is_array($request) ? $this->sanitizeDebugPayload($request) : $request,
            'resposta_dpd' => is_array($response) ? $this->sanitizeDebugPayload($response) : $response,
        ];

        return json_encode($diagnostic, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    protected function decodeStoredJsonPayload($payload)
    {
        $payload = trim((string) $payload);
        if ($payload === '') {
            return null;
        }

        $decoded = json_decode($payload, true);
        if (is_array($decoded)) {
            return $decoded;
        }

        return Tools::substr($payload, 0, 10000);
    }

    protected function sanitizeDebugPayload($value)
    {
        if (!is_array($value)) {
            return $value;
        }

        $result = [];
        foreach ($value as $key => $item) {
            $normalizedKey = Tools::strtolower(preg_replace('/[^a-zA-Z0-9]/', '', (string) $key));
            if (in_array($normalizedKey, ['pdf', 'labelpdf', 'etiquetapdf', 'zpl', 'qr', 'qrcode'], true)) {
                $result[$key] = '[conteúdo da etiqueta omitido]';
                continue;
            }

            if (in_array($normalizedKey, ['password', 'clientsecret', 'accesstoken', 'refreshtoken', 'token', 'authorization'], true)) {
                $result[$key] = '[omitido]';
                continue;
            }

            if ($normalizedKey === 'email' && is_scalar($item)) {
                $result[$key] = $this->maskDebugEmail((string) $item);
                continue;
            }

            if (in_array($normalizedKey, ['phone', 'mobile', 'telephone', 'telemovel'], true) && is_scalar($item)) {
                $result[$key] = $this->maskDebugValue((string) $item, 3);
                continue;
            }

            $result[$key] = $this->sanitizeDebugPayload($item);
        }

        return $result;
    }

    protected function maskDebugEmail($email)
    {
        $email = trim((string) $email);
        if ($email === '' || strpos($email, '@') === false) {
            return $email !== '' ? '[omitido]' : '';
        }

        $parts = explode('@', $email, 2);
        return $this->maskDebugValue($parts[0], 2) . '@' . $parts[1];
    }

    protected function maskDebugValue($value, $visible = 2)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }

        $visible = max(0, (int) $visible);
        $length = Tools::strlen($value);
        if ($length <= $visible) {
            return str_repeat('*', $length);
        }

        return str_repeat('*', $length - $visible) . Tools::substr($value, -$visible);
    }

}
