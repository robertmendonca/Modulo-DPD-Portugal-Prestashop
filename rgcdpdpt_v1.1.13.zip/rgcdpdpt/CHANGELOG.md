## 1.1.13 - 2026-08-26

- Pesquisa Pickup PT passa a usar prioritariamente `GetPudoListByLongLat`, operação oficial MyPudo para procurar PUDO por latitude/longitude.
- A coordenada de origem continua a ser obtida pelo CP7 através da GEO API PT.
- O conjunto de pontos passa a ser solicitado diretamente à MyPudo a partir da coordenada, evitando o subconjunto diferente observado com `GetPudoList` por endereço/código postal.
- `GetPudoList` permanece como fallback automático caso a operação geográfica não esteja disponível para a credencial configurada.
- Logs de Pickup passam a indicar a operação usada e os cinco primeiros pontos devolvidos, facilitando comparação com o localizador oficial DPD.
- Novo asset `front-1.1.13.js` para evitar cache de versões anteriores.

## 1.1.12 - 2026-08-26

- Corrigida a origem geográfica usada para ordenar pontos Pickup por código postal completo em Portugal.
- A georreferenciação de CP7 deixa de usar Nominatim/OpenStreetMap e passa a usar o endpoint específico de códigos postais da GEO API PT.
- O módulo valida CP4/CP3 devolvidos antes de aceitar a coordenada, evitando usar uma localização de outro código postal.
- A distância aos pontos DPD continua a ser recalculada localmente por Haversine, agora a partir do centro do CP7 português.
- A pesquisa solicita até 50 candidatos à MyPudo e apresenta os 10 mais próximos após a ordenação geográfica local.
- A cache antiga de coordenadas Nominatim não é reutilizada; a 1.1.12 usa um ficheiro de cache próprio.
- Novo asset `front-1.1.12.js` para evitar cache de versões anteriores.

## 1.1.11 - 2026-08-26

- Corrigida definitivamente a regressão de localização do Pickup em Portugal.
- O código postal completo passa a ser a origem geográfica autoritativa da pesquisa Pickup.
- A morada/cidade guardada no carrinho deixa de poder deslocar uma pesquisa portuguesa para outra localidade.
- Adicionada georreferenciação do código postal completo via Nominatim/OpenStreetMap, enviando apenas o código postal.
- Adicionada cache local de coordenadas e limitação de chamadas ao serviço de georreferenciação.
- A distância dos pontos DPD é recalculada localmente por Haversine a partir da coordenada do código postal.
- Quando a coordenada está disponível, o módulo pede uma lista alargada de candidatos à MyPudo e apresenta os pontos realmente mais próximos.
- O botão manual passa a enviar explicitamente o modo de pesquisa ao backend.
- Novo asset `front-1.1.11.js` para evitar cache de versões anteriores.

## 1.1.10 - 2026-08-26

- Corrigida a precisão da pesquisa Pickup por código postal completo.
- Quando o código postal pesquisado coincide com a morada de entrega, o módulo volta a enviar ao MyPudo a rua, o código postal completo e a cidade, como nas versões 1.0.x.
- Se o utilizador alterar manualmente o código postal, a morada/cidade anteriores não são reutilizadas, evitando geolocalização pela morada errada.
- A ordenação dos resultados passa a respeitar a distância geográfica devolvida pela DPD quando existe contexto completo de morada.
- O frontend deixa de reordenar pontos pela diferença numérica entre códigos postais; a ordem calculada no servidor passa a ser autoritativa.
- Novo asset `front-1.1.10.js` para evitar cache de versões anteriores.

## 1.1.9 - 2026-08-26

- Restaura o motor de pesquisa Pickup comprovado das versões 1.0.x (`GetPudoList`) em vez de continuar a acrescentar filtros locais sobre a resposta MyPudo.
- Para destinos em Portugal, a pesquisa Pickup passa a ser determinada no servidor apenas pelo código postal, com `address` vazio e `city=?`, impedindo que morada/cidade antigas do checkout alterem a localização.
- Repõe os limites normais MyPudo configurados (`10` pontos e raio configurado), removendo a expansão temporária para 50 candidatos.
- Repõe a ordenação por proximidade de código postal usada na 1.0.6.
- A correção passa a ser totalmente server-side e deixa de depender do parâmetro `manual` enviado pelo JavaScript.
- O asset frontend passa a usar um nome físico versionado (`front-1.1.9.js`) para contornar caches antigos do browser, PrestaShop ou CDN/Cloudflare.
- O verificador de atualizações adiciona cache-busting e headers `no-cache` ao consultar `rgcdpdpt_latest.zip`, evitando ler pacotes antigos armazenados em cache.
- O upgrade limpa a cache do updater e força novo registo técnico da versão.

## 1.1.8 - 2026-08-26

- Corrige a pesquisa manual Pickup para ser sempre baseada exclusivamente no código postal introduzido.
- O frontend envia agora explicitamente o modo de pesquisa manual ao controller.
- O controller ignora sempre morada/cidade do carrinho numa pesquisa manual, mesmo quando o código postal digitado coincide com o da morada de entrega.
- A validação de área postal portuguesa passa a ser obrigatória no modo manual antes de qualquer ordenação por distância.
- Resultados MyPudo de zonas incompatíveis deixam de ser apresentados no mapa/lista, mesmo quando a API devolve uma distância aparentemente pequena.
- Logs Pickup passam a indicar `strict_postcode` para facilitar o diagnóstico.
- Cache do verificador de atualizações é limpa durante o upgrade.
- Quando o pacote remoto está mais antigo que a instalação, o updater volta a verificar automaticamente após 15 minutos em vez de aguardar 24 horas.

## 1.1.7 - 2026-08-26

- Corrigida a pesquisa Pickup por código postal: pesquisas manuais passam a enviar `city` vazio em vez de `?`.
- Pesquisa apenas por código postal solicita um conjunto alargado de candidatos à MyPudo e valida localmente a área postal portuguesa antes de apresentar resultados.
- Resultados de uma área postal incompatível são rejeitados em vez de aparecerem no mapa com uma distância enganadora.
- A ordenação final dos pontos Pickup passa a ser definida no servidor, evitando diferenças entre PHP e JavaScript.
- Logs Pickup passam a incluir um resumo seguro dos códigos postais/cidades devolvidos para diagnóstico.
- O updater distingue `Atualizado` de `Servidor de atualizações desatualizado` quando o pacote remoto é mais antigo que a instalação.
- O upgrade limpa a cache do updater para forçar uma nova leitura do pacote publicado.
- Uma guia Trace ainda sem eventos antes da recolha passa a ser registada como informação, não como aviso.

## 1.1.6 - 2026-08-26

- Corrige a pesquisa manual de pontos Pickup quando o código postal introduzido é diferente do código postal da morada de entrega.
- A morada e a cidade da encomenda deixam de ser enviadas ao MyPudo quando pertencem a outro código postal.
- Adicionada validação equivalente no servidor para impedir pesquisas com contexto geográfico contraditório.
- Mantém morada e cidade como contexto apenas quando o código postal pesquisado corresponde ao da morada de entrega.

## 1.1.5 - 2026-08-26

- Corrige a versão apresentada no painel central de instalações após upgrades do módulo.
- O módulo volta a reportar imediatamente quando deteta uma versão diferente da última enviada.
- Adiciona heartbeat técnico diário para manter `last_reported_at` atualizado sem chamadas em excesso.
- Reduz o bloqueio após falha temporária do reporter de 24 horas para 15 minutos.
- O User-Agent do reporter passa a usar dinamicamente a versão real do módulo.

## 1.1.3

- Remove do backoffice a alternativa de CRON por HTTP, incluindo URL, token e exemplo com `curl`.
- Remove o endpoint HTTP público de sincronização; o tracking automático passa a utilizar apenas o CRON PHP local recomendado.
- Elimina no upgrade o token HTTP gerado por versões 1.1.x anteriores.
- Mantém na aba Tracking automático somente a ativação, o mapeamento COL/OFD/POD e o comando de CRON PHP local.

## 1.1.4 - 2026-08-26

- Corrigido o endereço do serviço de atualização para usar o pacote estável `rgcdpdpt_latest.zip`.
- O upgrade substitui automaticamente a antiga URL `rgcdpdpt_v1.0.x.zip`.
- Uma falha na verificação de atualização deixa de apresentar versão e SHA-256 antigos como resultado atual.
- Mantida a deteção da versão real pelo `config.xml` contido no ZIP.

## 1.1.2

- Integra a URL e a API key universal da DPD Trace diretamente no módulo, sem configuração por loja.
- Oculta do backoffice os campos técnicos de URL, API key, idioma e limite por execução.
- Fixa internamente o idioma dos eventos em PT e o lote do CRON em 50 encomendas.
- Mantém visíveis apenas a ativação da sincronização, o mapeamento COL/OFD/POD e as instruções de CRON.
- Atualiza o diagnóstico para indicar que a API Trace está integrada, sem expor a chave.

## 1.1.1

- Corrige o upgrade em PrestaShop/MariaDB ao procurar o estado **Saiu para entrega**.
- Remove um `LIMIT 1` redundante numa consulta executada por `Db::getValue()`, evitando SQL inválido `LIMIT 1 LIMIT 1`.
- Mantém a migração 1.1.0 idempotente para permitir repetir com segurança uma atualização que tenha falhado.

## 1.1.0

- Adiciona integração com a nova API **DPD Trace** para acompanhamento automático das expedições.
- Adiciona configuração segura da API key da Trace, guardada como credencial sensível.
- Adiciona sincronização por CRON, com execução local por PHP recomendada e endpoint HTTP protegido por token como alternativa.
- Implementa o fluxo automático `COL → Enviado`, `OFD → Saiu para entrega` e `POD → Entregue`.
- Cria automaticamente o estado **Saiu para entrega** quando necessário e permite alterar o mapeamento dos três estados no backoffice.
- Analisa todo o histórico de eventos e utiliza `EventCod`, sem depender da ordem do array nem da descrição do evento.
- Para encomendas com vários volumes, só avança quando todos os volumes atingem o mesmo marco automático.
- Guarda apenas o último código, descrição, data do evento e dados técnicos de sincronização; não persiste coordenadas, nome do recebedor ou imagem POD da resposta Trace.
- Impede regressão de estados e não substitui estados terminais protegidos como cancelado, reembolsado ou erro de pagamento.
- Adiciona sincronização manual do estado DPD no bloco da encomenda para diagnóstico.
- Incorpora o dicionário de códigos de eventos fornecido pela DPD como referência interna; códigos não mapeados não alteram a encomenda.

## 1.0.6

- Mantém, por desenho da integração DPD, o `client_id` e o `client_secret` técnicos públicos incorporados no código.
- Mantém o endpoint e o funcionamento MyPudo/Pickup existentes.
- Move as etiquetas PDF para armazenamento privado em `var/modules/rgcdpdpt/labels`, com nomes aleatórios de 128 bits, permissões restritas e download autenticado pelo backoffice.
- Migra automaticamente etiquetas antigas guardadas em `modules/rgcdpdpt/var/labels`.
- Protege os endpoints AJAX Pickup com token associado ao carrinho e assinatura dos pontos devolvidos pela pesquisa.
- Limita a pesquisa Pickup a 30 consultas por minuto por sessão/carrinho para reduzir abuso sem afetar o checkout normal.
- Deixa de devolver mensagens técnicas internas do MyPudo ao frontend em caso de exceção.
- Minimiza dados pessoais, credenciais e conteúdo de etiquetas nos logs, diagnóstico e payloads de expedição persistidos.
- Adiciona retenção automática de logs, configurável e com 90 dias por defeito.
- Migra credenciais configuráveis de Base64/texto legado para AES-256-GCM quando OpenSSL está disponível.
- Deixa de preencher a password da API no HTML do backoffice; campo vazio mantém a credencial já guardada.
- Prefixa as classes internas do módulo para reduzir risco de colisões com outros módulos DPD.
- Consolida os assets ativos em `front.js`, `front.css`, `admin.js` e `admin.css`, usando a versão do módulo para cache busting.
- Remove assets históricos e imagens duplicadas do pacote de distribuição.
- Mantém Leaflet 1.9.4 em versão fixa e adiciona Subresource Integrity (SRI) aos recursos carregados do CDN.
- Limita a compatibilidade declarada à linha PrestaShop 8.x/9.x, evitando anunciar compatibilidade automática com uma futura versão 10.
- Atualiza a documentação de registo técnico para refletir os metadados de contas DPD efetivamente enviados.

## 1.0.5

- Corrige a configuração OAuth interna do plugin.
- Define automaticamente o `client_id` e o `client_secret` fornecidos pela DPD.
- Mantém estes campos ocultos no backoffice.
- Repara automaticamente instalações anteriores com `client_secret` em falta.
- Adiciona ao Diagnóstico apenas o estado configurado/em falta, sem expor o segredo.

## 1.0.4

- Corrigido o cálculo de `fresh_pickup_date`: passa a utilizar o dia útil seguinte, ignorando fins de semana e feriados nacionais portugueses.
- Corrigido o cálculo de `fresh_expiration_date`: a validade passa a ser contada a partir da data de recolha Fresh, e não a partir da data de criação da expedição.
- Movido o campo **Validade Fresh** da aba Operação para a própria linha da conta **DPD Portugal Fresh**, na aba Contas DPD.
- O cliente pode configurar entre 1 e 365 dias de validade após a recolha; o valor por defeito continua a ser 5 dias.
- Mantida a compatibilidade com PrestaShop 8.x e 9.x.

## 1.0.3

- Adicionado verificador próprio de atualizações do módulo.
- O módulo consulta automaticamente, no máximo uma vez a cada 24 horas, o pacote publicado em `https://api.rgcconsulting.pt/dpd/module/latest/rgcdpdpt_latest.zip`.
- A versão é identificada diretamente no `config.xml` existente dentro do ZIP disponibilizado.
- Adicionado aviso no topo da configuração quando existe uma versão mais recente.
- Adicionado botão **Procurar atualizações** para verificação manual.
- Adicionado estado da atualização na aba **Diagnóstico**, incluindo versão instalada, versão disponível, última verificação e SHA-256 do pacote.
- A atualização continua manual: o módulo não substitui os seus próprios ficheiros automaticamente.
- Compatibilidade declarada atualizada para PrestaShop 8.x e 9.x.

## 1.0.2

- Adicionado serviço **DPD Portugal Fresh** como nova conta configurável.
- Quando uma encomenda usa DPD Fresh, o payload da API passa a incluir `fresh_pickup_date` com D+1.
- Adicionado envio de `fresh_expiration_date` com validade D+5 por defeito.
- Adicionado campo **Validade Fresh (dias)** na aba Operação para permitir validade inferior quando solicitado pelo cliente.
- Atualizada a estrutura de serviços para incluir a conta Fresh no registo técnico enviado à API RGC.

## 1.0.1

- Adiciona envio técnico das contas DPD configuradas para a API de registo.
- O envio passa a incluir serviço, tipo de entrega, conta DPD, estado ativo/inativo e nome visível.
- Ao guardar a configuração do módulo, o registo técnico é atualizado na API central.
- Não são enviados dados de clientes, encomendas, credenciais DPD, tokens ou etiquetas.

## 1.0.0

- Marca a primeira versão estável do módulo.
- Adiciona registo técnico simples de instalação para `https://api.rgcconsulting.pt/dpd/register-install`.
- O registo envia apenas domínio da loja, data da instalação, versão do módulo, versão do PrestaShop e identificador técnico da instalação.
- O registo não bloqueia a instalação caso a API esteja indisponível.
- Não são enviados dados de clientes, encomendas, credenciais DPD, tokens ou etiquetas.

## 0.7.16

- Corrige a acentuação dos textos visíveis no backoffice do módulo.
- Ajusta mensagens de validação e diagnóstico para português de Portugal.
- Atualiza os assets do backoffice para evitar cache dos textos antigos.

## 0.7.15

- Guarda o estado visual da secção Pickup da aba Contas DPD.
- Ao ativar o conteúdo Pickup, a secção permanece ativa após atualizar a página.
- Ao desativar o conteúdo Pickup, a secção permanece desativada após atualizar a página.
- Adiciona persistência via configuração do módulo e localStorage do backoffice.

## 0.7.14

- Corrige a secção Pickup da aba Contas DPD para iniciar oculta por defeito.
- Transforma o botão Pickup em alternância visual: Ativar conteúdo Pickup / Desativar conteúdo Pickup.
- Mantém o alerta de confirmação apenas ao ativar a visualização dos serviços Pickup.

## 0.7.13

- Renomeia a aba Tipologia de serviços / Contas DPD para Contas DPD.
- Divide a configuração de contas DPD em duas secções: Home e Pickup.
- Adiciona botão de ativação visual para mostrar a configuração Pickup, com alerta para usar apenas quando existir contrato DPD para Pickup/Shop.

## 0.7.12

- Adiciona fundo cinza bem claro na aba ativa da configuração do módulo para diferenciar visualmente das demais abas.

## 0.7.11

- Remove completamente a aba Pesquisa de pontos Pickup da configuração do módulo no backoffice.
- Mantém a configuração técnica Pickup/Shop gerida internamente, sem exposição na interface.

## 0.7.10

- A aba Pesquisa de pontos Pickup deixa de mostrar os parâmetros técnicos fixos da pesquisa Pickup/Shop.
- Mantém os valores internos existentes sem os expor no HTML do formulário.

## 0.7.9

- A aba DPD passa a mostrar apenas Utilizador da API e Password da API.
- Oculta da configuração visível os campos técnicos fixos: modo, endpoints, Client ID e Client secret.
- Ajusta os defaults internos para ambiente live e Client ID 2.

## 0.7.8

- Melhora o diagnóstico exibido na encomenda, mostrando resumo da expedição, serviço DPD, conta usada, destino, payload enviado e resposta recebida.
- Regista logs mais completos quando a DPD recusa a criação da expedição, incluindo conta DPD, serviço, destino, endpoint e resposta.
- Mantém tokens, passwords e etiquetas PDF/base64 omitidos nos logs e no diagnóstico.

## 0.7.7

- Força HTTP/1.1 nas chamadas cURL para OAuth, criação de expedição e fallback Pickup, evitando falhas de HTTP/2 como `stream 0 was not closed cleanly: CANCEL`.
- Adiciona headers `Connection: close` e `Expect:` nas chamadas DPD para reduzir problemas de negociação/proxy.
- Melhora o log de erro cURL com `curl_errno`, mensagem e HTTP status.

## 0.7.6

- Mapa Pickup passa a carregar automaticamente quando o cliente seleciona um serviço Pickup/Shop.
- O botão **Procurar pontos Pickup** fica disponível para atualizar a pesquisa quando o código postal é alterado.

## 0.7.5

- Corrigida validação que mostrava o alerta de seleção Pickup antes da morada estar preenchida.

## 0.7.4

- Adicionados ícones personalizados DPD no mapa Pickup.
- Adicionados ícones próprios para carriers Home e Pickup/Shop.

## 0.7.3

- Criada aba própria para **Pesquisa de pontos Pickup**.

## 0.7.2

- Criada aba **Tipologia de serviços / Contas DPD**.
- Removida a configuração antiga baseada em Subconta Home/Pickup.
- Configuração passa a ser baseada nos serviços DPD fornecidos pela DPD.

## 0.7.1

- Configuração do backoffice reorganizada com abas Bootstrap `nav nav-tabs`.

## 0.7.0

- Adicionada base de serviços DPD por tipologia.
- Adicionados serviços Portugal Home, Portugal Shop, Portugal Ilhas, Espanha Home, Espanha Shop, Internacional Home e Internacional Shop.
