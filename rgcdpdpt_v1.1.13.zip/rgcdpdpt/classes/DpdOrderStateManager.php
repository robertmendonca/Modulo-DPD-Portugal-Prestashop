<?php
class RgcdpdptDpdOrderStateManager
{
    public static function ensureDefaults()
    {
        $shippingId = (int) Configuration::get('PS_OS_SHIPPING');
        $deliveredId = (int) Configuration::get('PS_OS_DELIVERED');

        if (!self::isValidStateId((int) RgcdpdptDpdConfig::get('TRACE_STATE_COL_ID', 0))) {
            if ($shippingId > 0 && self::isValidStateId($shippingId)) {
                RgcdpdptDpdConfig::set('TRACE_STATE_COL_ID', $shippingId);
            }
        }

        if (!self::isValidStateId((int) RgcdpdptDpdConfig::get('TRACE_STATE_POD_ID', 0))) {
            if ($deliveredId > 0 && self::isValidStateId($deliveredId)) {
                RgcdpdptDpdConfig::set('TRACE_STATE_POD_ID', $deliveredId);
            }
        }

        if (!self::isValidStateId((int) RgcdpdptDpdConfig::get('TRACE_STATE_OFD_ID', 0))) {
            $outForDeliveryId = self::findOrCreateOutForDeliveryState($shippingId);
            if ($outForDeliveryId > 0) {
                RgcdpdptDpdConfig::set('TRACE_STATE_OFD_ID', $outForDeliveryId);
            }
        }

        return self::isValidStateId((int) RgcdpdptDpdConfig::get('TRACE_STATE_COL_ID', 0))
            && self::isValidStateId((int) RgcdpdptDpdConfig::get('TRACE_STATE_OFD_ID', 0))
            && self::isValidStateId((int) RgcdpdptDpdConfig::get('TRACE_STATE_POD_ID', 0));
    }

    public static function isValidStateId($idOrderState)
    {
        $idOrderState = (int) $idOrderState;
        if ($idOrderState <= 0) {
            return false;
        }

        try {
            return Validate::isLoadedObject(new OrderState($idOrderState));
        } catch (Exception $e) {
            return false;
        }
    }

    protected static function findOrCreateOutForDeliveryState($shippingId)
    {
        $existing = (int) Db::getInstance()->getValue(
            'SELECT os.`id_order_state` '
            . 'FROM `' . _DB_PREFIX_ . 'order_state` os '
            . 'INNER JOIN `' . _DB_PREFIX_ . 'order_state_lang` osl ON osl.`id_order_state` = os.`id_order_state` '
            . "WHERE osl.`name` IN ('Saiu para entrega', 'Out for delivery') "
            // Db::getValue() already limits the result internally in PrestaShop.
            // An explicit limit here can be duplicated by the database abstraction on some versions.
            . "ORDER BY (os.`module_name` = 'rgcdpdpt') DESC, os.`id_order_state` ASC"
        );
        if ($existing > 0 && self::isValidStateId($existing)) {
            return $existing;
        }

        $source = null;
        if ((int) $shippingId > 0 && self::isValidStateId((int) $shippingId)) {
            $source = new OrderState((int) $shippingId);
        }

        $state = new OrderState();
        $state->color = '#2E6DA4';
        $state->send_email = 0;
        $state->hidden = 0;
        $state->delivery = 0;
        $state->module_name = 'rgcdpdpt';
        $state->unremovable = 0;

        foreach (['invoice', 'logable', 'shipped', 'paid', 'pdf_delivery', 'pdf_invoice'] as $property) {
            if ($source && property_exists($source, $property)) {
                $state->{$property} = (int) $source->{$property};
            }
        }
        $state->shipped = 1;

        foreach (Language::getLanguages(false) as $language) {
            $idLang = (int) $language['id_lang'];
            $isoCode = strtolower((string) ($language['iso_code'] ?? ''));
            $state->name[$idLang] = $isoCode === 'pt' ? 'Saiu para entrega' : 'Out for delivery';
            $state->template[$idLang] = '';
        }

        if (!$state->add()) {
            RgcdpdptDpdLogRepository::add('error', 'Could not create Out for delivery order state', 'tracking', 0);
            return 0;
        }

        return (int) $state->id;
    }
}
