<?php
class RgcdpdptDpdTraceEventMap
{
    public static function descriptions()
    {
        return [
            '001' => 'ENTREGUE PELA DPD NO PONTO DE ENTREGA',
            '002' => 'RECEPCIONADO PELO PONTO DE ENTREGA',
            '007' => 'DEPOSITADO PELO CLIENTE/EXPEDIDOR',
            '008' => 'DATA DE PERMANÊNCIA EM LOJA EXPIRADA',
            '009' => 'TRANSFERÊNCIAS ENTRE PONTOS',
            '012' => 'ENTREGUE À DPD PELO PONTO DE ENTREGA',
            '055' => 'CANCELADO-PEDIDO DUPLICAD',
            '110' => 'DOCUMENTO EM FALTA OU INCORRECTO',
            '113' => 'PRODUTO PROIBIDO',
            '114' => 'ATRASO NA LIGAÇÃO',
            '115' => 'NÃO EXPORTADO POR OUTROS MOTIVOS',
            '401' => 'PROBLEMA NO ENDEREÇO PARA ENTREGA',
            '402' => 'RETORNO ARMAZÉM PARA ENTREGA',
            '403' => 'RETORNO ARMAZÉM  (PÁRA AEP)',
            '410' => 'ENVIO EM ARMAZÉM',
            '411' => 'ANOMALIA OPERACIONAL',
            '412' => 'ENVIO DANIFICADO',
            '413' => 'ANOMALIA OPERACIONAL',
            '417' => 'ENVIO PARCIALMENTE RECEBIDO',
            '418' => 'ANOMALIA OPERACIONAL',
            '419' => 'ANOMALIA OPERACIONAL',
            '420' => 'ANOMALIA OPERACIONAL',
            '422' => 'PENDENTE DE ENTREGA HIPERS',
            '423' => 'A AGUARDAR MARCAÇÃO DE ENTREGA',
            '424' => 'DEVOLUÇÃO AO EXPEDIDOR',
            '450' => 'NOVA DATA OU MORADA (PREDICT)',
            '480' => 'FRESH-ENTRADA COLDROOM',
            '481' => 'FRESH-ENVIO EM TRANSITO',
            '482' => 'FRESH-ENVIO EM DISTRIBUICAO',
            '500' => 'ENDEREÇO DO DESTINATÁRIO INCORRECTO OU DESCONHECIDO',
            '501' => 'ENDEREÇO DO DESTINATÁRIO INCOMPLETO OU ILEGÍVEL',
            '502' => 'ALTERAÇÃO DE MORADA DO DESTINATÁRIO',
            '503' => 'RECUSA DO DESTINATÁRIO',
            '504' => 'FALTA DE PAGAMENTO',
            '505' => 'DESTINATÁRIO FECHADO',
            '506' => 'AUSÊNCIA DO DESTINATÁRIO',
            '507' => 'FALTA DE SELO/SELO PARTIDO (OBRIGA A PARAGEM DO ENVIO)',
            '508' => 'DESTINATÁRIO ENCERRADO PARA FÉRIAS',
            '509' => 'ALTERAÇÃO DA DATA DE ENTREGA',
            '510' => 'ANOMALIA OPERACIONAL',
            '511' => 'TEMPO DE ESPERA EXCEDIDO NO DESTINATÁRIO',
            '512' => 'ANOMALIA OPERACIONAL',
            '513' => 'LOCAL DE ENTREGA NÃO ACESSÍVEL',
            '514' => 'INTEMPÉRIES',
            '515' => 'ANOMALIA OPERACIONAL',
            '516' => 'DESTINATÁRIO AUSENTE/FECHADO',
            '517' => 'NAO ENTREGAR A PEDIDO DO EXPEDIDOR',
            '518' => 'ANOMALIA OPERACIONAL',
            '521' => 'LOCKER / PICKUP LOTADO',
            '522' => 'VOLUME NÃO CABE NO LOCKER',
            '523' => 'PIN INVÁLIDO',
            '524' => 'QRCODE INVÁLIDO',
            '525' => 'SWAP NÃO CONFORME',
            '526' => 'REENCAMINHAMENTO PICKUP',
            '527' => 'LOCKER INDISPONÍVEL',
            '540' => 'ENVIO RETIDO POR DIFERENÇA DE PESOS',
            '611' => 'ENCOMENDA DEVOLVIDA AO EXPEDIDOR',
            '616' => 'ENTREGA ANULADA',
            '700' => 'INFORMAÇÃO INTERACTIVA DE PREVISÃO DE ENTREGA',
            '701' => 'ALTERAÇÃO DE DATA',
            '702' => 'ALTERAÇÃO DE DATA',
            '703' => 'ALTERAÇÃO PARA LOJA PICKUP',
            '704' => 'ALTERAÇÃO DE DATA',
            '705' => 'ALTERAÇÃO DE DATA',
            '706' => 'HORÁRIO DE ENTREGA ENVIADA AO DESTINATÁRIO',
            '709' => 'MENSAGEM "A PROXIMA ENTREGA" ENVIADA',
            '711' => 'RECEPÇÃO DOS DADOS ELECTRONICOS DA EXPEDIÇÃO',
            '712' => 'ENTREGA ANTECIPADA',
            '713' => 'ENTREGA TARDIA',
            '714' => 'DATA PREVISTA DE ENTREGA',
            '721' => 'PEDIDO DE NOVA ENTREGA PELO EXPEDIDOR',
            '722' => 'PEDIDO DE ALTERAÇÃO DE MORADA PELO EXPEDIDOR',
            '723' => 'MORADA CORRIGIDA PELO EXPEDIDOR',
            '724' => 'PEDIDO DE DEVOLUÇÃO PELO EXPEDIDOR',
            '731' => 'PEDIDO DE NOVA ENTREGA PELO DESTINATÁRIO',
            '732' => 'PEDIDO DE ALTERAÇÃO DE DATA PELO DESTINATÁRIO',
            '733' => 'PEDIDO DE ALTERAÇÃO DE MORADA PELO DESTINATÁRIO',
            '734' => 'ENCOMENDA A DEVOLVER',
            '741' => 'PEDIDO DE NOVA ENTREGA',
            '742' => 'PEDIDO DE ALTERAÇÃO DE DATA',
            '743' => 'PEDIDO DE ALTERAÇÃO DE MORADA',
            '744' => 'ENCOMENDA A DEVOLVER',
            '745' => 'ENTREGA ANTECIPADA',
            '746' => 'ENTREGA TARDIA',
            '747' => 'DATA PREVISTA DE ENTREGA',
            '800' => 'ENDEREÇO DESCONHECIDO',
            '801' => 'ENDEREÇO INCORRECTO',
            '802' => 'ALTERAÇÃO DE MORADA',
            '803' => 'RECUSADA',
            '804' => 'FALTA DE PAGAMENTO',
            '805' => 'LOCAL FECHADO',
            '806' => 'EXPEDIDOR AUSENTE',
            '807' => 'CARGA NÃO ESTÁ PRONTA',
            '808' => 'NADA A RECOLHER',
            '809' => 'FORA DE NORMAS',
            '810' => 'FALTA DE TEMPO',
            '811' => 'TEMPO EXCEDIDO',
            '812' => 'CIRCUITO ERRADO',
            '813' => 'LOCAL INACESSIVEL',
            '814' => 'INTEMPERIES',
            '815' => 'EMBALAMENTO DEFICIENTE',
            '816' => 'FALTA PESSOA DE CONTACTO',
            '817' => 'EXPEDIDOR NÃO AVISADO',
            '818' => 'FALTA DE CAPACIDADE',
            '819' => 'ANULADA',
            '820' => 'FALTA INFORM.ADICIONAL',
            '821' => 'DEIXOU DE TRABALHAR',
            '822' => 'JÁ RECOLHIDO',
            '823' => 'NADA A RECOLHER C/ENTREGA',
            '824' => 'NUMERO DE VOLS SUPERIOR AO PEDIDO',
            'COL' => 'ENCOMENDA RECOLHIDA',
            'HUB' => 'PASSAGEM POR HUB',
            'INB' => 'ENTRADA EM ARMAZÉM',
            'OFD' => 'EM DISTRIBUIÇÃO',
            'OFP' => 'SAIDA PARA RECOLHA',
            'PEC' => 'ENTRADA EM ARMAZÉM',
            'POD' => 'PROVA DE ENTREGA',
            'REC' => 'RECOLHA',
        ];
    }

    public static function description($code, $fallback = '')
    {
        $code = strtoupper(trim((string) $code));
        $descriptions = self::descriptions();

        return isset($descriptions[$code]) ? $descriptions[$code] : (string) $fallback;
    }

    public static function isKnown($code)
    {
        $code = strtoupper(trim((string) $code));
        return array_key_exists($code, self::descriptions());
    }

    public static function automaticStage($code)
    {
        $code = strtoupper(trim((string) $code));
        $stages = [
            'COL' => 1,
            'OFD' => 2,
            'POD' => 3,
        ];

        return isset($stages[$code]) ? $stages[$code] : 0;
    }

    public static function automaticStateConfigKey($code)
    {
        $code = strtoupper(trim((string) $code));
        $keys = [
            'COL' => 'TRACE_STATE_COL_ID',
            'OFD' => 'TRACE_STATE_OFD_ID',
            'POD' => 'TRACE_STATE_POD_ID',
        ];

        return isset($keys[$code]) ? $keys[$code] : '';
    }

    public static function isDelivered($code)
    {
        return strtoupper(trim((string) $code)) === 'POD';
    }
}
