<?php
class RgcdpdptDpdSecurity
{
    public static function pickupToken(Cart $cart)
    {
        $material = 'pickup|' . (int) $cart->id . '|' . (string) $cart->secure_key;
        return hash_hmac('sha256', $material, self::key());
    }

    public static function validatePickupToken($token, Cart $cart)
    {
        $expected = self::pickupToken($cart);
        $token = trim((string) $token);

        if ($token === '' || $expected === '') {
            return false;
        }

        if (function_exists('hash_equals')) {
            return hash_equals($expected, $token);
        }

        return $expected === $token;
    }

    public static function signPickupItem(Cart $cart, array $item)
    {
        $canonical = self::canonicalPickupItem($item);
        $material = 'pickup-item|' . (int) $cart->id . '|' . json_encode($canonical, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        return hash_hmac('sha256', $material, self::key());
    }

    public static function validatePickupItemSignature(Cart $cart, array $item, $signature)
    {
        $expected = self::signPickupItem($cart, $item);
        $signature = trim((string) $signature);

        if ($signature === '') {
            return false;
        }

        if (function_exists('hash_equals')) {
            return hash_equals($expected, $signature);
        }

        return $expected === $signature;
    }

    public static function canonicalPickupItem(array $item)
    {
        return [
            'code' => self::scalar($item['code'] ?? '', 64),
            'name' => self::scalar($item['name'] ?? '', 255),
            'address' => self::scalar($item['address'] ?? '', 255),
            'zip' => self::scalar($item['zip'] ?? '', 32),
            'city' => self::scalar($item['city'] ?? '', 128),
            'country' => self::scalar($item['country'] ?? 'PRT', 8),
            'latitude' => self::scalar($item['latitude'] ?? '', 32),
            'longitude' => self::scalar($item['longitude'] ?? '', 32),
        ];
    }

    protected static function scalar($value, $maxLength)
    {
        if (!is_scalar($value) && $value !== null) {
            return '';
        }

        $value = trim((string) $value);
        return class_exists('Tools') ? Tools::substr($value, 0, (int) $maxLength) : substr($value, 0, (int) $maxLength);
    }

    protected static function key()
    {
        $seed = defined('_COOKIE_KEY_') ? (string) _COOKIE_KEY_ : '';
        if ($seed === '' && defined('_COOKIE_IV_')) {
            $seed = (string) _COOKIE_IV_;
        }
        if ($seed === '') {
            throw new RuntimeException('Chave de segurança do PrestaShop indisponível.');
        }

        return hash('sha256', 'rgcdpdpt|' . $seed, true);
    }
}
