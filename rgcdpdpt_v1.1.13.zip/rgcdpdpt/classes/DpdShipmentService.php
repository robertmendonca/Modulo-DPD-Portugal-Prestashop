<?php
class RgcdpdptDpdShipmentService
{
    /** @var Module */
    protected $module;

    public function __construct(Module $module)
    {
        $this->module = $module;
    }

    public function createForOrder($idOrder)
    {
        $order = new Order((int) $idOrder);
        if (!Validate::isLoadedObject($order)) {
            throw new Exception('Order not found.');
        }

        $existing = RgcdpdptDpdShipmentRepository::getByOrderId((int) $order->id);
        if ($existing && !empty($existing['tracking_number'])) {
            throw new Exception('This order already has a DPD shipment.');
        }

        $payload = $this->buildPayload($order);
        $response = (new RgcdpdptDpdShipmentClient())->createShipment($payload);

        if (!$this->isSuccessfulShipmentResponse($response)) {
            $message = $this->extractShipmentErrorMessage($response);

            RgcdpdptDpdShipmentRepository::saveForOrder((int) $order->id, (int) $order->id_cart, [
                'carrier_type' => $this->getCarrierTypeFromOrder($order),
                'dpd_sub_account' => $payload['sub_account']['code'] ?? '',
                'tracking_number' => '',
                'label_path' => '',
                'request_payload' => RgcdpdptDpdDataSanitizer::sanitize($payload),
                'response_payload' => RgcdpdptDpdDataSanitizer::sanitize($response),
                'status' => 'failed',
                'is_test' => RgcdpdptDpdConfig::isQaMode(),
            ]);

            RgcdpdptDpdLogRepository::add('error', 'DPD shipment was not created', 'order', (int) $order->id, [
                'message' => $message,
                'mode' => RgcdpdptDpdConfig::get('MODE'),
                'shipment_url' => RgcdpdptDpdConfig::get('SHIPMENT_URL'),
                'carrier_type' => $this->getCarrierTypeFromOrder($order),
                'service_label' => RgcdpdptDpdConfig::serviceLabel($this->getCarrierTypeFromOrder($order)),
                'dpd_account' => $payload['sub_account']['code'] ?? '',
                'order_reference' => (string) $order->reference,
                'destination_country' => $payload['address']['country']['iso2'] ?? ($payload['address']['country']['id'] ?? ''),
                'destination_zip' => $payload['address']['zip_code'] ?? '',
                'request_payload' => RgcdpdptDpdDataSanitizer::sanitize($payload),
                'response_payload' => RgcdpdptDpdDataSanitizer::sanitize($response),
            ]);

            throw new Exception('DPD não criou a expedição: ' . $message);
        }

        $pdfBase64 = $this->extractLabelBase64($response);
        $tracking = $this->extractTrackingNumber($response);
        if ($tracking === '' && $pdfBase64 !== '') {
            $tracking = $this->extractTrackingFromPdfBase64($pdfBase64);
        }
        $labelPath = $pdfBase64 ? $this->storeLabel($order, $pdfBase64) : '';

        if ($tracking !== '') {
            $this->updateOrderCarrierTracking($order, $tracking);
        } else {
            RgcdpdptDpdLogRepository::add('warning', 'Shipment created but tracking number was not found in DPD response', 'order', (int) $order->id, [
                'response_preview' => Tools::substr(json_encode(RgcdpdptDpdDataSanitizer::sanitize($response), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), 0, 1200),
            ]);
        }

        RgcdpdptDpdShipmentRepository::saveForOrder((int) $order->id, (int) $order->id_cart, [
            'carrier_type' => $this->getCarrierTypeFromOrder($order),
            'dpd_sub_account' => $payload['sub_account']['code'] ?? '',
            'tracking_number' => $tracking,
            'label_path' => $labelPath,
            'request_payload' => RgcdpdptDpdDataSanitizer::sanitize($payload),
            'response_payload' => RgcdpdptDpdDataSanitizer::sanitize($response),
            'status' => 'created',
            'is_test' => RgcdpdptDpdConfig::isQaMode(),
        ]);

        RgcdpdptDpdLogRepository::add('info', 'Shipment created for order', 'order', (int) $order->id, [
            'tracking_number' => $tracking,
        ]);

        return [
            'tracking_number' => $tracking,
            'label_path' => $labelPath,
            'payload' => $payload,
            'response' => $response,
        ];
    }


    protected function isSuccessfulShipmentResponse(array $response)
    {
        $statusCode = isset($response['status_code']) ? (int) $response['status_code'] : 0;

        if ($statusCode < 200 || $statusCode >= 300) {
            return false;
        }

        if (array_key_exists('result', $response) && ($response['result'] === null || $response['result'] === false)) {
            return false;
        }

        return true;
    }

    protected function extractShipmentErrorMessage(array $response)
    {
        $candidates = [
            $response['message'] ?? null,
            $response['error_description'] ?? null,
            $response['error'] ?? null,
            $response['result']['message'] ?? null,
            $response['result']['error'] ?? null,
            $response['data']['message'] ?? null,
            $response['data']['error'] ?? null,
        ];

        foreach ($candidates as $candidate) {
            if (is_scalar($candidate) && trim((string) $candidate) !== '') {
                return trim((string) $candidate);
            }
        }

        $statusCode = isset($response['status_code']) ? (string) $response['status_code'] : 'sem código';

        return 'Resposta DPD sem sucesso (' . $statusCode . ').';
    }


    protected function extractLabelBase64(array $response)
    {
        $candidates = [
            $response['result']['pdf'] ?? null,
            $response['result']['label_pdf'] ?? null,
            $response['result']['etiqueta_pdf'] ?? null,
            $response['result']['label'] ?? null,
            $response['pdf'] ?? null,
            $response['label_pdf'] ?? null,
            $response['etiqueta_pdf'] ?? null,
            $response['data']['pdf'] ?? null,
            $response['data']['label_pdf'] ?? null,
        ];

        foreach ($candidates as $candidate) {
            if (is_string($candidate) && trim($candidate) !== '') {
                return trim($candidate);
            }
        }

        return '';
    }

    protected function extractTrackingNumber(array $response)
    {
        $preferredPaths = [
            ['result', 'num_guia'],
            ['result', 'numero_guia'],
            ['result', 'n_guia'],
            ['result', 'guia'],
            ['result', 'tracking_number'],
            ['result', 'trackingNumber'],
            ['result', 'tracking'],
            ['result', 'expedition_number'],
            ['result', 'numero_expedicao'],
            ['result', 'num_expedicao'],
            ['data', 'num_guia'],
            ['data', 'numero_guia'],
            ['data', 'tracking_number'],
            ['num_guia'],
            ['numero_guia'],
            ['tracking_number'],
            ['trackingNumber'],
            ['tracking'],
        ];

        foreach ($preferredPaths as $path) {
            $value = $this->arrayPath($response, $path);
            $tracking = $this->normalizeTrackingValue($value);
            if ($tracking !== '') {
                return $tracking;
            }
        }

        foreach (['guias_seur', 'guias', 'labels', 'shipments', 'volumes', 'parcels'] as $listKey) {
            $value = $this->findFirstValueByNormalizedKey($response, $listKey);
            $tracking = $this->extractTrackingFromMixed($value);
            if ($tracking !== '') {
                return $tracking;
            }
        }

        return $this->findFirstTrackingByKey($response);
    }

    public function setManualTrackingForOrder($idOrder, $tracking)
    {
        $order = new Order((int) $idOrder);
        if (!Validate::isLoadedObject($order)) {
            throw new Exception('Order not found.');
        }

        $tracking = $this->normalizeTrackingValue($tracking);
        if ($tracking === '') {
            throw new Exception('Informe um número de guia DPD válido.');
        }

        $shipment = RgcdpdptDpdShipmentRepository::getByOrderId((int) $order->id);
        if (!$shipment) {
            throw new Exception('DPD shipment not found for this order.');
        }

        RgcdpdptDpdShipmentRepository::updateTrackingNumber((int) $order->id, $tracking);
        $this->updateOrderCarrierTracking($order, $tracking);

        RgcdpdptDpdLogRepository::add('info', 'Shipment tracking manually set for order', 'order', (int) $order->id, [
            'tracking_number' => $tracking,
        ]);

        return $tracking;
    }

    protected function extractTrackingFromMixed($value)
    {
        $tracking = $this->normalizeTrackingValue($value);
        if ($tracking !== '') {
            return $tracking;
        }

        if (is_array($value)) {
            $fromKeys = $this->findFirstTrackingByKey($value);
            if ($fromKeys !== '') {
                return $fromKeys;
            }

            foreach ($value as $item) {
                $fromItem = $this->extractTrackingFromMixed($item);
                if ($fromItem !== '') {
                    return $fromItem;
                }
            }
        }

        return '';
    }

    protected function findFirstTrackingByKey($value)
    {
        if (!is_array($value)) {
            return '';
        }

        $wanted = [
            'numguia',
            'numeroguia',
            'nguia',
            'guia',
            'trackingnumber',
            'tracking',
            'shipmentnumber',
            'expeditionnumber',
            'numeroexpedicao',
            'numexpedicao',
            'barcode',
            'barcodenumber',
            'parcelnumber',
            'numobjeto',
            'objectnumber',
        ];

        foreach ($value as $key => $item) {
            $normalizedKey = $this->normalizeArrayKey($key);
            if (in_array($normalizedKey, $wanted, true)) {
                $tracking = $this->normalizeTrackingValue($item);
                if ($tracking !== '') {
                    return $tracking;
                }
            }
        }

        foreach ($value as $item) {
            if (is_array($item)) {
                $tracking = $this->findFirstTrackingByKey($item);
                if ($tracking !== '') {
                    return $tracking;
                }
            }
        }

        return '';
    }

    protected function findFirstValueByNormalizedKey($value, $wantedKey)
    {
        if (!is_array($value)) {
            return null;
        }

        $wantedKey = $this->normalizeArrayKey($wantedKey);
        foreach ($value as $key => $item) {
            if ($this->normalizeArrayKey($key) === $wantedKey) {
                return $item;
            }
        }

        foreach ($value as $item) {
            if (is_array($item)) {
                $found = $this->findFirstValueByNormalizedKey($item, $wantedKey);
                if ($found !== null) {
                    return $found;
                }
            }
        }

        return null;
    }

    protected function arrayPath(array $array, array $path)
    {
        $current = $array;
        foreach ($path as $part) {
            if (!is_array($current) || !array_key_exists($part, $current)) {
                return null;
            }
            $current = $current[$part];
        }

        return $current;
    }

    protected function normalizeArrayKey($key)
    {
        return Tools::strtolower(preg_replace('/[^a-zA-Z0-9]/', '', (string) $key));
    }

    protected function normalizeTrackingValue($value)
    {
        if (is_object($value)) {
            $value = get_object_vars($value);
        }

        if (is_array($value)) {
            foreach ($value as $item) {
                $tracking = $this->normalizeTrackingValue($item);
                if ($tracking !== '') {
                    return $tracking;
                }
            }

            return '';
        }

        if ($value === null) {
            return '';
        }

        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }

        $value = preg_replace('/\s+/', '', $value);
        $value = trim($value, " \t\n\r\0\x0B,;|/");

        if ($value === '' || Tools::strtolower($value) === 'null' || Tools::strtolower($value) === 'array') {
            return '';
        }

        return Tools::substr($value, 0, 64);
    }

    protected function extractTrackingFromPdfBase64($pdfBase64)
    {
        $binary = base64_decode((string) $pdfBase64, true);
        if ($binary === false || $binary === '') {
            return '';
        }

        return $this->extractTrackingFromPdfContent($binary);
    }

    protected function extractTrackingFromPdfContent($binary)
    {
        if ((string) $binary === '') {
            return '';
        }

        $searchable = (string) $binary . "\n" . $this->extractSearchablePdfStreamContent((string) $binary);

        if (!preg_match_all('/(?<!\d)(\d{12,24})(?!\d)/', $searchable, $matches)) {
            return '';
        }

        $numbers = array_values(array_unique($matches[1]));
        foreach ($numbers as $number) {
            if (preg_match('/^0\d{13,17}$/', $number)) {
                return Tools::substr($number, 0, 64);
            }
        }

        foreach ($numbers as $number) {
            if (!preg_match('/^(0+)$/', $number)) {
                return Tools::substr($number, 0, 64);
            }
        }

        return '';
    }

    protected function extractSearchablePdfStreamContent($binary)
    {
        $output = '';
        if (!preg_match_all('/<<(.*?)>>\s*stream\r?\n?(.*?)\r?\n?endstream/s', (string) $binary, $matches, PREG_SET_ORDER)) {
            return '';
        }

        foreach ($matches as $match) {
            $dict = isset($match[1]) ? (string) $match[1] : '';
            $stream = isset($match[2]) ? (string) $match[2] : '';
            $decoded = $stream;

            if (stripos($dict, 'FlateDecode') !== false) {
                $candidate = @gzuncompress($stream);
                if ($candidate === false && function_exists('zlib_decode')) {
                    $candidate = @zlib_decode($stream);
                }
                if ($candidate !== false && $candidate !== '') {
                    $decoded = $candidate;
                }
            }

            $decoded = str_replace(['\\(', '\\)', '\\\\'], ['(', ')', '\\'], $decoded);
            $output .= "\n" . $decoded;
        }

        return $output;
    }

    protected function updateOrderCarrierTracking(Order $order, $tracking)
    {
        $tracking = $this->normalizeTrackingValue($tracking);
        if ($tracking === '') {
            return false;
        }

        $updated = Db::getInstance()->update(
            'order_carrier',
            ['tracking_number' => pSQL($tracking)],
            '`id_order` = ' . (int) $order->id
        );

        try {
            if (method_exists($order, 'setWsShippingNumber')) {
                $order->setWsShippingNumber($tracking);
            }
        } catch (Exception $e) {
            RgcdpdptDpdLogRepository::add('warning', 'Could not update PrestaShop native shipping number', 'order', (int) $order->id, [
                'error' => $e->getMessage(),
                'tracking_number' => $tracking,
            ]);
        }

        return (bool) $updated;
    }


    public function refreshTrackingForOrder($idOrder)
    {
        $order = new Order((int) $idOrder);
        if (!Validate::isLoadedObject($order)) {
            throw new Exception('Order not found.');
        }

        $shipment = RgcdpdptDpdShipmentRepository::getByOrderId((int) $order->id);
        if (!$shipment) {
            throw new Exception('DPD shipment not found for this order.');
        }

        if (!empty($shipment['tracking_number'])) {
            return (string) $shipment['tracking_number'];
        }

        $response = json_decode((string) ($shipment['response_payload'] ?? ''), true);
        $tracking = is_array($response) ? $this->extractTrackingNumber($response) : '';

        if ($tracking === '' && !empty($shipment['label_path']) && is_file($shipment['label_path'])) {
            $tracking = $this->extractTrackingFromPdfContent((string) file_get_contents($shipment['label_path']));
        }

        if ($tracking === '') {
            RgcdpdptDpdLogRepository::add('warning', 'Could not refresh tracking number from saved DPD response', 'order', (int) $order->id, [
                'response_preview' => $this->sanitizedStoredResponsePreview($shipment['response_payload'] ?? ''),
            ]);
            throw new Exception('Não foi possível identificar a guia na resposta guardada da DPD. Abra a etiqueta PDF e valide o número manualmente, ou envie o payload dos logs para análise.');
        }

        RgcdpdptDpdShipmentRepository::updateTrackingNumber((int) $order->id, $tracking);
        $this->updateOrderCarrierTracking($order, $tracking);

        RgcdpdptDpdLogRepository::add('info', 'Shipment tracking refreshed for order', 'order', (int) $order->id, [
            'tracking_number' => $tracking,
        ]);

        return $tracking;
    }

    public function buildPayload(Order $order)
    {
        $carrierType = $this->getCarrierTypeFromOrder($order);
        $isPickup = RgcdpdptDpdConfig::isPickupService($carrierType);
        $deliveryAddress = new Address((int) $order->id_address_delivery);

        if (!Validate::isLoadedObject($deliveryAddress)) {
            throw new Exception('Delivery address not found.');
        }

        $pickup = $isPickup ? RgcdpdptDpdPickupRepository::getByOrderId((int) $order->id) : null;
        if ($isPickup && !$pickup) {
            $pickup = RgcdpdptDpdPickupRepository::getByCartId((int) $order->id_cart);
        }

        if (!RgcdpdptDpdConfig::isServiceEnabled($carrierType)) {
            throw new Exception('Serviço DPD não ativo: ' . RgcdpdptDpdConfig::serviceLabel($carrierType));
        }

        if (!RgcdpdptDpdConfig::supportsAddress($carrierType, $deliveryAddress)) {
            throw new Exception('O serviço DPD selecionado não corresponde ao destino da encomenda: ' . RgcdpdptDpdConfig::serviceLabel($carrierType));
        }

        $subAccountCode = RgcdpdptDpdConfig::serviceAccount($carrierType);
        if ($subAccountCode === '') {
            throw new Exception('Conta DPD não configurada para: ' . RgcdpdptDpdConfig::serviceLabel($carrierType));
        }

        $country = new Country((int) $deliveryAddress->id_country);
        $recipientPhoneCode = $this->countryPhoneCode(Validate::isLoadedObject($country) ? (string) $country->iso_code : 'PT');
        $phone = $this->cleanPhone($deliveryAddress->phone ?: $deliveryAddress->phone_mobile);
        $mobile = $this->cleanPhone($deliveryAddress->phone_mobile ?: $deliveryAddress->phone);

        $payload = [
            'sub_account' => [
                'code' => $subAccountCode,
            ],
            'sender' => [
                'id' => null,
                'name' => RgcdpdptDpdConfig::get('SENDER_NAME'),
                'phone' => $this->nullable($this->cleanPhone(RgcdpdptDpdConfig::get('SENDER_PHONE'))),
                'phone_code' => $this->nullable($this->normalizePhoneCode(RgcdpdptDpdConfig::get('SENDER_PHONE_CODE'))),
                'mobile' => $this->nullable($this->cleanPhone(RgcdpdptDpdConfig::get('SENDER_MOBILE'))),
                'mobile_code' => $this->nullable($this->normalizePhoneCode(RgcdpdptDpdConfig::get('SENDER_MOBILE_CODE'))),
                'email' => RgcdpdptDpdConfig::get('SENDER_EMAIL'),
                'save' => false,
            ],
            'shipper' => [
                'name' => RgcdpdptDpdConfig::get('SHIPPER_NAME'),
                'address' => RgcdpdptDpdConfig::get('SHIPPER_ADDRESS'),
                'zip_code' => RgcdpdptDpdConfig::get('SHIPPER_ZIP'),
                'location' => RgcdpdptDpdConfig::get('SHIPPER_CITY'),
                'country' => [
                    'id' => RgcdpdptDpdConfig::get('SHIPPER_COUNTRY_ISO2', 'PT'),
                ],
            ],
            'recipient' => [
                'id' => null,
                'name' => trim($deliveryAddress->firstname . ' ' . $deliveryAddress->lastname),
                'client_code' => null,
                'save' => false,
            ],
            'address' => [
                'id' => null,
                'country' => [
                    'id' => $country->iso_code ?: 'PT',
                    'iso2' => $country->iso_code ?: 'PT',
                ],
                'address' => trim($deliveryAddress->address1 . ' ' . $deliveryAddress->address2),
                'zip_code' => $deliveryAddress->postcode,
                'location' => $deliveryAddress->city,
                'save' => false,
            ],
            'contact' => [
                'id' => null,
                'name' => trim($deliveryAddress->firstname . ' ' . $deliveryAddress->lastname),
                'phone' => $this->nullable($phone),
                'phone_code' => $this->nullable($phone ? $recipientPhoneCode : null),
                'mobile' => $this->nullable($mobile),
                'mobile_code' => $this->nullable($mobile ? $recipientPhoneCode : null),
                'email' => $order->getCustomer()->email,
                'save' => false,
            ],
            'destinatario_usar_endereco_pickup' => $isPickup,
            'recipient_pickup_store' => [
                'number' => $isPickup && $pickup ? (string) $pickup['pickup_code'] : '',
            ],
            'pickup_store_name' => $isPickup ? trim($deliveryAddress->firstname . ' ' . $deliveryAddress->lastname) : '',
            'pickup_store_mobile' => $isPickup ? (string) $mobile : '',
            'pickup_store_mobile_code' => $isPickup && $mobile ? $recipientPhoneCode : '',
            'pickup_store_email' => $isPickup ? $order->getCustomer()->email : '',
            'opcoes_servico_predict_para_entrega' => (bool) RgcdpdptDpdConfig::get('ENABLE_PREDICT', 0),
            'encomenda_referencia' => Tools::substr($order->reference, 0, 16),
            'opcoes_servico_codigo_at' => null,
            'encomenda_observacao' => Tools::substr((string) $order->note, 0, 64),
            'expedition_date' => date('Y-m-d'),
            'expedition_time' => '23:59',
            'encomenda_peso_envio' => (string) $this->calculateOrderWeight($order),
            'encomenda_num_volumes' => (int) RgcdpdptDpdConfig::get('DEFAULT_VOLUMES', 1),
            'opcoes_servico_enviar_a_cobranca' => false,
            'opcoes_servico_montante' => null,
            'etiqueta_hide_nome' => false,
            'etiqueta_hide_telemovel' => false,
            'etiqueta_hide_email' => false,
            'etiqueta_formato' => [
                'id' => (int) RgcdpdptDpdConfig::get('LABEL_FORMAT_ID', 1),
            ],
            'etiqueta_enviar_etiqueta_por_email' => false,
            'zpl_response' => false,
            'pdf_response' => true,
            'qr_response' => false,
        ];

        if (RgcdpdptDpdConfig::isFreshService($carrierType)) {
            $freshDates = RgcdpdptDpdFreshDateCalculator::calculate(null, RgcdpdptDpdConfig::freshExpirationDays());
            $payload['expedition_date'] = $freshDates['expedition_date'];
            $payload['fresh_pickup_date'] = $freshDates['pickup_date'];
            $payload['fresh_expiration_date'] = $freshDates['expiration_date'];
        }

        return $payload;
    }

    protected function getCarrierTypeFromOrder(Order $order)
    {
        $carrier = new Carrier((int) $order->id_carrier);
        $carrierReference = Validate::isLoadedObject($carrier) ? (int) $carrier->id_reference : 0;
        $carrierName = Validate::isLoadedObject($carrier) ? (string) $carrier->name : '';
        $type = (new RgcdpdptDpdCarrierManager($this->module))->getMatchedType((int) $order->id_carrier, $carrierReference, $carrierName);

        return $type !== '' ? $type : RgcdpdptDpdCarrierManager::TYPE_HOME;
    }

    protected function storeLabel(Order $order, $pdfBase64)
    {
        return RgcdpdptDpdStorage::storeLabel((int) $order->id, $pdfBase64);
    }

    protected function calculateOrderWeight(Order $order)
    {
        $products = $order->getProducts();
        $weight = 0.0;
        foreach ($products as $product) {
            $weight += ((float) $product['product_weight']) * ((int) $product['product_quantity']);
        }

        if ($weight <= 0) {
            $weight = 1.0;
        }

        return number_format($weight, 2, '.', '');
    }

    protected function cleanPhone($phone)
    {
        $digits = preg_replace('/[^0-9]/', '', (string) $phone);
        return $digits !== '' ? $digits : null;
    }

    protected function normalizePhoneCode($code)
    {
        $code = trim((string) $code);
        if ($code === '') {
            return null;
        }

        return strpos($code, '+') === 0 ? $code : '+' . ltrim($code, '+');
    }

    protected function countryPhoneCode($iso2)
    {
        $iso2 = Tools::strtoupper(trim((string) $iso2));
        $map = [
            'PT' => '+351',
            'ES' => '+34',
            'FR' => '+33',
            'DE' => '+49',
            'IT' => '+39',
            'NL' => '+31',
            'BE' => '+32',
            'LU' => '+352',
            'IE' => '+353',
            'GB' => '+44',
            'UK' => '+44',
        ];

        return $map[$iso2] ?? '+351';
    }

    protected function sanitizePayloadForLog($value)
    {
        return RgcdpdptDpdDataSanitizer::sanitize($value);
    }

    protected function sanitizedStoredResponsePreview($payload)
    {
        $payload = trim((string) $payload);
        if ($payload === '') {
            return '';
        }

        $decoded = json_decode($payload, true);
        if (is_array($decoded)) {
            $payload = json_encode(
                RgcdpdptDpdDataSanitizer::sanitize($decoded),
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
            );
        }

        return Tools::substr((string) $payload, 0, 1200);
    }

    protected function nullable($value)
    {
        return $value === '' ? null : $value;
    }
}
