<?php
class RgcdpdptDpdConfig
{
    public const PREFIX = 'RGCDPDPT_';
    public const DEFAULT_CLIENT_ID = '2';
    public const DEFAULT_CLIENT_SECRET = 'rczLIC19WQd4p7wCeQHejNCvBtyJRKgVMvTA34Li';
    public const DEFAULT_TRACE_URL = 'https://wservices.dpd.pt/trace/track';
    public const DEFAULT_TRACE_API_KEY = 'SuLfcLTxG2jo1jzfoiZAk1I0JsZOhk';
    public const DEFAULT_TRACE_COUNTRY_CODE = 'PT';
    public const DEFAULT_TRACE_CRON_LIMIT = 50;

    public static function serviceDefinitions()
    {
        return [
            'home' => [
                'label' => 'DPD Portugal Home',
                'delivery' => 'home',
                'default_account' => '09999001',
                'default_name' => 'DPD Portugal Home',
                'default_enabled' => '1',
                'default_rate' => '0',
            ],
            'pickup' => [
                'label' => 'DPD Portugal Shop',
                'delivery' => 'pickup',
                'default_account' => '09999002',
                'default_name' => 'DPD Portugal Shop',
                'default_enabled' => '1',
                'default_rate' => '0',
            ],
            'pt_fresh' => [
                'label' => 'DPD Portugal Fresh',
                'delivery' => 'home',
                'default_account' => '09999008',
                'default_name' => 'DPD Portugal Fresh',
                'default_enabled' => '0',
                'default_rate' => '0',
            ],
            'pt_islands' => [
                'label' => 'DPD Portugal Ilhas',
                'delivery' => 'home',
                'default_account' => '09999003',
                'default_name' => 'DPD Portugal Ilhas',
                'default_enabled' => '1',
                'default_rate' => '0',
            ],
            'es_home' => [
                'label' => 'DPD Espanha Home',
                'delivery' => 'home',
                'default_account' => '09999004',
                'default_name' => 'DPD Espanha Home',
                'default_enabled' => '1',
                'default_rate' => '0',
            ],
            'es_pickup' => [
                'label' => 'DPD Espanha Shop',
                'delivery' => 'pickup',
                'default_account' => '09999005',
                'default_name' => 'DPD Espanha Shop',
                'default_enabled' => '1',
                'default_rate' => '0',
            ],
            'int_home' => [
                'label' => 'DPD Internacional Home',
                'delivery' => 'home',
                'default_account' => '09999006',
                'default_name' => 'DPD Internacional Home',
                'default_enabled' => '1',
                'default_rate' => '0',
            ],
            'int_pickup' => [
                'label' => 'DPD Internacional Shop',
                'delivery' => 'pickup',
                'default_account' => '09999007',
                'default_name' => 'DPD Internacional Shop',
                'default_enabled' => '1',
                'default_rate' => '0',
            ],
        ];
    }

    public static function definitions()
    {
        $definitions = [
            'MODE' => 'live',
            'OAUTH_URL' => 'https://business.dpd.pt/api/v1/pt/oauth/token',
            'SHIPMENT_URL' => 'https://business.dpd.pt/api/v1/pt/expedition/registarExpedicao',
            'COLLECT_URL' => 'https://business.dpd.pt/api/v1/pt/collect',
            'MANIFEST_URL' => 'https://business.dpd.pt/api/v1/pt/expedition/fechoApi',
            'PICKUP_WSDL' => 'http://mypudo.pickup-services.com/mypudo/mypudo.asmx?wsdl',
            'PICKUP_CARRIER' => 'CHR',
            'PICKUP_KEY' => '',
            'PICKUP_MAX_POINTS' => '10',
            'PICKUP_MAX_DISTANCE' => '20',
            'PICKUP_CONFIG_OPEN' => '0',
            'INSTALL_REPORT_ENDPOINT' => 'https://api.rgcconsulting.pt/dpd/register-install',
            'INSTALL_ID' => '',
            'INSTALL_CREATED_AT' => '',
            'INSTALL_REPORTED' => '0',
            'INSTALL_REPORTED_AT' => '',
            'INSTALL_REPORTED_VERSION' => '',
            'INSTALL_LAST_REPORT_ATTEMPT' => '',
            'INSTALL_LAST_REPORT_ERROR' => '',
            'UPDATE_URL' => 'https://api.rgcconsulting.pt/dpd/module/latest/rgcdpdpt_latest.zip',
            'UPDATE_CHECK_INTERVAL' => '86400',
            'UPDATE_LAST_CHECK' => '',
            'UPDATE_LATEST_VERSION' => '',
            'UPDATE_DOWNLOAD_URL' => '',
            'UPDATE_PACKAGE_SHA256' => '',
            'UPDATE_LAST_ERROR' => '',
            'API_USERNAME' => '',
            'API_PASSWORD' => '',
            'TRACE_URL' => 'https://wservices.dpd.pt/trace/track',
            'TRACE_API_KEY' => '',
            'TRACE_COUNTRY_CODE' => 'PT',
            'TRACE_SYNC_ENABLED' => '0',
            'TRACE_CRON_TOKEN' => '',
            'TRACE_CRON_LIMIT' => '50',
            'TRACE_STATE_COL_ID' => '0',
            'TRACE_STATE_OFD_ID' => '0',
            'TRACE_STATE_POD_ID' => '0',
            'CLIENT_ID' => self::DEFAULT_CLIENT_ID,
            'CLIENT_SECRET' => self::DEFAULT_CLIENT_SECRET,
            'MAX_WEIGHT' => '30',
            'ENABLE_PREDICT' => '0',
            'FRESH_EXPIRATION_DAYS' => '5',
            'DEFAULT_VOLUMES' => '1',
            'LABEL_FORMAT_ID' => '1',
            'LOG_ENABLED' => '1',
            'LOG_RETENTION_DAYS' => '90',
            'SENDER_NAME' => '',
            'SENDER_PHONE' => '',
            'SENDER_PHONE_CODE' => '+351',
            'SENDER_MOBILE' => '',
            'SENDER_MOBILE_CODE' => '+351',
            'SENDER_EMAIL' => '',
            'SHIPPER_NAME' => '',
            'SHIPPER_ADDRESS' => '',
            'SHIPPER_ZIP' => '',
            'SHIPPER_CITY' => '',
            'SHIPPER_COUNTRY_ISO2' => 'PT',
        ];

        foreach (self::serviceDefinitions() as $type => $definition) {
            $suffix = self::serviceKeySuffix($type);
            $definitions['SERVICE_' . $suffix . '_ENABLED'] = (string) ($definition['default_enabled'] ?? '0');
            $definitions['SERVICE_' . $suffix . '_ACCOUNT'] = (string) ($definition['default_account'] ?? '');
            $definitions['SERVICE_' . $suffix . '_NAME'] = (string) ($definition['default_name'] ?? $definition['label']);
            $definitions['RATE_' . $suffix] = (string) ($definition['default_rate'] ?? '0');
            $definitions['CARRIER_' . $suffix . '_ID'] = '0';
            $definitions['CARRIER_' . $suffix . '_REF'] = '0';
        }

        return $definitions;
    }

    public static function key($name)
    {
        return self::PREFIX . $name;
    }

    public static function get($name, $default = null)
    {
        $value = Configuration::get(self::key($name));
        if ($value === false || $value === null || $value === '') {
            $definitions = self::definitions();
            return array_key_exists($name, $definitions) ? $definitions[$name] : $default;
        }

        if (self::isSensitiveField($name)) {
            return self::decodeSensitiveValue((string) $value);
        }

        return $value;
    }

    public static function set($name, $value)
    {
        if (self::isSensitiveField($name)) {
            return Configuration::updateValue(self::key($name), self::encodeSensitiveValue((string) $value), false);
        }

        return Configuration::updateValue(self::key($name), (string) $value, false);
    }

    public static function isSensitiveField($name)
    {
        return in_array($name, self::sensitiveFields(), true);
    }

    protected static function sensitiveFields()
    {
        return [
            'API_PASSWORD',
            'CLIENT_SECRET',
            'PICKUP_KEY',
            'TRACE_API_KEY',
            'TRACE_CRON_TOKEN',
        ];
    }

    protected static function encodeSensitiveValue($value)
    {
        $value = (string) $value;
        if ($value === '') {
            return '';
        }

        $encryptionKey = self::sensitiveEncryptionKey();
        if ($encryptionKey !== null && function_exists('openssl_encrypt') && function_exists('random_bytes')) {
            try {
                $iv = random_bytes(12);
                $tag = '';
                $ciphertext = openssl_encrypt(
                    $value,
                    'aes-256-gcm',
                    $encryptionKey,
                    OPENSSL_RAW_DATA,
                    $iv,
                    $tag,
                    'rgcdpdpt:v1',
                    16
                );

                if ($ciphertext !== false && strlen($tag) === 16) {
                    return 'enc:v1:' . base64_encode($iv . $tag . $ciphertext);
                }
            } catch (Exception $e) {
                // Compatibility fallback below.
            }
        }

        // Legacy-compatible fallback for environments without OpenSSL.
        return 'base64:' . base64_encode($value);
    }

    protected static function decodeSensitiveValue($value)
    {
        $value = (string) $value;

        if (strpos($value, 'enc:v1:') === 0) {
            $payload = base64_decode(substr($value, 7), true);
            if ($payload === false || strlen($payload) < 29 || !function_exists('openssl_decrypt')) {
                return '';
            }

            $encryptionKey = self::sensitiveEncryptionKey();
            if ($encryptionKey === null) {
                return '';
            }

            $iv = substr($payload, 0, 12);
            $tag = substr($payload, 12, 16);
            $ciphertext = substr($payload, 28);
            $decoded = openssl_decrypt(
                $ciphertext,
                'aes-256-gcm',
                $encryptionKey,
                OPENSSL_RAW_DATA,
                $iv,
                $tag,
                'rgcdpdpt:v1'
            );

            return $decoded !== false ? $decoded : '';
        }

        if (strpos($value, 'base64:') === 0) {
            $decoded = base64_decode(substr($value, 7), true);
            if ($decoded !== false) {
                return $decoded;
            }
        }

        // Accept pre-1.0.6 plaintext values so they can be migrated safely.
        return $value;
    }

    protected static function sensitiveEncryptionKey()
    {
        $seed = defined('_COOKIE_KEY_') ? (string) _COOKIE_KEY_ : '';
        if ($seed === '' && defined('_COOKIE_IV_')) {
            $seed = (string) _COOKIE_IV_;
        }
        if ($seed === '') {
            return null;
        }

        return hash('sha256', 'rgcdpdpt-sensitive|' . $seed, true);
    }

    public static function migrateSensitiveStorage()
    {
        foreach (self::sensitiveFields() as $name) {
            $key = self::key($name);
            $raw = Configuration::get($key);
            if ($raw === false || $raw === null || $raw === '') {
                continue;
            }

            $raw = (string) $raw;
            if (strpos($raw, 'enc:v1:') === 0) {
                continue;
            }

            $decoded = self::decodeSensitiveValue($raw);
            if ($decoded !== '') {
                self::set($name, $decoded);
            }
        }

        return true;
    }

    public static function all()
    {
        $output = [];
        foreach (self::definitions() as $name => $default) {
            $output[$name] = self::get($name, $default);
        }

        return $output;
    }

    public static function installDefaults($overwrite = true)
    {
        foreach (self::definitions() as $name => $default) {
            $key = self::key($name);
            $current = Configuration::get($key);
            $hasValue = $current !== false && $current !== null && $current !== '';

            if ($hasValue && self::isSensitiveField($name)) {
                $hasValue = trim((string) self::decodeSensitiveValue((string) $current)) !== '';
            }

            if (!$overwrite && $hasValue) {
                continue;
            }

            self::set($name, $default);
        }

        return true;
    }

    public static function ensureDefaults()
    {
        return self::installDefaults(false);
    }

    public static function ensureInternalOAuthCredentials()
    {
        // These credentials are defined by DPD for this plugin and are not
        // editable in the backoffice. Keep them synchronized on install,
        // upgrade and before requesting an OAuth token.
        self::set('CLIENT_ID', self::DEFAULT_CLIENT_ID);
        self::set('CLIENT_SECRET', self::DEFAULT_CLIENT_SECRET);

        return true;
    }

    public static function removeAll()
    {
        foreach (array_keys(self::definitions()) as $name) {
            Configuration::deleteByName(self::key($name));
        }

        return true;
    }

    public static function isQaMode()
    {
        return self::get('MODE') !== 'live';
    }

    public static function normalizeServiceType($type)
    {
        $type = strtolower(trim((string) $type));
        $type = str_replace('-', '_', $type);

        if ($type === 'pt_home') {
            return 'home';
        }

        if ($type === 'pt_pickup' || $type === 'pt_shop') {
            return 'pickup';
        }

        return $type;
    }

    public static function serviceKeySuffix($type)
    {
        $type = self::normalizeServiceType($type);
        return strtoupper(preg_replace('/[^a-z0-9]+/i', '_', $type));
    }

    public static function serviceTypes()
    {
        return array_keys(self::serviceDefinitions());
    }

    public static function pickupServiceTypes()
    {
        $types = [];
        foreach (self::serviceDefinitions() as $type => $definition) {
            if (($definition['delivery'] ?? 'home') === 'pickup') {
                $types[] = $type;
            }
        }

        return $types;
    }

    public static function isKnownServiceType($type)
    {
        return array_key_exists(self::normalizeServiceType($type), self::serviceDefinitions());
    }

    public static function serviceLabel($type)
    {
        $type = self::normalizeServiceType($type);
        $definitions = self::serviceDefinitions();
        return isset($definitions[$type]) ? $definitions[$type]['label'] : $type;
    }

    public static function isPickupService($type)
    {
        $type = self::normalizeServiceType($type);
        $definitions = self::serviceDefinitions();
        return isset($definitions[$type]) && ($definitions[$type]['delivery'] ?? 'home') === 'pickup';
    }

    public static function isFreshService($type)
    {
        return self::normalizeServiceType($type) === 'pt_fresh';
    }

    public static function isServiceEnabled($type)
    {
        $type = self::normalizeServiceType($type);
        if (!self::isKnownServiceType($type)) {
            return false;
        }

        return (bool) (int) self::get('SERVICE_' . self::serviceKeySuffix($type) . '_ENABLED', 0);
    }

    public static function serviceName($type)
    {
        $type = self::normalizeServiceType($type);
        $definitions = self::serviceDefinitions();
        $fallback = isset($definitions[$type]) ? $definitions[$type]['default_name'] : $type;
        $value = trim((string) self::get('SERVICE_' . self::serviceKeySuffix($type) . '_NAME', $fallback));

        return $value !== '' ? $value : $fallback;
    }

    public static function serviceAccount($type)
    {
        $type = self::normalizeServiceType($type);
        return trim((string) self::get('SERVICE_' . self::serviceKeySuffix($type) . '_ACCOUNT', ''));
    }

    public static function carrierIdKey($type)
    {
        $type = self::normalizeServiceType($type);
        return 'CARRIER_' . self::serviceKeySuffix($type) . '_ID';
    }

    public static function carrierRefKey($type)
    {
        $type = self::normalizeServiceType($type);
        return 'CARRIER_' . self::serviceKeySuffix($type) . '_REF';
    }

    public static function serviceRate($type, $bucket = '')
    {
        $type = self::normalizeServiceType($type);
        if (!self::isKnownServiceType($type)) {
            return 0.0;
        }

        return self::normalizeDecimal(self::get('RATE_' . self::serviceKeySuffix($type), 0));
    }

    public static function fallbackCarrierRate($carrierType)
    {
        return self::serviceRate($carrierType);
    }

    public static function supportsAddress($type, Address $address)
    {
        $type = self::normalizeServiceType($type);
        $iso2 = self::addressCountryIso2($address);
        if ($iso2 === '') {
            return false;
        }

        if ($type === 'home') {
            return $iso2 === 'PT' && RgcdpdptDpdZoneResolver::resolveByPostcode($address->postcode) === RgcdpdptDpdZoneResolver::MAINLAND;
        }

        if ($type === 'pickup') {
            return $iso2 === 'PT' && RgcdpdptDpdZoneResolver::resolveByPostcode($address->postcode) === RgcdpdptDpdZoneResolver::MAINLAND;
        }

        if ($type === 'pt_fresh') {
            return $iso2 === 'PT' && RgcdpdptDpdZoneResolver::resolveByPostcode($address->postcode) === RgcdpdptDpdZoneResolver::MAINLAND;
        }

        if ($type === 'pt_islands') {
            return $iso2 === 'PT' && RgcdpdptDpdZoneResolver::resolveByPostcode($address->postcode) !== RgcdpdptDpdZoneResolver::MAINLAND;
        }

        if ($type === 'es_home') {
            return $iso2 === 'ES';
        }

        if ($type === 'es_pickup') {
            return $iso2 === 'ES';
        }

        if ($type === 'int_home') {
            return !in_array($iso2, ['PT', 'ES'], true);
        }

        if ($type === 'int_pickup') {
            return !in_array($iso2, ['PT', 'ES'], true);
        }

        return false;
    }

    public static function addressCountryIso2(Address $address)
    {
        $country = new Country((int) $address->id_country);
        if (!Validate::isLoadedObject($country)) {
            return '';
        }

        return Tools::strtoupper((string) $country->iso_code);
    }

    public static function normalizeDecimal($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return 0.0;
        }

        $value = str_replace(["\xc2\xa0", ' '], '', $value);
        $value = preg_replace('/[^0-9,\.\-]/', '', $value);

        if ($value === '' || $value === '-' || $value === ',' || $value === '.') {
            return 0.0;
        }

        $lastComma = strrpos($value, ',');
        $lastDot = strrpos($value, '.');

        if ($lastComma !== false && $lastDot !== false) {
            if ($lastComma > $lastDot) {
                $value = str_replace('.', '', $value);
                $value = str_replace(',', '.', $value);
            } else {
                $value = str_replace(',', '', $value);
            }
        } elseif ($lastComma !== false) {
            $value = str_replace(',', '.', $value);
        }

        return (float) $value;
    }

    public static function formatPriceForDisplay($value)
    {
        return number_format((float) $value, 2, ',', '.') . ' EUR';
    }

    public static function maxWeight()
    {
        return (float) self::get('MAX_WEIGHT', 30);
    }

    public static function freshExpirationDays()
    {
        $days = (int) self::get('FRESH_EXPIRATION_DAYS', 5);
        if ($days < 1) {
            return 5;
        }

        return min($days, 365);
    }

    public static function trackingSyncEnabled()
    {
        return (bool) (int) self::get('TRACE_SYNC_ENABLED', 0);
    }

    public static function trackingCountryCode()
    {
        return self::DEFAULT_TRACE_COUNTRY_CODE;
    }

    public static function trackingCronLimit()
    {
        return self::DEFAULT_TRACE_CRON_LIMIT;
    }

    public static function ensureTrackingCronToken()
    {
        $token = trim((string) self::get('TRACE_CRON_TOKEN', ''));
        if ($token !== '') {
            return $token;
        }

        try {
            $token = function_exists('random_bytes') ? bin2hex(random_bytes(24)) : Tools::passwdGen(48);
        } catch (Exception $e) {
            $token = Tools::passwdGen(48);
        }

        self::set('TRACE_CRON_TOKEN', $token);
        return $token;
    }

    public static function loggingEnabled()
    {
        return (bool) self::get('LOG_ENABLED', 1);
    }

    public static function logRetentionDays()
    {
        $days = (int) self::get('LOG_RETENTION_DAYS', 90);
        if ($days <= 0) {
            return 0;
        }

        return min($days, 3650);
    }
}
