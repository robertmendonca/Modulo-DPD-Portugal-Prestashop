<?php
class RgcdpdptDpdShipmentRepository
{
    public static function getByOrderId($idOrder)
    {
        return Db::getInstance()->getRow('
            SELECT *
            FROM `' . _DB_PREFIX_ . 'rgcdpd_shipment`
            WHERE `id_order` = ' . (int) $idOrder
        );
    }

    public static function saveForOrder($idOrder, $idCart, array $data)
    {
        $existing = self::getByOrderId($idOrder);
        $payload = [
            'id_cart' => (int) $idCart,
            'carrier_type' => pSQL((string) ($data['carrier_type'] ?? 'home')),
            'dpd_sub_account' => pSQL((string) ($data['dpd_sub_account'] ?? '')),
            'tracking_number' => pSQL((string) ($data['tracking_number'] ?? '')),
            'label_path' => pSQL((string) ($data['label_path'] ?? '')),
            'request_payload' => pSQL(self::encodeSanitizedPayload($data['request_payload'] ?? null), true),
            'response_payload' => pSQL(self::encodeSanitizedPayload($data['response_payload'] ?? null), true),
            'status' => pSQL((string) ($data['status'] ?? 'created')),
            'is_test' => !empty($data['is_test']) ? 1 : 0,
            'date_upd' => date('Y-m-d H:i:s'),
        ];

        if ($existing) {
            $oldTracking = trim((string) ($existing['tracking_number'] ?? ''));
            $newTracking = trim((string) ($payload['tracking_number'] ?? ''));
            if ($newTracking !== '' && $newTracking !== $oldTracking) {
                $payload = array_merge($payload, self::traceResetPayload());
            }

            return Db::getInstance()->update('rgcdpd_shipment', $payload, '`id_rgcdpd_shipment` = ' . (int) $existing['id_rgcdpd_shipment']);
        }

        $payload['id_order'] = (int) $idOrder;
        $payload['date_add'] = date('Y-m-d H:i:s');

        return Db::getInstance()->insert('rgcdpd_shipment', $payload);
    }

    public static function updateTrackingNumber($idOrder, $trackingNumber)
    {
        $existing = self::getByOrderId((int) $idOrder);
        $trackingNumber = trim((string) $trackingNumber);
        $payload = [
            'tracking_number' => pSQL($trackingNumber),
            'date_upd' => date('Y-m-d H:i:s'),
        ];

        if ($existing && $trackingNumber !== '' && $trackingNumber !== trim((string) ($existing['tracking_number'] ?? ''))) {
            $payload = array_merge($payload, self::traceResetPayload());
        }

        return Db::getInstance()->update('rgcdpd_shipment', $payload, '`id_order` = ' . (int) $idOrder);
    }

    public static function getPendingTrackingSync($limit = 50)
    {
        $limit = max(1, min(250, (int) $limit));

        try {
            return Db::getInstance()->executeS(
                'SELECT * FROM `' . _DB_PREFIX_ . 'rgcdpd_shipment` '
                . "WHERE `tracking_number` IS NOT NULL AND TRIM(`tracking_number`) <> '' "
                . "AND `trace_delivered` = 0 AND `is_test` = 0 AND `status` <> 'failed' "
                . 'ORDER BY COALESCE(`trace_last_sync_at`, `date_add`) ASC, `id_rgcdpd_shipment` ASC '
                . 'LIMIT ' . (int) $limit
            ) ?: [];
        } catch (Exception $e) {
            return [];
        }
    }

    public static function updateTraceEvent($idOrder, array $event, $stage = 0, $delivered = false)
    {
        $existing = self::getByOrderId((int) $idOrder);
        if (!$existing) {
            return false;
        }

        $stage = max((int) ($existing['trace_stage'] ?? 0), (int) $stage);
        $isDelivered = !empty($existing['trace_delivered']) || $delivered;
        $description = Tools::substr(trim((string) ($event['description'] ?? '')), 0, 255);
        $eventCode = Tools::substr(strtoupper(trim((string) ($event['code'] ?? ''))), 0, 16);
        $eventDateTime = trim((string) ($event['datetime'] ?? ''));

        return Db::getInstance()->update('rgcdpd_shipment', [
            'trace_event_code' => pSQL($eventCode),
            'trace_event_description' => pSQL($description),
            'trace_event_datetime' => $eventDateTime !== '' ? pSQL($eventDateTime) : null,
            'trace_last_sync_at' => date('Y-m-d H:i:s'),
            'trace_last_error' => null,
            'trace_stage' => $stage,
            'trace_delivered' => $isDelivered ? 1 : 0,
            'date_upd' => date('Y-m-d H:i:s'),
        ], '`id_order` = ' . (int) $idOrder);
    }

    public static function touchTraceSync($idOrder)
    {
        return Db::getInstance()->update('rgcdpd_shipment', [
            'trace_last_sync_at' => date('Y-m-d H:i:s'),
            'trace_last_error' => null,
            'date_upd' => date('Y-m-d H:i:s'),
        ], '`id_order` = ' . (int) $idOrder);
    }

    public static function updateTraceError($idOrder, $error)
    {
        return Db::getInstance()->update('rgcdpd_shipment', [
            'trace_last_sync_at' => date('Y-m-d H:i:s'),
            'trace_last_error' => pSQL(Tools::substr(trim((string) $error), 0, 255)),
            'date_upd' => date('Y-m-d H:i:s'),
        ], '`id_order` = ' . (int) $idOrder);
    }

    public static function countPendingTrackingSync()
    {
        try {
            return (int) Db::getInstance()->getValue(
                'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'rgcdpd_shipment` '
                . "WHERE `tracking_number` IS NOT NULL AND TRIM(`tracking_number`) <> '' "
                . "AND `trace_delivered` = 0 AND `is_test` = 0 AND `status` <> 'failed'"
            );
        } catch (Exception $e) {
            return 0;
        }
    }

    protected static function traceResetPayload()
    {
        return [
            'trace_event_code' => null,
            'trace_event_description' => null,
            'trace_event_datetime' => null,
            'trace_last_sync_at' => null,
            'trace_last_error' => null,
            'trace_stage' => 0,
            'trace_delivered' => 0,
        ];
    }

    protected static function encodeSanitizedPayload($payload)
    {
        if (is_string($payload)) {
            $trimmed = trim($payload);
            if ($trimmed === '') {
                return '';
            }

            $decoded = json_decode($trimmed, true);
            if (!is_array($decoded)) {
                return '[payload não estruturado omitido]';
            }
            $payload = $decoded;
        }

        $sanitized = RgcdpdptDpdDataSanitizer::sanitize($payload);
        $encoded = json_encode($sanitized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        return $encoded !== false ? $encoded : '';
    }

    public static function sanitizeStoredPayloads()
    {
        $lastId = 0;

        do {
            $rows = Db::getInstance()->executeS(
                'SELECT `id_rgcdpd_shipment`, `request_payload`, `response_payload` '
                . 'FROM `' . _DB_PREFIX_ . 'rgcdpd_shipment` '
                . 'WHERE `id_rgcdpd_shipment` > ' . (int) $lastId . ' '
                . 'ORDER BY `id_rgcdpd_shipment` ASC LIMIT 100'
            ) ?: [];

            foreach ($rows as $row) {
                $lastId = (int) $row['id_rgcdpd_shipment'];
                $request = self::sanitizeStoredPayloadValue($row['request_payload'] ?? '');
                $response = self::sanitizeStoredPayloadValue($row['response_payload'] ?? '');

                Db::getInstance()->update('rgcdpd_shipment', [
                    'request_payload' => pSQL($request, true),
                    'response_payload' => pSQL($response, true),
                    'date_upd' => date('Y-m-d H:i:s'),
                ], '`id_rgcdpd_shipment` = ' . $lastId);
            }
        } while (count($rows) === 100);

        return true;
    }

    protected static function sanitizeStoredPayloadValue($payload)
    {
        $payload = trim((string) $payload);
        if ($payload === '') {
            return '';
        }

        $decoded = json_decode($payload, true);
        if (!is_array($decoded)) {
            return '[payload legado não estruturado omitido na atualização 1.0.6]';
        }

        $sanitized = RgcdpdptDpdDataSanitizer::sanitize($decoded);
        $encoded = json_encode($sanitized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        return $encoded !== false ? $encoded : '';
    }
}
