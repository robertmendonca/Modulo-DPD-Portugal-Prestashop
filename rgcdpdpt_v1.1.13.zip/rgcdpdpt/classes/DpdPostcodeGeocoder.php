<?php

class RgcdpdptDpdPostcodeGeocoder
{
    const ENDPOINT_BASE = 'https://json.geoapi.pt/codigo_postal/';
    const CACHE_TTL = 15552000; // 180 days
    const MIN_REQUEST_INTERVAL = 1.05;

    protected $moduleVersion;

    public function __construct($moduleVersion = '')
    {
        $this->moduleVersion = trim((string) $moduleVersion);
    }

    /**
     * Geocode a complete Portuguese postcode using GEO API PT.
     *
     * Only the postcode is sent. No customer street, name, email or phone is
     * transmitted. Returns ['latitude' => float, 'longitude' => float,
     * 'source' => string, 'locality' => string] or null.
     */
    public function geocodePortuguesePostcode($postcode)
    {
        $postcode = $this->normalizePortuguesePostcode($postcode);
        if ($postcode === '') {
            return null;
        }

        $cached = $this->readCache($postcode);
        if ($cached !== null) {
            return $cached;
        }

        if (!function_exists('curl_init')) {
            return null;
        }

        $result = $this->requestGeoApiPt($postcode);
        if ($result === null) {
            RgcdpdptDpdLogRepository::add('info', 'Pickup postcode geocoding unavailable; using DPD fallback ordering', 'pickup', 0, [
                'zip' => $this->maskPostcode($postcode),
                'source' => 'geoapi_pt',
            ]);
            return null;
        }

        $this->writeCache($postcode, $result);

        RgcdpdptDpdLogRepository::add('info', 'Pickup postcode geocoded for distance ordering', 'pickup', 0, [
            'zip' => $this->maskPostcode($postcode),
            'source' => 'geoapi_pt',
            'locality' => Tools::substr((string) ($result['locality'] ?? ''), 0, 80),
        ]);

        return $result;
    }

    protected function requestGeoApiPt($postcode)
    {
        $this->respectPublicServiceRateLimit();

        $url = self::ENDPOINT_BASE . rawurlencode($postcode);
        $ch = curl_init($url);
        if ($ch === false) {
            return null;
        }

        $version = $this->moduleVersion !== '' ? $this->moduleVersion : 'unknown';
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 2,
            CURLOPT_CONNECTTIMEOUT => 4,
            CURLOPT_TIMEOUT => 7,
            CURLOPT_HTTPHEADER => [
                'Accept: application/json',
                'User-Agent: RGC-DPD-PT/' . $version . ' (https://github.com/robertmendonca/Modulo-DPD-Portugal-Prestashop)',
            ],
        ]);

        $body = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($body === false || $status < 200 || $status >= 300) {
            return null;
        }

        $decoded = json_decode((string) $body, true);
        if (!is_array($decoded)) {
            return null;
        }

        if (!$this->responseMatchesPostcode($decoded, $postcode)) {
            RgcdpdptDpdLogRepository::add('warning', 'Pickup postcode geocoder returned a different postcode; response ignored', 'pickup', 0, [
                'zip' => $this->maskPostcode($postcode),
                'source' => 'geoapi_pt',
            ]);
            return null;
        }

        $coordinates = $this->extractCoordinates($decoded);
        if ($coordinates === null) {
            return null;
        }

        return [
            'latitude' => $coordinates[0],
            'longitude' => $coordinates[1],
            'source' => 'geoapi_pt',
            'locality' => trim((string) ($decoded['Localidade'] ?? ($decoded['Designação Postal'] ?? ''))),
        ];
    }

    protected function responseMatchesPostcode(array $decoded, $postcode)
    {
        $digits = preg_replace('/[^0-9]/', '', (string) $postcode);
        if (strlen($digits) !== 7) {
            return false;
        }

        $expectedCp4 = (int) substr($digits, 0, 4);
        $expectedCp3 = (int) substr($digits, 4, 3);

        if (isset($decoded['CP4']) && (int) $decoded['CP4'] !== $expectedCp4) {
            return false;
        }

        if (array_key_exists('CP3', $decoded)) {
            $cp3 = $decoded['CP3'];
            if (is_array($cp3)) {
                $values = array_map('intval', $cp3);
                if (!in_array($expectedCp3, $values, true)) {
                    return false;
                }
            } elseif ((int) $cp3 !== $expectedCp3) {
                return false;
            }
        }

        return true;
    }

    /**
     * GEO API PT exposes several representative coordinates. For a complete
     * CP7 we prefer "centro", which is the centre derived from the postcode
     * data points, then fall back to centre of mass/centroid/individual point.
     */
    protected function extractCoordinates(array $decoded)
    {
        $candidates = [];

        foreach (['centro', 'centroDeMassa', 'centroide'] as $key) {
            if (isset($decoded[$key]) && is_array($decoded[$key])) {
                $candidates[] = $decoded[$key];
            }
        }

        if (!empty($decoded['pontos']) && is_array($decoded['pontos'])) {
            foreach ($decoded['pontos'] as $point) {
                if (is_array($point) && isset($point['coordenadas']) && is_array($point['coordenadas'])) {
                    $candidates[] = $point['coordenadas'];
                }
            }
        }

        foreach ($candidates as $candidate) {
            if (!isset($candidate[0], $candidate[1])) {
                continue;
            }

            $lat = $this->coordinate($candidate[0], -90, 90);
            $lon = $this->coordinate($candidate[1], -180, 180);
            if ($lat === null || $lon === null) {
                continue;
            }

            // Portuguese territory is safely inside these broad bounds. This
            // catches accidentally reversed or unrelated coordinates.
            if ($lat < 30.0 || $lat > 43.0 || $lon < -32.0 || $lon > -5.0) {
                continue;
            }

            return [$lat, $lon];
        }

        return null;
    }

    protected function respectPublicServiceRateLimit()
    {
        $path = $this->rateLimitFile();
        $handle = @fopen($path, 'c+');
        if (!$handle) {
            return;
        }

        if (@flock($handle, LOCK_EX)) {
            rewind($handle);
            $previous = (float) trim((string) stream_get_contents($handle));
            $now = microtime(true);
            $elapsed = $previous > 0 ? ($now - $previous) : self::MIN_REQUEST_INTERVAL;
            if ($elapsed < self::MIN_REQUEST_INTERVAL) {
                usleep((int) ((self::MIN_REQUEST_INTERVAL - $elapsed) * 1000000));
            }

            ftruncate($handle, 0);
            rewind($handle);
            fwrite($handle, sprintf('%.6f', microtime(true)));
            fflush($handle);
            flock($handle, LOCK_UN);
        }

        fclose($handle);
    }

    protected function readCache($postcode)
    {
        $path = $this->cacheFile();
        if (!is_file($path)) {
            return null;
        }

        $raw = @file_get_contents($path);
        $data = json_decode((string) $raw, true);
        if (!is_array($data) || empty($data[$postcode]) || !is_array($data[$postcode])) {
            return null;
        }

        $entry = $data[$postcode];
        $storedAt = (int) ($entry['stored_at'] ?? 0);
        if ($storedAt <= 0 || (time() - $storedAt) > self::CACHE_TTL) {
            return null;
        }

        $lat = $this->coordinate($entry['latitude'] ?? null, -90, 90);
        $lon = $this->coordinate($entry['longitude'] ?? null, -180, 180);
        if ($lat === null || $lon === null) {
            return null;
        }

        return [
            'latitude' => $lat,
            'longitude' => $lon,
            'source' => (string) ($entry['source'] ?? 'geoapi_pt_cache'),
            'locality' => (string) ($entry['locality'] ?? ''),
        ];
    }

    protected function writeCache($postcode, array $result)
    {
        $path = $this->cacheFile();
        $dir = dirname($path);
        if (!is_dir($dir) || !is_writable($dir)) {
            return;
        }

        $handle = @fopen($path, 'c+');
        if (!$handle) {
            return;
        }

        if (@flock($handle, LOCK_EX)) {
            rewind($handle);
            $existing = json_decode((string) stream_get_contents($handle), true);
            if (!is_array($existing)) {
                $existing = [];
            }

            $existing[$postcode] = [
                'latitude' => (float) $result['latitude'],
                'longitude' => (float) $result['longitude'],
                'source' => (string) ($result['source'] ?? 'geoapi_pt'),
                'locality' => (string) ($result['locality'] ?? ''),
                'stored_at' => time(),
            ];

            if (count($existing) > 1000) {
                uasort($existing, function ($a, $b) {
                    return (int) ($b['stored_at'] ?? 0) <=> (int) ($a['stored_at'] ?? 0);
                });
                $existing = array_slice($existing, 0, 1000, true);
            }

            $json = json_encode($existing, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($json !== false) {
                ftruncate($handle, 0);
                rewind($handle);
                fwrite($handle, $json);
                fflush($handle);
            }
            flock($handle, LOCK_UN);
        }

        fclose($handle);
    }

    protected function normalizePortuguesePostcode($postcode)
    {
        $digits = preg_replace('/[^0-9]/', '', (string) $postcode);
        if (strlen($digits) !== 7) {
            return '';
        }

        return substr($digits, 0, 4) . '-' . substr($digits, 4, 3);
    }

    protected function coordinate($value, $min, $max)
    {
        if (!is_scalar($value)) {
            return null;
        }

        $value = str_replace(',', '.', trim((string) $value));
        if ($value === '' || !is_numeric($value)) {
            return null;
        }

        $float = (float) $value;
        if ($float < $min || $float > $max) {
            return null;
        }

        return $float;
    }

    protected function cacheFile()
    {
        // New cache file intentionally avoids reusing Nominatim coordinates
        // stored by 1.1.11.
        return $this->cacheBaseDir() . 'rgcdpdpt_postcode_geoapi_pt.json';
    }

    protected function rateLimitFile()
    {
        return $this->cacheBaseDir() . 'rgcdpdpt_geoapi_pt_rate.lock';
    }

    protected function cacheBaseDir()
    {
        $base = defined('_PS_CACHE_DIR_') ? (string) _PS_CACHE_DIR_ : sys_get_temp_dir() . DIRECTORY_SEPARATOR;
        return rtrim($base, '/\\') . DIRECTORY_SEPARATOR;
    }

    protected function maskPostcode($postcode)
    {
        if (preg_match('/^([0-9]{4})-([0-9]{3})$/', (string) $postcode, $m)) {
            return $m[1] . '-***';
        }

        return '***';
    }
}
