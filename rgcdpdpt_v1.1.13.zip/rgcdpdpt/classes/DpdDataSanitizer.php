<?php
class RgcdpdptDpdDataSanitizer
{
    public static function sanitize($value)
    {
        if (!is_array($value)) {
            return $value;
        }

        $sanitized = [];
        foreach ($value as $key => $item) {
            $normalizedKey = self::normalizeKey($key);

            if (self::isCredentialKey($normalizedKey)) {
                $sanitized[$key] = '[omitido]';
                continue;
            }

            if (self::isLabelContentKey($normalizedKey)) {
                $sanitized[$key] = '[conteúdo da etiqueta omitido]';
                continue;
            }

            if (is_array($item)) {
                $sanitized[$key] = self::sanitize($item);
                continue;
            }

            if (!is_scalar($item) && $item !== null) {
                $sanitized[$key] = '[omitido]';
                continue;
            }

            if (self::isEmailKey($normalizedKey)) {
                $sanitized[$key] = self::maskEmail((string) $item);
                continue;
            }

            if (self::isPhoneKey($normalizedKey)) {
                $sanitized[$key] = self::maskValue((string) $item, 3);
                continue;
            }

            if (self::isNameKey($normalizedKey) || self::isAddressKey($normalizedKey) || self::isLocationKey($normalizedKey)) {
                $sanitized[$key] = trim((string) $item) !== '' ? '[omitido]' : '';
                continue;
            }

            if (self::isPostcodeKey($normalizedKey)) {
                $sanitized[$key] = self::maskPostcode((string) $item);
                continue;
            }

            if (self::isFreeTextKey($normalizedKey)) {
                $sanitized[$key] = trim((string) $item) !== '' ? '[omitido]' : '';
                continue;
            }

            $sanitized[$key] = $item;
        }

        return $sanitized;
    }

    protected static function normalizeKey($key)
    {
        $key = preg_replace('/[^a-zA-Z0-9]/', '', (string) $key);
        return class_exists('Tools') ? Tools::strtolower($key) : strtolower($key);
    }

    protected static function isCredentialKey($key)
    {
        return in_array($key, [
            'password',
            'clientsecret',
            'accesstoken',
            'refreshtoken',
            'token',
            'authorization',
            'apikey',
            'pickupkey',
        ], true);
    }

    protected static function isLabelContentKey($key)
    {
        return in_array($key, [
            'pdf',
            'labelpdf',
            'etiquetapdf',
            'zpl',
            'qr',
            'qrcode',
            'pdfresponse',
            'zplresponse',
            'qrresponse',
        ], true);
    }

    protected static function isEmailKey($key)
    {
        return strpos($key, 'email') !== false;
    }

    protected static function isPhoneKey($key)
    {
        return strpos($key, 'phone') !== false
            || strpos($key, 'mobile') !== false
            || strpos($key, 'telephone') !== false
            || strpos($key, 'telemovel') !== false;
    }

    protected static function isNameKey($key)
    {
        return $key === 'name' || substr($key, -4) === 'name';
    }

    protected static function isAddressKey($key)
    {
        return strpos($key, 'address') !== false || strpos($key, 'morada') !== false;
    }

    protected static function isLocationKey($key)
    {
        return in_array($key, [
            'city',
            'location',
            'locality',
            'cidade',
        ], true);
    }

    protected static function isPostcodeKey($key)
    {
        return strpos($key, 'postcode') !== false
            || strpos($key, 'zipcode') !== false
            || $key === 'zip'
            || substr($key, -3) === 'zip';
    }

    protected static function isFreeTextKey($key)
    {
        return in_array($key, [
            'note',
            'notes',
            'comment',
            'comments',
            'observation',
            'observations',
            'encomendaobservacao',
        ], true);
    }

    public static function maskEmail($email)
    {
        $email = trim((string) $email);
        if ($email === '' || strpos($email, '@') === false) {
            return $email !== '' ? '[omitido]' : '';
        }

        $parts = explode('@', $email, 2);
        return self::maskValue($parts[0], 2) . '@' . $parts[1];
    }

    public static function maskPostcode($postcode)
    {
        $postcode = trim((string) $postcode);
        if ($postcode === '') {
            return '';
        }

        if (preg_match('/^(\d{4})[-\s]?(\d{3})$/', $postcode, $matches)) {
            return $matches[1] . '-***';
        }

        $length = class_exists('Tools') ? Tools::strlen($postcode) : strlen($postcode);
        if ($length <= 3) {
            return str_repeat('*', $length);
        }

        $prefix = class_exists('Tools') ? Tools::substr($postcode, 0, 3) : substr($postcode, 0, 3);
        return $prefix . str_repeat('*', max(1, $length - 3));
    }

    public static function maskValue($value, $visible = 2)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }

        $visible = max(0, (int) $visible);
        $length = class_exists('Tools') ? Tools::strlen($value) : strlen($value);
        if ($length <= $visible) {
            return str_repeat('*', $length);
        }

        $tail = class_exists('Tools') ? Tools::substr($value, -$visible) : substr($value, -$visible);
        return str_repeat('*', $length - $visible) . $tail;
    }
}
