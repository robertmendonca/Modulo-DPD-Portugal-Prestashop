<?php
class RgcdpdptDpdTraceClient
{
    public function track($trackingNumber, $countryCode = 'PT')
    {
        $trackingNumber = trim((string) $trackingNumber);
        if ($trackingNumber === '') {
            throw new Exception('Guia DPD em falta para consulta de tracking.');
        }

        // The Trace endpoint and API key are universal values supplied by DPD
        // for this integration. They are intentionally not merchant-editable.
        $url = RgcdpdptDpdConfig::DEFAULT_TRACE_URL;
        $apiKey = RgcdpdptDpdConfig::DEFAULT_TRACE_API_KEY;

        $countryCode = strtoupper(trim((string) $countryCode));
        if (!in_array($countryCode, ['PT', 'EN'], true)) {
            $countryCode = 'PT';
        }

        $query = http_build_query([
            'countrycode' => $countryCode,
            'search' => $trackingNumber,
        ], '', '&', PHP_QUERY_RFC3986);
        $requestUrl = rtrim($url, '?&') . (strpos($url, '?') === false ? '?' : '&') . $query;

        $ch = curl_init($requestUrl);
        curl_setopt_array($ch, [
            CURLOPT_HTTPGET => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 45,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_USERAGENT => 'RGC-DPD-PT-Prestashop/' . (defined('_PS_VERSION_') ? _PS_VERSION_ : 'unknown'),
            CURLOPT_HTTPHEADER => [
                'apikey: ' . $apiKey,
                'Accept: application/json',
                'Connection: close',
            ],
        ]);

        $raw = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($errno) {
            throw new Exception('Erro de ligação à API Trace DPD [' . (int) $errno . ']: ' . $error);
        }

        if ($status < 200 || $status >= 300) {
            throw new Exception('API Trace DPD respondeu HTTP ' . $status . '.');
        }

        $decoded = json_decode((string) $raw, true);
        if (!is_array($decoded)) {
            throw new Exception('API Trace DPD devolveu uma resposta JSON inválida.');
        }

        return $decoded;
    }
}
