<?php
class RgcdpdptDpdLogRepository
{
    protected static $purgedThisRequest = false;

    protected static function tableExists()
    {
        return RgcdpdptDpdSchema::hasTable('rgcdpd_log');
    }

    public static function add($level, $message, $contextType = 'system', $contextId = null, $payload = null)
    {
        if (!RgcdpdptDpdConfig::loggingEnabled() || !self::tableExists()) {
            return true;
        }

        self::purgeExpired();

        $sanitizedPayload = $payload !== null ? RgcdpdptDpdDataSanitizer::sanitize($payload) : null;
        if ($sanitizedPayload !== null && !is_string($sanitizedPayload)) {
            $sanitizedPayload = json_encode($sanitizedPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }

        return Db::getInstance()->insert('rgcdpd_log', [
            'context_type' => pSQL(Tools::substr((string) $contextType, 0, 64)),
            'context_id' => $contextId !== null ? (int) $contextId : null,
            'level' => pSQL(Tools::substr((string) $level, 0, 16)),
            'message' => pSQL(Tools::substr((string) $message, 0, 255)),
            'payload' => $sanitizedPayload !== null ? pSQL((string) $sanitizedPayload, true) : null,
            'date_add' => date('Y-m-d H:i:s'),
        ]);
    }

    public static function latest($limit = 20)
    {
        if (!self::tableExists()) {
            return [];
        }

        self::purgeExpired();
        $limit = max(1, min(100, (int) $limit));

        try {
            return Db::getInstance()->executeS(
                'SELECT * FROM `' . _DB_PREFIX_ . 'rgcdpd_log` ORDER BY `id_rgcdpd_log` DESC LIMIT ' . (int) $limit
            ) ?: [];
        } catch (Exception $e) {
            return [];
        }
    }

    public static function purgeExpired()
    {
        if (self::$purgedThisRequest || !self::tableExists()) {
            return true;
        }

        self::$purgedThisRequest = true;
        $days = RgcdpdptDpdConfig::logRetentionDays();
        if ($days <= 0) {
            return true;
        }

        try {
            return (bool) Db::getInstance()->execute(
                'DELETE FROM `' . _DB_PREFIX_ . 'rgcdpd_log` '
                . 'WHERE `date_add` < DATE_SUB(NOW(), INTERVAL ' . (int) $days . ' DAY)'
            );
        } catch (Exception $e) {
            return false;
        }
    }

    public static function sanitizeExistingPayloads()
    {
        if (!self::tableExists()) {
            return true;
        }

        $lastId = 0;
        do {
            $rows = Db::getInstance()->executeS(
                'SELECT `id_rgcdpd_log`, `payload` FROM `' . _DB_PREFIX_ . 'rgcdpd_log` '
                . 'WHERE `id_rgcdpd_log` > ' . (int) $lastId . ' '
                . 'ORDER BY `id_rgcdpd_log` ASC LIMIT 100'
            ) ?: [];

            foreach ($rows as $row) {
                $lastId = (int) $row['id_rgcdpd_log'];
                $payload = trim((string) ($row['payload'] ?? ''));
                if ($payload === '') {
                    continue;
                }

                $decoded = json_decode($payload, true);
                if (is_array($decoded)) {
                    $sanitized = RgcdpdptDpdDataSanitizer::sanitize($decoded);
                    $payload = json_encode($sanitized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                    if ($payload === false) {
                        $payload = '';
                    }
                } else {
                    $payload = '[payload legado não estruturado omitido na atualização 1.0.6]';
                }

                Db::getInstance()->update('rgcdpd_log', [
                    'payload' => pSQL((string) $payload, true),
                ], '`id_rgcdpd_log` = ' . $lastId);
            }
        } while (count($rows) === 100);

        self::$purgedThisRequest = false;
        self::purgeExpired();
        return true;
    }
}
