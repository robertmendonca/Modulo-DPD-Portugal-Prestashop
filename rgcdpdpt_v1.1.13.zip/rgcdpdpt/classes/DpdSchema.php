<?php
class RgcdpdptDpdSchema
{
    public static function install()
    {
        $installed = (bool) require dirname(__DIR__) . '/sql/install.php';
        return $installed && self::ensureTrackingColumns();
    }

    public static function uninstall()
    {
        return (bool) require dirname(__DIR__) . '/sql/uninstall.php';
    }

    public static function tableName($name)
    {
        return _DB_PREFIX_ . ltrim((string) $name, '_');
    }

    public static function hasTable($name)
    {
        $table = pSQL(self::tableName($name));
        $sql = "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '" . $table . "'";

        try {
            return (bool) Db::getInstance()->getValue($sql);
        } catch (Exception $e) {
            return false;
        }
    }

    public static function ensureTrackingColumns()
    {
        if (!self::hasTable('rgcdpd_shipment')) {
            return false;
        }

        $columns = [
            'trace_event_code' => 'VARCHAR(16) NULL',
            'trace_event_description' => 'VARCHAR(255) NULL',
            'trace_event_datetime' => 'DATETIME NULL',
            'trace_last_sync_at' => 'DATETIME NULL',
            'trace_last_error' => 'VARCHAR(255) NULL',
            'trace_stage' => 'TINYINT UNSIGNED NOT NULL DEFAULT 0',
            'trace_delivered' => 'TINYINT(1) NOT NULL DEFAULT 0',
        ];

        foreach ($columns as $name => $definition) {
            if (self::hasColumn('rgcdpd_shipment', $name)) {
                continue;
            }

            $sql = 'ALTER TABLE `' . self::tableName('rgcdpd_shipment') . '` ADD COLUMN `'
                . pSQL($name) . '` ' . $definition;
            if (!Db::getInstance()->execute($sql)) {
                return false;
            }
        }

        self::ensureIndex(
            'rgcdpd_shipment',
            'idx_rgcdpd_shipment_trace_pending',
            '`trace_delivered`, `tracking_number`'
        );

        return true;
    }

    public static function hasColumn($tableName, $columnName)
    {
        $table = pSQL(self::tableName($tableName));
        $column = pSQL((string) $columnName);

        try {
            return (bool) Db::getInstance()->getValue(
                "SELECT COUNT(*) FROM information_schema.COLUMNS "
                . "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '" . $table . "' AND COLUMN_NAME = '" . $column . "'"
            );
        } catch (Exception $e) {
            return false;
        }
    }

    protected static function ensureIndex($tableName, $indexName, $columnsSql)
    {
        $table = pSQL(self::tableName($tableName));
        $index = pSQL((string) $indexName);

        try {
            $exists = (bool) Db::getInstance()->getValue(
                "SELECT COUNT(*) FROM information_schema.STATISTICS "
                . "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '" . $table . "' AND INDEX_NAME = '" . $index . "'"
            );
            if ($exists) {
                return true;
            }

            return (bool) Db::getInstance()->execute(
                'ALTER TABLE `' . self::tableName($tableName) . '` ADD INDEX `' . $index . '` (' . $columnsSql . ')'
            );
        } catch (Exception $e) {
            return false;
        }
    }
}
