<?php
class RgcdpdptDpdTrackingSyncService
{
    protected $module;

    public function __construct($module = null)
    {
        $this->module = $module;
    }

    public function syncPending($limit = null)
    {
        if (!RgcdpdptDpdConfig::trackingSyncEnabled()) {
            throw new Exception('Sincronização automática de tracking DPD está desativada.');
        }

        if (!RgcdpdptDpdSchema::ensureTrackingColumns()) {
            throw new Exception('Não foi possível preparar a estrutura de tracking DPD.');
        }

        RgcdpdptDpdOrderStateManager::ensureDefaults();
        $limit = $limit === null ? RgcdpdptDpdConfig::trackingCronLimit() : max(1, min(250, (int) $limit));

        $result = [
            'scanned' => 0,
            'updated' => 0,
            'unchanged' => 0,
            'delivered' => 0,
            'errors' => 0,
            'busy' => false,
        ];

        $lockName = 'rgcdpdpt_trace_sync';
        $hasLock = $this->acquireLock($lockName);
        if ($hasLock === false) {
            $result['busy'] = true;
            return $result;
        }

        try {
            foreach (RgcdpdptDpdShipmentRepository::getPendingTrackingSync($limit) as $shipment) {
                $result['scanned']++;
                $idOrder = (int) $shipment['id_order'];

                try {
                    $sync = $this->syncOrder($idOrder, false);
                    if (!empty($sync['order_state_changed'])) {
                        $result['updated']++;
                    } else {
                        $result['unchanged']++;
                    }
                    if (!empty($sync['delivered'])) {
                        $result['delivered']++;
                    }
                } catch (Exception $e) {
                    $result['errors']++;
                    RgcdpdptDpdShipmentRepository::updateTraceError($idOrder, $e->getMessage());
                    RgcdpdptDpdLogRepository::add('error', 'DPD Trace synchronization failed', 'order', $idOrder, [
                        'error' => $e->getMessage(),
                    ]);
                }
            }
        } finally {
            if ($hasLock === true) {
                $this->releaseLock($lockName);
            }
        }

        return $result;
    }

    public function syncOrder($idOrder, $force = true)
    {
        $idOrder = (int) $idOrder;
        $order = new Order($idOrder);
        if (!Validate::isLoadedObject($order)) {
            throw new Exception('Encomenda não encontrada.');
        }

        if (!$force && !RgcdpdptDpdConfig::trackingSyncEnabled()) {
            throw new Exception('Sincronização automática de tracking DPD está desativada.');
        }

        RgcdpdptDpdSchema::ensureTrackingColumns();
        RgcdpdptDpdOrderStateManager::ensureDefaults();

        $shipment = RgcdpdptDpdShipmentRepository::getByOrderId($idOrder);
        if (!$shipment) {
            throw new Exception('Expedição DPD não encontrada para esta encomenda.');
        }

        $trackingNumber = trim((string) ($shipment['tracking_number'] ?? ''));
        if ($trackingNumber === '') {
            throw new Exception('A expedição ainda não tem uma guia DPD válida.');
        }

        if (!empty($shipment['trace_delivered']) && !$force) {
            return [
                'id_order' => $idOrder,
                'tracking_number' => $trackingNumber,
                'event_code' => (string) ($shipment['trace_event_code'] ?? ''),
                'event_description' => (string) ($shipment['trace_event_description'] ?? ''),
                'stage' => (int) ($shipment['trace_stage'] ?? 0),
                'order_state_changed' => false,
                'delivered' => true,
            ];
        }

        try {
            $response = (new RgcdpdptDpdTraceClient())->track(
                $trackingNumber,
                RgcdpdptDpdConfig::trackingCountryCode()
            );
        } catch (Exception $e) {
            RgcdpdptDpdShipmentRepository::updateTraceError($idOrder, $e->getMessage());
            throw $e;
        }

        $analysis = $this->analyseTraceResponse($response);
        if (!$analysis['latest_event']) {
            RgcdpdptDpdShipmentRepository::touchTraceSync($idOrder);
            RgcdpdptDpdLogRepository::add('info', 'DPD Trace response contained no events yet', 'order', $idOrder, [
                'tracking_number' => $trackingNumber,
            ]);

            return [
                'id_order' => $idOrder,
                'tracking_number' => $trackingNumber,
                'event_code' => '',
                'event_description' => '',
                'stage' => (int) ($shipment['trace_stage'] ?? 0),
                'order_state_changed' => false,
                'delivered' => !empty($shipment['trace_delivered']),
            ];
        }

        $latestEvent = $analysis['latest_event'];
        $observedStage = (int) $analysis['stage'];
        $storedStage = max(
            (int) ($shipment['trace_stage'] ?? 0),
            $this->mappedStageForOrderState((int) $order->current_state)
        );
        $effectiveStage = max($storedStage, $observedStage);
        $delivered = !empty($shipment['trace_delivered']) || $observedStage >= 3;
        $orderStateChanged = false;
        $targetCode = $this->codeForStage($observedStage);

        if ($observedStage > $storedStage && $targetCode !== '') {
            $targetConfigKey = RgcdpdptDpdTraceEventMap::automaticStateConfigKey($targetCode);
            $targetStateId = (int) RgcdpdptDpdConfig::get($targetConfigKey, 0);

            if (!RgcdpdptDpdOrderStateManager::isValidStateId($targetStateId)) {
                throw new Exception('Estado PrestaShop não configurado para o evento DPD ' . $targetCode . '.');
            }

            if (!$this->isProtectedTerminalState((int) $order->current_state)) {
                $orderStateChanged = $this->changeOrderState($order, $targetStateId, $targetCode);
            } else {
                RgcdpdptDpdLogRepository::add('warning', 'DPD Trace state not applied because order is in a protected terminal state', 'order', $idOrder, [
                    'event_code' => $targetCode,
                    'current_order_state' => (int) $order->current_state,
                    'target_order_state' => $targetStateId,
                ]);
            }
        }

        RgcdpdptDpdShipmentRepository::updateTraceEvent(
            $idOrder,
            $latestEvent,
            $effectiveStage,
            $delivered
        );

        $previousCode = strtoupper(trim((string) ($shipment['trace_event_code'] ?? '')));
        $previousDateTime = trim((string) ($shipment['trace_event_datetime'] ?? ''));
        if ($previousCode !== $latestEvent['code'] || $previousDateTime !== $latestEvent['datetime']) {
            $level = RgcdpdptDpdTraceEventMap::isKnown($latestEvent['code']) ? 'info' : 'warning';
            RgcdpdptDpdLogRepository::add($level, 'DPD Trace event updated', 'order', $idOrder, [
                'tracking_number' => $trackingNumber,
                'event_code' => $latestEvent['code'],
                'event_description' => $latestEvent['description'],
                'event_datetime' => $latestEvent['datetime'],
                'automatic_stage' => $observedStage,
                'order_state_changed' => $orderStateChanged,
            ]);
        }

        return [
            'id_order' => $idOrder,
            'tracking_number' => $trackingNumber,
            'event_code' => $latestEvent['code'],
            'event_description' => $latestEvent['description'],
            'event_datetime' => $latestEvent['datetime'],
            'stage' => $effectiveStage,
            'order_state_changed' => $orderStateChanged,
            'delivered' => $delivered,
        ];
    }

    protected function analyseTraceResponse(array $response)
    {
        $latestEvent = null;
        $parcelStages = [];
        $hasParcel = false;

        foreach ($response as $parcelIndex => $parcel) {
            if (!is_array($parcel) || !isset($parcel['Trace']) || !is_array($parcel['Trace'])) {
                continue;
            }

            $hasParcel = true;
            $parcelStage = 0;

            foreach ($parcel['Trace'] as $rawEvent) {
                if (!is_array($rawEvent)) {
                    continue;
                }

                $event = $this->normalizeEvent($rawEvent);
                if (!$event) {
                    continue;
                }

                $eventStage = RgcdpdptDpdTraceEventMap::automaticStage($event['code']);
                if ($eventStage > $parcelStage) {
                    $parcelStage = $eventStage;
                }

                if ($latestEvent === null || $event['timestamp'] > $latestEvent['timestamp']) {
                    $latestEvent = $event;
                }
            }

            $parcelStages[(string) $parcelIndex] = $parcelStage;
        }

        if (!$hasParcel || $latestEvent === null) {
            return ['latest_event' => null, 'stage' => 0];
        }

        // A search can return more than one parcel/volume. Only advance the order
        // when every returned parcel has reached the same automatic milestone.
        $stage = $parcelStages ? min($parcelStages) : 0;
        unset($latestEvent['timestamp']);

        return [
            'latest_event' => $latestEvent,
            'stage' => (int) $stage,
        ];
    }

    protected function normalizeEvent(array $rawEvent)
    {
        $code = strtoupper(trim((string) ($rawEvent['EventCod'] ?? '')));
        $rawDateTime = trim((string) ($rawEvent['EventDateTime'] ?? ''));
        if ($code === '' || $rawDateTime === '') {
            return null;
        }

        $timestamp = strtotime($rawDateTime);
        if ($timestamp === false) {
            return null;
        }

        $apiDescription = trim((string) ($rawEvent['EventDescription'] ?? ''));
        $description = $apiDescription !== ''
            ? $apiDescription
            : RgcdpdptDpdTraceEventMap::description($code, '');

        return [
            'code' => Tools::substr($code, 0, 16),
            'description' => Tools::substr($description, 0, 255),
            'datetime' => date('Y-m-d H:i:s', $timestamp),
            'timestamp' => $timestamp,
        ];
    }

    protected function codeForStage($stage)
    {
        $codes = [
            1 => 'COL',
            2 => 'OFD',
            3 => 'POD',
        ];

        return isset($codes[(int) $stage]) ? $codes[(int) $stage] : '';
    }

    protected function mappedStageForOrderState($idOrderState)
    {
        $idOrderState = (int) $idOrderState;
        if ($idOrderState <= 0) {
            return 0;
        }

        $stateStages = [
            (int) RgcdpdptDpdConfig::get('TRACE_STATE_COL_ID', 0) => 1,
            (int) RgcdpdptDpdConfig::get('TRACE_STATE_OFD_ID', 0) => 2,
            (int) RgcdpdptDpdConfig::get('TRACE_STATE_POD_ID', 0) => 3,
        ];

        return isset($stateStages[$idOrderState]) ? (int) $stateStages[$idOrderState] : 0;
    }

    protected function isProtectedTerminalState($idOrderState)
    {
        $protected = array_filter([
            (int) Configuration::get('PS_OS_CANCELED'),
            (int) Configuration::get('PS_OS_REFUND'),
            (int) Configuration::get('PS_OS_ERROR'),
        ]);

        return in_array((int) $idOrderState, $protected, true);
    }

    protected function changeOrderState(Order $order, $targetStateId, $eventCode)
    {
        $targetStateId = (int) $targetStateId;
        if ((int) $order->current_state === $targetStateId) {
            return false;
        }

        $history = new OrderHistory();
        $history->id_order = (int) $order->id;
        $history->id_employee = 0;
        $history->changeIdOrderState($targetStateId, $order);

        $added = $history->addWithemail();
        if (!$added) {
            $reloaded = new Order((int) $order->id);
            if (!Validate::isLoadedObject($reloaded) || (int) $reloaded->current_state !== $targetStateId) {
                throw new Exception('Não foi possível alterar o estado da encomenda no PrestaShop.');
            }

            RgcdpdptDpdLogRepository::add('warning', 'Order state changed but PrestaShop email could not be sent', 'order', (int) $order->id, [
                'event_code' => $eventCode,
                'target_order_state' => $targetStateId,
            ]);
        }

        RgcdpdptDpdLogRepository::add('info', 'Order state updated from DPD Trace', 'order', (int) $order->id, [
            'event_code' => $eventCode,
            'target_order_state' => $targetStateId,
        ]);

        return true;
    }

    protected function acquireLock($lockName)
    {
        try {
            return (int) Db::getInstance()->getValue(
                "SELECT GET_LOCK('" . pSQL((string) $lockName) . "', 0)"
            ) === 1;
        } catch (Exception $e) {
            // If advisory locks are unavailable, keep the synchronizer usable.
            return null;
        }
    }

    protected function releaseLock($lockName)
    {
        try {
            Db::getInstance()->getValue(
                "SELECT RELEASE_LOCK('" . pSQL((string) $lockName) . "')"
            );
        } catch (Exception $e) {
            // Nothing else to do.
        }
    }
}
