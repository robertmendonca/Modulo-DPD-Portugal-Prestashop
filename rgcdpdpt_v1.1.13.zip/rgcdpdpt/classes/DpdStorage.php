<?php
class RgcdpdptDpdStorage
{
    public static function labelDirectory()
    {
        if (!defined('_PS_ROOT_DIR_')) {
            throw new RuntimeException('Diretório raiz do PrestaShop indisponível.');
        }

        return rtrim((string) _PS_ROOT_DIR_, '/\\') . DIRECTORY_SEPARATOR
            . 'var' . DIRECTORY_SEPARATOR
            . 'modules' . DIRECTORY_SEPARATOR
            . 'rgcdpdpt' . DIRECTORY_SEPARATOR
            . 'labels' . DIRECTORY_SEPARATOR;
    }

    public static function ensureLabelDirectory()
    {
        $dir = self::labelDirectory();
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
            return false;
        }

        if (!is_writable($dir)) {
            return false;
        }

        self::writeProtectionFiles($dir);
        return true;
    }

    public static function storeLabel($idOrder, $pdfBase64)
    {
        if (!self::ensureLabelDirectory()) {
            throw new RuntimeException('Não foi possível preparar o armazenamento privado das etiquetas DPD.');
        }

        $pdf = base64_decode((string) $pdfBase64, true);
        if ($pdf === false || $pdf === '' || strncmp($pdf, '%PDF', 4) !== 0) {
            throw new RuntimeException('A DPD devolveu uma etiqueta PDF inválida.');
        }

        $suffix = self::randomSuffix();
        $filename = 'dpd_label_order_' . (int) $idOrder . '_' . $suffix . '.pdf';
        $path = self::labelDirectory() . $filename;
        $tmpPath = $path . '.tmp';

        $bytes = @file_put_contents($tmpPath, $pdf, LOCK_EX);
        if ($bytes === false || $bytes !== strlen($pdf)) {
            @unlink($tmpPath);
            throw new RuntimeException('Não foi possível guardar a etiqueta PDF da DPD.');
        }

        @chmod($tmpPath, 0600);
        if (!@rename($tmpPath, $path)) {
            @unlink($tmpPath);
            throw new RuntimeException('Não foi possível finalizar o ficheiro da etiqueta PDF da DPD.');
        }

        @chmod($path, 0600);
        return $path;
    }

    public static function migrateLegacyLabels()
    {
        if (!defined('_PS_MODULE_DIR_') || !RgcdpdptDpdSchema::hasTable('rgcdpd_shipment')) {
            return true;
        }

        $legacyDir = rtrim((string) _PS_MODULE_DIR_, '/\\') . DIRECTORY_SEPARATOR
            . 'rgcdpdpt' . DIRECTORY_SEPARATOR . 'var' . DIRECTORY_SEPARATOR . 'labels' . DIRECTORY_SEPARATOR;

        if (!is_dir($legacyDir)) {
            return true;
        }

        if (!self::ensureLabelDirectory()) {
            return false;
        }

        $rows = Db::getInstance()->executeS(
            'SELECT `id_rgcdpd_shipment`, `id_order`, `label_path` '
            . 'FROM `' . _DB_PREFIX_ . 'rgcdpd_shipment` '
            . "WHERE `label_path` LIKE '" . pSQL($legacyDir) . "%'"
        ) ?: [];

        foreach ($rows as $row) {
            $oldPath = (string) ($row['label_path'] ?? '');
            if ($oldPath === '' || !is_file($oldPath)) {
                continue;
            }

            $contents = @file_get_contents($oldPath);
            if ($contents === false || $contents === '' || strncmp($contents, '%PDF', 4) !== 0) {
                continue;
            }

            $newFilename = 'dpd_label_order_' . (int) $row['id_order'] . '_' . self::randomSuffix() . '.pdf';
            $newPath = self::labelDirectory() . $newFilename;
            if (@file_put_contents($newPath, $contents, LOCK_EX) === false) {
                return false;
            }

            @chmod($newPath, 0600);
            $updated = Db::getInstance()->update('rgcdpd_shipment', [
                'label_path' => pSQL($newPath),
                'date_upd' => date('Y-m-d H:i:s'),
            ], '`id_rgcdpd_shipment` = ' . (int) $row['id_rgcdpd_shipment']);

            if (!$updated) {
                @unlink($newPath);
                return false;
            }

            @unlink($oldPath);
        }

        foreach (['.gitkeep', '.htaccess', 'index.php'] as $markerFile) {
            $markerPath = $legacyDir . $markerFile;
            if (is_file($markerPath)) {
                @unlink($markerPath);
            }
        }
        @rmdir($legacyDir);
        @rmdir(dirname(rtrim($legacyDir, "/\\")));

        return true;
    }

    public static function isManagedLabelPath($path)
    {
        $path = trim((string) $path);
        if ($path === '' || !is_file($path)) {
            return false;
        }

        $realPath = realpath($path);
        $realDir = realpath(self::labelDirectory());
        if ($realPath === false || $realDir === false) {
            return false;
        }

        $prefix = rtrim($realDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
        return strpos($realPath, $prefix) === 0 && strtolower(pathinfo($realPath, PATHINFO_EXTENSION)) === 'pdf';
    }

    public static function removeAllLabels()
    {
        try {
            $dir = self::labelDirectory();
        } catch (Exception $e) {
            return true;
        }

        if (!is_dir($dir)) {
            return true;
        }

        $items = @scandir($dir);
        if (!is_array($items)) {
            return false;
        }

        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }

            $path = $dir . $item;
            if (is_file($path) || is_link($path)) {
                @unlink($path);
            }
        }

        @rmdir($dir);
        @rmdir(dirname(rtrim($dir, '/\\')));
        return true;
    }

    protected static function writeProtectionFiles($dir)
    {
        $htaccess = $dir . '.htaccess';
        if (!is_file($htaccess)) {
            @file_put_contents($htaccess, "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n", LOCK_EX);
            @chmod($htaccess, 0600);
        }

        $index = $dir . 'index.php';
        if (!is_file($index)) {
            @file_put_contents($index, "<?php\nhttp_response_code(404);\nexit;\n", LOCK_EX);
            @chmod($index, 0600);
        }
    }

    protected static function randomSuffix()
    {
        if (function_exists('random_bytes')) {
            try {
                return bin2hex(random_bytes(16));
            } catch (Exception $e) {
                // Fallback below.
            }
        }

        return substr(hash('sha256', uniqid((string) mt_rand(), true) . microtime(true)), 0, 32);
    }
}
