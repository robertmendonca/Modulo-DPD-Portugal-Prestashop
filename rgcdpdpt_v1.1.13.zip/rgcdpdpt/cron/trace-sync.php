<?php
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('CLI only');
}

$rootDir = dirname(__DIR__, 3);
$configFile = $rootDir . '/config/config.inc.php';
$initFile = $rootDir . '/init.php';

if (!is_file($configFile)) {
    fwrite(STDERR, "PrestaShop config not found.\n");
    exit(2);
}

require_once $configFile;
if (is_file($initFile)) {
    require_once $initFile;
}

$module = Module::getInstanceByName('rgcdpdpt');
if (!$module || !Validate::isLoadedObject($module) || !Module::isEnabled('rgcdpdpt')) {
    fwrite(STDERR, "RGC DPD PT module not available or disabled.\n");
    exit(3);
}

try {
    $result = (new RgcdpdptDpdTrackingSyncService($module))->syncPending();
    $output = [
        'ok' => true,
        'result' => $result,
        'pending' => RgcdpdptDpdShipmentRepository::countPendingTrackingSync(),
        'executed_at' => date('c'),
    ];
    fwrite(STDOUT, json_encode($output, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . PHP_EOL);
    exit(!empty($result['errors']) ? 1 : 0);
} catch (Exception $e) {
    RgcdpdptDpdLogRepository::add('error', 'DPD Trace CLI cron failed', 'tracking', 0, [
        'error' => $e->getMessage(),
    ]);
    fwrite(STDERR, $e->getMessage() . PHP_EOL);
    exit(1);
}
