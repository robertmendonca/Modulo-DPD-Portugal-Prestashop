# Guia de utilização

Este guia explica o fluxo normal depois do módulo estar instalado e configurado.

## Fluxo do cliente no checkout

1. O cliente adiciona produtos ao carrinho.
2. Preenche a morada de entrega.
3. O PrestaShop mostra os métodos DPD disponíveis para essa morada.
4. O cliente escolhe Home ou Pickup/Shop.

### Se escolher Home

A encomenda será entregue na morada indicada pelo cliente.

### Se escolher DPD Fresh

O cliente final escolhe o método DPD Fresh no checkout como qualquer outra transportadora.

No momento de criar a expedição, o módulo adiciona automaticamente as datas Fresh exigidas pela DPD.

### Se escolher Pickup/Shop

O módulo mostra automaticamente:

- lista de pontos Pickup próximos;
- mapa com os pontos disponíveis;
- marcador DPD no mapa.

O cliente deve selecionar um ponto Pickup antes de continuar.

O botão **Procurar pontos Pickup** serve para atualizar a pesquisa, por exemplo quando o cliente altera o código postal.

## Fluxo do lojista no backoffice

1. Entre no backoffice.
2. Vá a **Encomendas**.
3. Abra a encomenda.
4. Confirme que a encomenda está paga ou pronta para envio.
5. No bloco DPD, clique em **Criar expedição DPD**.
6. Aguarde a resposta da DPD.
7. Abra ou descarregue a etiqueta PDF.
8. Imprima a etiqueta.
9. Cole a etiqueta na encomenda.

## Quando criar a expedição

A expedição não é criada automaticamente no momento da compra.

Isto é intencional. Evita criar expedições para encomendas:

- não pagas;
- canceladas;
- pendentes de validação;
- com stock indisponível;
- ainda em preparação.

## Onde encontrar a guia e a etiqueta

Depois da expedição criada, o módulo guarda:

- número da guia;
- etiqueta PDF;
- resposta da DPD;
- tracking no PrestaShop.

A etiqueta fica disponível no bloco DPD da encomenda.


## Tracking automático depois da entrega à DPD

Depois de gerar a etiqueta e entregar fisicamente a encomenda à DPD, não é necessário alterar manualmente os estados se a sincronização estiver ativada.

O fluxo automático é:

1. `COL` - **Encomenda recolhida**: o PrestaShop passa para o estado configurado como **Enviado**.
2. `OFD` - **Em distribuição**: o PrestaShop passa para **Saiu para entrega**.
3. `POD` - **Prova de entrega**: o PrestaShop passa para **Entregue** e a monitorização dessa expedição termina.

O módulo analisa o histórico completo devolvido pela API DPD. Isto permite recuperar corretamente o estado mesmo que uma execução do CRON aconteça depois de vários eventos já terem ocorrido.

Eventos como passagem por HUB, entrada em armazém, alteração de morada, destinatário ausente ou outras incidências podem ser guardados nos logs, mas não provocam uma alteração automática do estado da encomenda.

Na própria encomenda existe o botão **Sincronizar estado DPD agora**, útil para teste e diagnóstico.

### CRON recomendado

Na aba **Tracking automático** da configuração do módulo é mostrado o comando local a utilizar no servidor.

Execute o ficheiro:

```text
modules/rgcdpdpt/cron/trace-sync.php
```

a cada 15 minutos. A sincronização não utiliza endpoint HTTP e não depende de Cloudflare ou do frontend.

## Se a expedição falhar

Leia a mensagem devolvida pela DPD.

As causas mais comuns são:

- conta DPD incorreta para o serviço;
- credenciais inválidas;
- IP não autorizado;
- morada incompleta;
- ponto Pickup não selecionado;
- serviço não contratado na DPD.

Use a aba **Diagnóstico** para obter mais informação.
