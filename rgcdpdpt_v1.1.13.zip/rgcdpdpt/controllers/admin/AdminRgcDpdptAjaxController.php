<?php
class AdminRgcDpdptAjaxController extends ModuleAdminController
{
    public $bootstrap = true;

    public function postProcess()
    {
        $action = Tools::getValue('action');

        if ($action === 'CreateShipment') {
            $idOrder = (int) Tools::getValue('id_order');

            try {
                (new RgcdpdptDpdShipmentService($this->module))->createForOrder($idOrder);
                $this->context->cookie->__set('rgcdpdpt_flash_success', 'Expedição DPD criada com sucesso.');
            } catch (Exception $e) {
                RgcdpdptDpdLogRepository::add('error', $e->getMessage(), 'order', $idOrder);
                $this->context->cookie->__set('rgcdpdpt_flash_error', $e->getMessage());
            }

            Tools::redirectAdmin($this->context->link->getAdminLink('AdminOrders', true, [], [
                'id_order' => $idOrder,
                'vieworder' => 1,
            ]));
        }


        if ($action === 'RefreshTracking') {
            $idOrder = (int) Tools::getValue('id_order');

            try {
                $tracking = (new RgcdpdptDpdShipmentService($this->module))->refreshTrackingForOrder($idOrder);
                $this->context->cookie->__set('rgcdpdpt_flash_success', 'Guia DPD recuperada: ' . $tracking);
            } catch (Exception $e) {
                RgcdpdptDpdLogRepository::add('error', $e->getMessage(), 'order', $idOrder);
                $this->context->cookie->__set('rgcdpdpt_flash_error', $e->getMessage());
            }

            Tools::redirectAdmin($this->context->link->getAdminLink('AdminOrders', true, [], [
                'id_order' => $idOrder,
                'vieworder' => 1,
            ]));
        }


        if ($action === 'SyncTrackingStatus') {
            $idOrder = (int) Tools::getValue('id_order');

            try {
                $sync = (new RgcdpdptDpdTrackingSyncService($this->module))->syncOrder($idOrder, true);
                $message = 'Tracking DPD sincronizado';
                if (!empty($sync['event_code'])) {
                    $message .= ': ' . $sync['event_code'];
                    if (!empty($sync['event_description'])) {
                        $message .= ' - ' . $sync['event_description'];
                    }
                }
                if (!empty($sync['order_state_changed'])) {
                    $message .= '. Estado da encomenda atualizado.';
                } else {
                    $message .= '. Sem alteração de estado.';
                }
                $this->context->cookie->__set('rgcdpdpt_flash_success', $message);
            } catch (Exception $e) {
                RgcdpdptDpdLogRepository::add('error', $e->getMessage(), 'order', $idOrder);
                $this->context->cookie->__set('rgcdpdpt_flash_error', $e->getMessage());
            }

            Tools::redirectAdmin($this->context->link->getAdminLink('AdminOrders', true, [], [
                'id_order' => $idOrder,
                'vieworder' => 1,
            ]));
        }


        if ($action === 'SetManualTracking') {
            $idOrder = (int) Tools::getValue('id_order');
            $trackingNumber = (string) Tools::getValue('tracking_number');

            try {
                $tracking = (new RgcdpdptDpdShipmentService($this->module))->setManualTrackingForOrder($idOrder, $trackingNumber);
                $this->context->cookie->__set('rgcdpdpt_flash_success', 'Guia DPD gravada: ' . $tracking);
            } catch (Exception $e) {
                RgcdpdptDpdLogRepository::add('error', $e->getMessage(), 'order', $idOrder);
                $this->context->cookie->__set('rgcdpdpt_flash_error', $e->getMessage());
            }

            Tools::redirectAdmin($this->context->link->getAdminLink('AdminOrders', true, [], [
                'id_order' => $idOrder,
                'vieworder' => 1,
            ]));
        }

        if ($action === 'DownloadLabel') {
            $idOrder = (int) Tools::getValue('id_order');
            $shipment = RgcdpdptDpdShipmentRepository::getByOrderId($idOrder);
            if (!$shipment || empty($shipment['label_path']) || !RgcdpdptDpdStorage::isManagedLabelPath($shipment['label_path'])) {
                http_response_code(404);
                die('Etiqueta não encontrada');
            }

            header('Content-Type: application/pdf');
            header('Content-Disposition: inline; filename="dpd-label-order-' . $idOrder . '.pdf"');
            header('X-Content-Type-Options: nosniff');
            header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
            readfile($shipment['label_path']);
            exit;
        }

        parent::postProcess();
    }
}
