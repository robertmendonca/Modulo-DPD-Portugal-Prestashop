<?php
class RgcdpdptPickupModuleFrontController extends ModuleFrontController
{
    public $ssl = true;
    public $ajax = true;

    public function postProcess()
    {
        if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? '')) !== 'POST') {
            $this->renderJson(['ok' => false, 'message' => 'Método não permitido.'], 405);
            return;
        }

        $cart = $this->context->cart;
        if (!Validate::isLoadedObject($cart)) {
            $this->renderJson(['ok' => false, 'message' => 'Carrinho não encontrado.'], 400);
            return;
        }

        $token = (string) Tools::getValue('token');
        if (!RgcdpdptDpdSecurity::validatePickupToken($token, $cart)) {
            $this->renderJson(['ok' => false, 'message' => 'Pedido Pickup inválido. Atualize a página e tente novamente.'], 403);
            return;
        }

        $action = trim((string) Tools::getValue('action'));

        try {
            if ($action === 'list') {
                $this->handleList($cart);
                return;
            }

            if ($action === 'save') {
                $this->handleSave($cart);
                return;
            }

            $this->renderJson(['ok' => false, 'message' => 'Ação inválida.'], 400);
        } catch (Exception $e) {
            RgcdpdptDpdLogRepository::add('error', $e->getMessage(), 'pickup', 0);
            $this->renderJson([
                'ok' => false,
                'message' => 'Não foi possível concluir a operação Pickup. Tente novamente.',
            ], 500);
        }
    }

    protected function handleList(Cart $cart)
    {
        $zipCode = $this->limitedValue('zip', 32);
        if ($zipCode === '' || !preg_match('/^[0-9A-Za-z -]{3,32}$/', $zipCode)) {
            $this->renderJson(['ok' => false, 'message' => 'Código postal inválido.'], 400);
            return;
        }

        if (!$this->allowPickupLookup()) {
            $this->renderJson(['ok' => false, 'message' => 'Foram efetuadas demasiadas pesquisas Pickup. Aguarde um momento e tente novamente.'], 429);
            return;
        }

        $manualLookup = (int) Tools::getValue('manual', 0) === 1;
        $deliveryAddress = '';
        $deliveryCity = '';
        $countryCode = 'PRT';

        if ((int) $cart->id_address_delivery > 0) {
            $address = new Address((int) $cart->id_address_delivery);
            if (Validate::isLoadedObject($address)) {
                $country = new Country((int) $address->id_country);
                if (Validate::isLoadedObject($country)) {
                    $countryCode = $this->iso2ToIso3((string) $country->iso_code);
                }

                // For non-Portuguese destinations keep the full address context.
                // Portugal is intentionally postcode-first: the postcode typed in
                // the widget is the authoritative lookup origin.
                if ($countryCode !== 'PRT') {
                    $deliveryAddress = trim((string) $address->address1 . ' ' . (string) $address->address2);
                    $deliveryCity = trim((string) $address->city);
                }
            }
        }

        $pickupClient = new RgcdpdptDpdPickupClient();
        $origin = null;
        $locationMode = 'full_delivery_address';
        $preferDpdDistance = true;
        $displayLimit = max(1, min(50, (int) RgcdpdptDpdConfig::get('PICKUP_MAX_POINTS', '10')));
        $lookupLimit = $displayLimit;

        if ($countryCode === 'PRT') {
            // Never mix a Portuguese postcode with an old street/city from the cart.
            // MyPudo receives the complete postcode only; when possible we geocode
            // that postcode and calculate the real distance to each DPD point locally.
            $deliveryAddress = '';
            $deliveryCity = '?';
            $preferDpdDistance = false;

            $origin = (new RgcdpdptDpdPostcodeGeocoder((string) $this->module->version))
                ->geocodePortuguesePostcode($zipCode);

            if (is_array($origin)) {
                $locationMode = 'postcode_geoapi_pt';
                // Ask DPD for a broader candidate pool, then keep only the nearest
                // configured number after our geographic distance calculation.
                $lookupLimit = 50;
            } else {
                $locationMode = 'postcode_only_fallback';
            }
        } else {
            $submittedAddress = trim((string) Tools::getValue('address', ''));
            $submittedCity = trim((string) Tools::getValue('city', ''));
            if ($submittedAddress !== '') {
                $deliveryAddress = Tools::substr($submittedAddress, 0, 255);
            }
            if ($submittedCity !== '') {
                $deliveryCity = Tools::substr($submittedCity, 0, 128);
            }
        }

        $items = [];
        $coordinateLookupUsed = false;

        if ($countryCode === 'PRT' && is_array($origin)) {
            try {
                // MyPudo exposes a dedicated geographic operation. Using it here
                // is important: the address-based GetPudoList operation can return
                // a different subset of the Pickup network even after we sort the
                // result locally. Ask MyPudo itself for points nearest to the CP7
                // coordinate, then recalculate the displayed distances from the
                // same origin for consistency.
                $items = $pickupClient->searchByCoordinates(
                    $origin['latitude'],
                    $origin['longitude'],
                    $countryCode,
                    'mypudo_longlat_geoapi_pt',
                    50
                );
                if (count($items)) {
                    $coordinateLookupUsed = true;
                    $locationMode = 'mypudo_longlat_geoapi_pt';
                } else {
                    RgcdpdptDpdLogRepository::add('warning', 'Pickup coordinate lookup returned no points; using postcode fallback', 'pickup', 0, [
                        'zip' => $this->maskPostcode($zipCode),
                    ]);
                }
            } catch (Exception $coordinateError) {
                RgcdpdptDpdLogRepository::add('warning', 'Pickup coordinate lookup failed; using postcode fallback', 'pickup', 0, [
                    'zip' => $this->maskPostcode($zipCode),
                    'message' => Tools::substr($coordinateError->getMessage(), 0, 250),
                ]);
            }
        }

        if (!$coordinateLookupUsed) {
            $items = $pickupClient->search(
                $zipCode,
                $countryCode,
                $deliveryAddress,
                $deliveryCity,
                $preferDpdDistance,
                $locationMode,
                $lookupLimit
            );
        }

        if (is_array($origin)) {
            $items = $pickupClient->recalculateDistancesFromOrigin(
                $items,
                $origin['latitude'],
                $origin['longitude']
            );
            $items = array_slice($items, 0, $displayLimit);
        }

        $topPoints = [];
        foreach (array_slice($items, 0, 5) as $logItem) {
            if (!is_array($logItem)) {
                continue;
            }
            $topPoints[] = [
                'code' => Tools::substr((string) ($logItem['code'] ?? ''), 0, 32),
                'name' => Tools::substr((string) ($logItem['name'] ?? ''), 0, 80),
                'zip' => $this->maskPostcode((string) ($logItem['zip'] ?? '')),
                'distance' => $this->safeDistance($logItem['distance'] ?? ''),
            ];
        }

        RgcdpdptDpdLogRepository::add('info', 'Pickup result ordering completed', 'pickup', 0, [
            'zip' => $this->maskPostcode($zipCode),
            'manual' => $manualLookup ? 1 : 0,
            'location_mode' => $locationMode,
            'returned_points' => count($items),
            'top_points' => $topPoints,
        ]);

        $safeItems = [];
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $canonical = RgcdpdptDpdSecurity::canonicalPickupItem($item);
            if ($canonical['code'] === '' || $canonical['name'] === '') {
                continue;
            }

            $canonical['distance'] = $this->safeDistance($item['distance'] ?? '');
            $canonical['_signature'] = RgcdpdptDpdSecurity::signPickupItem($cart, $canonical);
            $safeItems[] = $canonical;
        }

        $this->renderJson(['ok' => true, 'items' => $safeItems]);
    }

    protected function handleSave(Cart $cart)
    {
        $payload = RgcdpdptDpdSecurity::canonicalPickupItem([
            'code' => Tools::getValue('pickup_code'),
            'name' => Tools::getValue('pickup_name'),
            'address' => Tools::getValue('pickup_address'),
            'zip' => Tools::getValue('pickup_zip'),
            'city' => Tools::getValue('pickup_city'),
            'country' => Tools::getValue('pickup_country'),
            'latitude' => Tools::getValue('pickup_latitude'),
            'longitude' => Tools::getValue('pickup_longitude'),
        ]);

        if ($payload['code'] === '' || $payload['name'] === '') {
            $this->renderJson(['ok' => false, 'message' => 'Ponto Pickup inválido.'], 400);
            return;
        }

        $signature = (string) Tools::getValue('pickup_signature');
        if (!RgcdpdptDpdSecurity::validatePickupItemSignature($cart, $payload, $signature)) {
            RgcdpdptDpdLogRepository::add('warning', 'Ponto Pickup rejeitado por assinatura inválida.', 'pickup', 0, [
                'code' => $payload['code'],
                'zip' => $payload['zip'],
            ]);
            $this->renderJson(['ok' => false, 'message' => 'Ponto Pickup inválido. Faça uma nova pesquisa.'], 403);
            return;
        }

        RgcdpdptDpdPickupRepository::saveForCart((int) $cart->id, $payload);
        $this->renderJson(['ok' => true]);
    }

    protected function allowPickupLookup()
    {
        $cookie = $this->context->cookie;
        if (!$cookie) {
            return true;
        }

        $now = time();
        $windowKey = 'rgcdpdpt_pickup_window';
        $countKey = 'rgcdpdpt_pickup_count';
        $windowStarted = (int) $cookie->{$windowKey};
        $count = (int) $cookie->{$countKey};

        if ($windowStarted <= 0 || ($now - $windowStarted) >= 60) {
            $cookie->{$windowKey} = $now;
            $cookie->{$countKey} = 1;
            return true;
        }

        $count++;
        $cookie->{$countKey} = $count;

        return $count <= 30;
    }

    protected function limitedValue($name, $maxLength)
    {
        return Tools::substr(trim((string) Tools::getValue($name, '')), 0, (int) $maxLength);
    }

    protected function safeDistance($value)
    {
        if (!is_scalar($value) && $value !== null) {
            return '';
        }

        return Tools::substr(trim((string) $value), 0, 32);
    }

    protected function renderJson(array $payload, $statusCode = 200)
    {
        if (!headers_sent()) {
            http_response_code((int) $statusCode);
            header('Content-Type: application/json; charset=utf-8');
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        }

        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $this->ajaxRender($json !== false ? $json : '{"ok":false,"message":"Erro interno."}');
    }

    protected function normalizePostcodeForComparison($postcode)
    {
        $postcode = Tools::strtoupper(trim((string) $postcode));
        return preg_replace('/[^0-9A-Z]/', '', $postcode);
    }

    protected function maskPostcode($postcode)
    {
        $digits = preg_replace('/[^0-9]/', '', (string) $postcode);
        if (strlen($digits) >= 4) {
            return substr($digits, 0, 4) . '-***';
        }

        return '***';
    }

    protected function iso2ToIso3($iso2)
    {
        $iso2 = Tools::strtoupper(trim((string) $iso2));
        $map = [
            'PT' => 'PRT',
            'ES' => 'ESP',
            'FR' => 'FRA',
            'DE' => 'DEU',
            'IT' => 'ITA',
            'NL' => 'NLD',
            'BE' => 'BEL',
            'LU' => 'LUX',
            'IE' => 'IRL',
            'GB' => 'GBR',
            'UK' => 'GBR',
        ];

        return $map[$iso2] ?? ($iso2 ?: 'PRT');
    }
}
