<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_1_12($module)
{
    RgcdpdptDpdUpdateChecker::clearCache();
    RgcdpdptDpdConfig::set('INSTALL_REPORTED_VERSION', '');

    // 1.1.11 used a Nominatim cache which may contain an imprecise coordinate
    // for a complete Portuguese postcode. 1.1.12 uses a separate GEO API PT
    // cache, but remove the old file as well so it cannot be reused manually.
    if (defined('_PS_CACHE_DIR_')) {
        $oldCache = rtrim((string) _PS_CACHE_DIR_, '/\\') . DIRECTORY_SEPARATOR . 'rgcdpdpt_postcode_geocode.json';
        if (is_file($oldCache)) {
            @unlink($oldCache);
        }
    }

    return true;
}
