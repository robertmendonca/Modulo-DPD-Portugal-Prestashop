<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_1_8($module)
{
    RgcdpdptDpdUpdateChecker::clearCache();
    RgcdpdptDpdConfig::set('INSTALL_REPORTED_VERSION', '');

    return true;
}
