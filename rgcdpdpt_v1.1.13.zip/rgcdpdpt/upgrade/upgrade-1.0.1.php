<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_1($module)
{
    RgcdpdptDpdConfig::ensureDefaults();
    RgcdpdptDpdInstallReporter::report($module, true);
    return true;
}
