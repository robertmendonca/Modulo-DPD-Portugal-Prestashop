<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_1_2($module)
{
    if (!RgcdpdptDpdSchema::install()) {
        return false;
    }

    RgcdpdptDpdConfig::ensureDefaults();
    RgcdpdptDpdConfig::ensureInternalOAuthCredentials();
    RgcdpdptDpdConfig::ensureTrackingCronToken();

    if (!RgcdpdptDpdOrderStateManager::ensureDefaults()) {
        return false;
    }

    if (class_exists('RgcdpdptDpdUpdateChecker')) {
        RgcdpdptDpdUpdateChecker::clearCache();
    }

    if (class_exists('RgcdpdptDpdInstallReporter')) {
        RgcdpdptDpdInstallReporter::report($module, true);
    }

    return true;
}
