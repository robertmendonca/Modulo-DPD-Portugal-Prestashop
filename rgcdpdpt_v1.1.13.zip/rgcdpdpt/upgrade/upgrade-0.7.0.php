<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_7_0($module)
{
    RgcdpdptDpdConfig::ensureDefaults();
    return (new RgcdpdptDpdCarrierManager($module))->installOrRepair();
}
