<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_1_5($module)
{
    // Force the next normal module load to publish the version that is actually
    // active after PrestaShop completes the upgrade. During an upgrade callback
    // PrestaShop may still expose the previous module version on $module.
    RgcdpdptDpdConfig::set('INSTALL_REPORTED_VERSION', '');
    RgcdpdptDpdConfig::set('INSTALL_LAST_REPORT_ATTEMPT', '');

    if (class_exists('RgcdpdptDpdInstallReporter')) {
        RgcdpdptDpdInstallReporter::report($module, true);
    }

    return true;
}
