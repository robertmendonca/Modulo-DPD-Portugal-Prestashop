<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_7_10($module)
{
    return true;
}
