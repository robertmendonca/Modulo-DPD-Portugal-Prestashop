<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_7_15($module)
{
    if (class_exists('RgcdpdptDpdConfig')) {
        return RgcdpdptDpdConfig::ensureDefaults();
    }

    return true;
}
