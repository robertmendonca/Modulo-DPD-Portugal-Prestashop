<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_7_4($module)
{
    if (!class_exists('RgcdpdptDpdConfig')) {
        require_once dirname(__DIR__) . '/classes/RgcdpdptDpdConfig.php';
    }

    if (!class_exists('RgcdpdptDpdCarrierManager')) {
        require_once dirname(__DIR__) . '/classes/RgcdpdptDpdCarrierManager.php';
    }

    RgcdpdptDpdConfig::ensureDefaults();

    return (new RgcdpdptDpdCarrierManager($module))->installOrRepair();
}
