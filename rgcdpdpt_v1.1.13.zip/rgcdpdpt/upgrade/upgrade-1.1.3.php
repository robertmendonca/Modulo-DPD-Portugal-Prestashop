<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_1_3($module)
{
    // The public HTTP cron endpoint was removed in 1.1.3. Clean up the
    // installation-specific token that older 1.1.x versions generated.
    Configuration::deleteByName(RgcdpdptDpdConfig::key('TRACE_CRON_TOKEN'));

    if (class_exists('RgcdpdptDpdUpdateChecker')) {
        RgcdpdptDpdUpdateChecker::clearCache();
    }

    if (class_exists('RgcdpdptDpdInstallReporter')) {
        RgcdpdptDpdInstallReporter::report($module, true);
    }

    return true;
}
