<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_3($module)
{
    RgcdpdptDpdConfig::ensureDefaults();

    if (class_exists('RgcdpdptDpdUpdateChecker')) {
        RgcdpdptDpdUpdateChecker::clearCache();
    }

    if (class_exists('RgcdpdptDpdInstallReporter')) {
        RgcdpdptDpdInstallReporter::report($module, true);
    }

    return true;
}
