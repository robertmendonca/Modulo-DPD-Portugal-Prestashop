<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_7_2($module)
{
    RgcdpdptDpdConfig::ensureDefaults();

    $legacyKeys = [
        'SUBACCOUNT_HOME',
        'SUBACCOUNT_PICKUP',
        'RATE_HOME_MAINLAND',
        'RATE_HOME_MADEIRA',
        'RATE_HOME_AZORES',
        'RATE_PICKUP_MAINLAND',
        'RATE_PICKUP_MADEIRA',
        'RATE_PICKUP_AZORES',
    ];

    foreach ($legacyKeys as $legacyKey) {
        Configuration::deleteByName(RgcdpdptDpdConfig::key($legacyKey));
    }

    foreach (RgcdpdptDpdConfig::serviceDefinitions() as $type => $definition) {
        $suffix = RgcdpdptDpdConfig::serviceKeySuffix($type);

        RgcdpdptDpdConfig::set('SERVICE_' . $suffix . '_ENABLED', (string) ($definition['default_enabled'] ?? '1'));

        $accountKey = 'SERVICE_' . $suffix . '_ACCOUNT';
        if (trim((string) RgcdpdptDpdConfig::get($accountKey, '')) === '') {
            RgcdpdptDpdConfig::set($accountKey, (string) ($definition['default_account'] ?? ''));
        }

        $nameKey = 'SERVICE_' . $suffix . '_NAME';
        if (trim((string) RgcdpdptDpdConfig::get($nameKey, '')) === '') {
            RgcdpdptDpdConfig::set($nameKey, (string) ($definition['default_name'] ?? $definition['label']));
        }
    }

    return (new RgcdpdptDpdCarrierManager($module))->installOrRepair();
}
