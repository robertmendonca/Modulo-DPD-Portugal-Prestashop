<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_6_1($module)
{
    return (new RgcdpdptDpdCarrierManager($module))->installOrRepair();
}
