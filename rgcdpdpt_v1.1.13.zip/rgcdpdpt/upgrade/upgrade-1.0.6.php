<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_6($module)
{
    if (!RgcdpdptDpdSchema::install()) {
        return false;
    }

    RgcdpdptDpdConfig::ensureDefaults();
    RgcdpdptDpdConfig::migrateSensitiveStorage();
    RgcdpdptDpdConfig::ensureInternalOAuthCredentials();

    if (!RgcdpdptDpdStorage::migrateLegacyLabels()) {
        return false;
    }

    if (!RgcdpdptDpdShipmentRepository::sanitizeStoredPayloads()) {
        return false;
    }

    if (!RgcdpdptDpdLogRepository::sanitizeExistingPayloads()) {
        return false;
    }

    rgcdpdpt_cleanup_legacy_release_files($module);

    if (class_exists('RgcdpdptDpdUpdateChecker')) {
        RgcdpdptDpdUpdateChecker::clearCache();
    }

    if (class_exists('RgcdpdptDpdInstallReporter')) {
        RgcdpdptDpdInstallReporter::report($module, true);
    }

    return true;
}

function rgcdpdpt_cleanup_legacy_release_files($module)
{
    if (!is_object($module) || empty($module->name) || !defined('_PS_MODULE_DIR_')) {
        return;
    }

    $root = rtrim((string) _PS_MODULE_DIR_, '/\\') . DIRECTORY_SEPARATOR . $module->name . DIRECTORY_SEPARATOR;
    $patterns = [
        $root . 'views/js/front-v*.js',
        $root . 'views/js/admin-v*.js',
        $root . 'views/css/front-v*.css',
        $root . 'views/css/admin-v*.css',
    ];

    foreach ($patterns as $pattern) {
        $files = glob($pattern) ?: [];
        foreach ($files as $file) {
            if (is_file($file)) {
                @unlink($file);
            }
        }
    }

    foreach ([
        $root . 'views/img/carrier-home.png',
        $root . 'views/img/carrier-pickup.png',
    ] as $file) {
        if (is_file($file)) {
            @unlink($file);
        }
    }
}
