<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_0($module)
{
    RgcdpdptDpdConfig::ensureDefaults();
    RgcdpdptDpdInstallReporter::report($module);

    return true;
}
