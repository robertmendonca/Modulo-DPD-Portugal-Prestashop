<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_1_4($module)
{
    // Use one stable package URL for every future release. The file on the
    // update server is replaced in place when a new version is published.
    RgcdpdptDpdConfig::set(
        'UPDATE_URL',
        'https://api.rgcconsulting.pt/dpd/module/latest/rgcdpdpt_latest.zip'
    );

    if (class_exists('RgcdpdptDpdUpdateChecker')) {
        RgcdpdptDpdUpdateChecker::clearCache();
    }

    if (class_exists('RgcdpdptDpdInstallReporter')) {
        RgcdpdptDpdInstallReporter::report($module, true);
    }

    return true;
}
