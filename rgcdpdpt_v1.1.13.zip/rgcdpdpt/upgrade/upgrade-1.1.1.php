<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_1_1($module)
{
    // Repeat the 1.1.0 setup defensively. This is intentionally idempotent so
    // shops that partially executed the previous migration can recover safely.
    if (!RgcdpdptDpdSchema::install()) {
        return false;
    }

    RgcdpdptDpdConfig::ensureDefaults();
    RgcdpdptDpdConfig::migrateSensitiveStorage();
    RgcdpdptDpdConfig::ensureInternalOAuthCredentials();
    RgcdpdptDpdConfig::ensureTrackingCronToken();

    if (!RgcdpdptDpdOrderStateManager::ensureDefaults()) {
        return false;
    }

    if (class_exists('RgcdpdptDpdUpdateChecker')) {
        RgcdpdptDpdUpdateChecker::clearCache();
    }

    if (class_exists('RgcdpdptDpdInstallReporter')) {
        RgcdpdptDpdInstallReporter::report($module, true);
    }

    return true;
}
