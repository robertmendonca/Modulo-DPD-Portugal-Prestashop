<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_4_5($module)
{
    $ok = true;
    foreach ([
        'displayCarrierExtraContent',
        'actionCarrierProcess',
        'actionValidateOrder',
        'displayHeader',
        'displayBackOfficeHeader',
        'displayAdminOrderSideBottom',
        'actionFrontControllerSetMedia',
    ] as $hook) {
        $ok = $ok && $module->registerHook($hook);
    }

    if (class_exists('RgcdpdptDpdCarrierManager')) {
        $ok = $ok && (new RgcdpdptDpdCarrierManager($module))->installOrRepair();
    }

    return $ok;
}
